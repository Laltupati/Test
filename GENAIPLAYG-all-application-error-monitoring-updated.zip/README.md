For frontend:
cd client
npm.cmd install
npm.cmd run dev

For backend:
cd server
npm.cmd install
node index.js
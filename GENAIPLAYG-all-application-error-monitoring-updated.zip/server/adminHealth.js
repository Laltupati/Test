/**
 * Admin Health Engine
 * ────────────────────
 * Implements the three Admin-tab use cases against the *real* applications
 * listed in the Use Cases catalog (their live `launchUrl`s):
 *
 *  UC1 — Status check   : HTTP-probe every app and mark it Active / Inactive.
 *                          A 401/403 is normally classified as "Restricted",
 *                          except Azure's standard "This web app is stopped"
 *                          403 page, which is classified as "Stopped". This
 *                          avoids treating an intentionally stopped App Service
 *                          as an access-restricted but healthy application.
 *  UC2 — Auto-fix        : on a genuine failure (timeout / network error /
 *                          5xx), retry with backoff (handles the very
 *                          common "Azure App Service cold start / sleeping
 *                          instance" case, where a simple re-request wakes
 *                          the app back up). If a retry succeeds, the
 *                          incident is auto-resolved and logged as such.
 *  UC3 — Notify owner    : if auto-fix does NOT resolve it, or a downstream
 *                          dependency error is detected, create an Azure-native
 *                          owner alert. Azure Monitor Action Groups are the
 *                          recommended email path; no SMTP server is required.
 *
 * Everything here is in-memory (no DB) — fine for this app's existing
 * pattern (see systemHealth/monitoringData in data.js), but the module is
 * written so a persistent store can be swapped in later without touching
 * the API layer in index.js.
 */

const https = require('https');
const http = require('http');
const { URL } = require('url');
const fs = require('fs');
const path = require('path');
const { getAccessToken } = require('./azureCredential');
const azureLogs = require('./azureLogs');

const REQUEST_TIMEOUT_MS = Math.max(2500, Number(process.env.HEALTH_CHECK_TIMEOUT_MS) || 5000);
const AUTO_FIX_RETRIES = 2;          // number of automatic retries before escalating
const AUTO_FIX_BACKOFF_MS = 4000;    // Azure free/basic tier cold-starts typically need a few seconds
const MAX_INCIDENT_LOG = 500;
const INCIDENT_LOG_FILE = process.env.INCIDENT_LOG_FILE || (process.env.WEBSITE_INSTANCE_ID ? '/home/data/genai-playground-incidents.json' : path.join(__dirname, '.genai-playground-incidents.json'));
const NOTIFY_COOLDOWN_MS = 60 * 60 * 1000;
const AUTO_RESTART_COOLDOWN_MS = 60 * 60 * 1000;
const ENABLE_AUTO_RESTART = process.env.ENABLE_AUTO_RESTART === 'true';
const OWNER_NOTIFICATION_WEBHOOK_URL = process.env.OWNER_NOTIFICATION_WEBHOOK_URL || process.env.AZURE_NOTIFICATION_WEBHOOK_URL || '';
const OWNER_NOTIFICATION_CC = process.env.OWNER_NOTIFICATION_CC || 'laltupati@kpmg.com';
const LOG_MONITOR_INTERVAL_MS = Math.max(Number(process.env.LOG_MONITOR_INTERVAL_MS) || 60000, 60000);
const RECOVERY_SUCCESS_CYCLES = Math.max(2, Number(process.env.HEALTH_RECOVERY_SUCCESS_CYCLES) || 3);
// Status reconciliation intentionally uses a longer lookback than the 60-minute
// UI counter. This lets the service reconstruct an unresolved incident after a
// worker recycle / ZIP deployment even if the durable latch file is temporarily
// unavailable. The status remains latched until explicitly resolved; the
// lookback is only a rehydration safety net, not an auto-recovery timer.
const STATUS_LOG_WINDOW_MINUTES = Math.max(5, Math.min(1440, Number(process.env.LOG_MONITOR_WINDOW_MINUTES || 60)));
const INCIDENT_REHYDRATE_WINDOW_MINUTES = Math.max(STATUS_LOG_WINDOW_MINUTES, Math.min(1440, Number(process.env.INCIDENT_REHYDRATE_WINDOW_MINUTES || 1440)));
const restartHistory = new Map();
const processedLogKeys = new Map(); // don't re-email the same owner more than once/hour for an ongoing outage

// Persist unresolved dependency incidents so a normal availability probe, an
// App Service recycle, or requests landing on another worker instance cannot
// incorrectly flip a Degraded application back to Healthy. On Azure App
// Service, /home is the persistent/shared content area when App Service
// storage is enabled. Override HEALTH_LATCH_FILE if your environment uses a
// different durable mount.
const HEALTH_LATCH_FILE = process.env.HEALTH_LATCH_FILE || (
  process.env.WEBSITE_INSTANCE_ID
    ? '/home/data/genai-playground-health-latches.json'
    : path.join(__dirname, '.genai-playground-health-latches.json')
);

function readPersistentLatches() {
  try {
    if (!fs.existsSync(HEALTH_LATCH_FILE)) return {};
    const raw = fs.readFileSync(HEALTH_LATCH_FILE, 'utf8');
    return raw ? JSON.parse(raw) : {};
  } catch (err) {
    console.warn(`[adminHealth] Unable to read health latch file ${HEALTH_LATCH_FILE}: ${err.message}`);
    return {};
  }
}

function writePersistentLatches(next) {
  try {
    fs.mkdirSync(path.dirname(HEALTH_LATCH_FILE), { recursive: true });
    const tmp = `${HEALTH_LATCH_FILE}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), 'utf8');
    fs.renameSync(tmp, HEALTH_LATCH_FILE);
  } catch (err) {
    console.warn(`[adminHealth] Unable to persist health latch file ${HEALTH_LATCH_FILE}: ${err.message}`);
  }
}

function getPersistentLatch(id) {
  const all = readPersistentLatches();
  const latch = all[id]?.active ? all[id] : null;
  if (!latch) return null;
  // Migration/policy: an unresolved dependency that keeps the application
  // Degraded means the primary workflow is not reliable. Treat it as CRITICAL
  // even when an older persisted latch was written as medium/high.
  if (latch.status === 'degraded' && (latch.dependencyHealth?.status === 'unhealthy' || latch.dependencyIncidentLatched !== false)) {
    latch.errorSeverity = 'critical';
    if (Array.isArray(latch.azureErrors)) {
      latch.azureErrors = latch.azureErrors.map(e => ({ ...e, Severity: e.Dependency ? 'critical' : e.Severity }));
    }
  }
  return latch;
}

function persistDependencyLatch(useCase, record) {
  const all = readPersistentLatches();
  all[useCase.id] = {
    active: true,
    id: useCase.id,
    title: useCase.title,
    status: 'degraded',
    detectedAt: all[useCase.id]?.detectedAt || record.lastError?.timeGenerated || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lastError: record.lastError || all[useCase.id]?.lastError || null,
    errorSeverity: record.status === 'degraded' && record.dependencyHealth?.status === 'unhealthy' ? 'critical' : (record.errorSeverity || all[useCase.id]?.errorSeverity || 'high'),
    remediation: record.remediation || all[useCase.id]?.remediation || 'owner_alert',
    dependencyHealth: record.dependencyHealth || all[useCase.id]?.dependencyHealth || null,
    // Preserve the actual Azure evidence for an unresolved incident so the UI
    // can continue to show the error details even after the rolling Log
    // Analytics display window becomes empty or this worker restarts.
    azureErrors: Array.isArray(record.azureErrors) && record.azureErrors.length
      ? record.azureErrors.slice(0, 25)
      : (Array.isArray(all[useCase.id]?.azureErrors) ? all[useCase.id].azureErrors.slice(0, 25) : []),
    lastNotification: record.lastNotification || all[useCase.id]?.lastNotification || null,
    owner: useCase.owner || null,
    ownerEmail: useCase.ownerEmail || null,
    recoverySuccessCycles: Number(record.recoverySuccessCycles || 0),
    lastRecoveryCheckAt: record.lastRecoveryCheckAt || all[useCase.id]?.lastRecoveryCheckAt || null,
  };
  writePersistentLatches(all);
}

function clearPersistentLatch(id) {
  const all = readPersistentLatches();
  if (!all[id]) return;
  delete all[id];
  writePersistentLatches(all);
}

// id -> record
const healthStore = new Map();
// rolling incident/error log, newest first. Persist it on /home so Azure App
// Service restarts/deployments do not erase Alerts & Incidents / Audit Logs.
function readIncidentLog() {
  try {
    if (!fs.existsSync(INCIDENT_LOG_FILE)) return [];
    const parsed = JSON.parse(fs.readFileSync(INCIDENT_LOG_FILE, 'utf8') || '[]');
    return Array.isArray(parsed) ? parsed.slice(0, MAX_INCIDENT_LOG) : [];
  } catch (err) {
    console.warn(`[adminHealth] Unable to read incident log ${INCIDENT_LOG_FILE}: ${err.message}`);
    return [];
  }
}
function writeIncidentLog(rows) {
  try {
    fs.mkdirSync(path.dirname(INCIDENT_LOG_FILE), { recursive: true });
    const tmp = `${INCIDENT_LOG_FILE}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(rows.slice(0, MAX_INCIDENT_LOG), null, 2), 'utf8');
    fs.renameSync(tmp, INCIDENT_LOG_FILE);
  } catch (err) {
    console.warn(`[adminHealth] Unable to persist incident log ${INCIDENT_LOG_FILE}: ${err.message}`);
  }
}
const incidentLog = readIncidentLog();

// Concurrency guards: prevent a manual "Recheck"/"Check All" from
// overlapping the background sweep (or another manual click) against the
// same use case(s), which would double outbound probes and could race on
// healthStore writes / fire duplicate notifications.
const inFlightIds = new Set();
let sweepInFlight = false;

function logIncident(entry) {
  incidentLog.unshift({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ...entry,
  });
  if (incidentLog.length > MAX_INCIDENT_LOG) incidentLog.length = MAX_INCIDENT_LOG;
  writeIncidentLog(incidentLog);
}

/** Single HTTP probe of a launchUrl. Resolves, never rejects. */
function probe(launchUrl) {
  return new Promise((resolve) => {
    const started = Date.now();
    let target;
    try {
      target = new URL(launchUrl);
    } catch {
      return resolve({ ok: false, errorType: 'invalid_url', errorMessage: 'launchUrl is not a valid URL' });
    }
    const lib = target.protocol === 'http:' ? http : https;

    const req = lib.request(
      target,
      {
        method: 'GET',
        timeout: REQUEST_TIMEOUT_MS,
        headers: {
          // Some App Service auth layers / WAFs / access restrictions treat
          // requests with no User-Agent (Node's default) as non-browser
          // traffic and reject them fast — even though the app itself is
          // perfectly healthy. Looking like a real browser avoids that
          // false "inactive" reading.
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 GenAI-Playground-HealthCheck',
          Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        },
      },
      (res) => {
        // Capture a small response-body sample. Azure App Service returns HTTP
        // 403 for both access restrictions *and* for a stopped web app, so the
        // status code alone is not enough to distinguish those states.
        const chunks = [];
        let capturedBytes = 0;
        const MAX_BODY_SAMPLE_BYTES = 16 * 1024;
        res.on('data', (chunk) => {
          if (capturedBytes >= MAX_BODY_SAMPLE_BYTES) return;
          const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
          const remaining = MAX_BODY_SAMPLE_BYTES - capturedBytes;
          chunks.push(buf.subarray(0, remaining));
          capturedBytes += Math.min(buf.length, remaining);
        });
        res.on('end', () => {
          const latencyMs = Date.now() - started;
          const ok = res.statusCode >= 200 && res.statusCode < 400;
          const bodySample = Buffer.concat(chunks).toString('utf8');
          const normalizedBody = bodySample.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
          const appStopped = res.statusCode === 403 && (
            /this web app is stopped/.test(normalizedBody) ||
            /web app (?:has been|is) stopped/.test(normalizedBody) ||
            /the web app you have attempted to reach is currently stopped/.test(normalizedBody)
          );
          const authRestricted = !ok && !appStopped && (res.statusCode === 401 || res.statusCode === 403);

          let errorMessage = null;
          if (!ok) {
            if (appStopped) {
              errorMessage = `Azure App Service is stopped (HTTP ${res.statusCode})`;
            } else if (authRestricted) {
              errorMessage = `App responded with HTTP ${res.statusCode} — access-restricted (App Service auth / IP allowlist). The app is up; this checker just isn't an allowed caller.`;
            } else {
              errorMessage = `App responded with HTTP ${res.statusCode}`;
            }
          }
          resolve({
            ok,
            appStopped,
            authRestricted,
            statusCode: res.statusCode,
            latencyMs,
            errorType: ok ? null : (appStopped ? 'app_stopped' : 'http_error'),
            errorMessage,
          });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({
        ok: false,
        latencyMs: Date.now() - started,
        errorType: 'timeout',
        errorMessage: `No response within ${REQUEST_TIMEOUT_MS / 1000}s (likely a cold-started/sleeping instance)`,
      });
    });

    req.on('error', (err) => {
      resolve({
        ok: false,
        latencyMs: Date.now() - started,
        errorType: 'network_error',
        errorMessage: err.message,
      });
    });

    req.end();
  });
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function detectDependency(text) {
  const t = String(text || '').toLowerCase();
  if (/azure[ -]?openai|openai|aoai|cognitive services|azure ai inference|chat completions|model endpoint|model deployment|deployment.*(?:not found|unavailable)|gpt-4|gpt-35|content filter/.test(t)) return 'Azure OpenAI';
  if (/azure sql|sql server|database|jdbc|odbc|pyodbc|sequelize|entity framework/.test(t)) return 'Database / SQL';
  if (/blob|storage account|azure storage|queue storage|table storage|data lake/.test(t)) return 'Azure Storage';
  if (/key vault|keyvault|secret|certificate|@microsoft\.keyvault|secreturi/.test(t)) return 'Key Vault';
  if (/redis|cache/.test(t)) return 'Redis / Cache';
  if (/service bus|event hub|eventhub|event grid/.test(t)) return 'Messaging';
  if (/dns|name resolution|econnrefused|econnreset|socket|connection refused|connection reset/.test(t)) return 'Network / External dependency';
  return null;
}

function normalizeOperationalSeverity(value) {
  const v = String(value || '').toLowerCase();
  if (v === 'urgent' || v === 'critical' || v === 'fatal') return 'critical';
  if (v === 'high' || v === 'error') return 'high';
  if (v === 'medium' || v === 'warning' || v === 'warn') return 'medium';
  return 'low';
}

function isActionableSeverity(value) {
  return ['critical', 'high', 'medium'].includes(normalizeOperationalSeverity(value));
}

function classifyError(error, recentLogs = []) {
  const text = [error?.errorType, error?.errorMessage, ...recentLogs.map(x => x.Message)].filter(Boolean).join(' ').toLowerCase();
  const dependency = detectDependency(text);

  if (/outofmemory|heap out of memory|memory limit|cannot allocate memory/.test(text)) {
    return { severity: 'critical', action: 'owner_alert', category: 'runtime', dependency, reason: 'Memory exhaustion requires application-level investigation or scaling.' };
  }
  if (/authentication|unauthorized|forbidden|permissiondenied|\b401\b|\b403\b|invalid credential|invalid api key|invalid subscription key|api key.*(?:missing|invalid|not set|not configured)|key vault.*(?:not able to be resolved|unresolved|invalidsyntax|vaultnotfound|secretnotfound|access.*denied)|secret.*(?:not found|can(?:not|'t) be found|missing)|secreturi.*(?:invalid|missing)|@microsoft\.keyvault|expired token|token acquisition/.test(text)) {
    return { severity: 'critical', action: 'owner_alert', category: dependency ? 'dependency_auth' : 'authentication', dependency, reason: dependency === 'Key Vault' ? 'Key Vault/app-setting credential resolution failure can make the application workflow unusable and requires immediate owner action.' : 'Authentication or authorization failure is not safe to auto-remediate.' };
  }
  if (dependency === 'Azure OpenAI' && /\b429\b|too many requests|rate limit|quota|throttl/.test(text)) {
    return { severity: 'high', action: 'owner_alert', category: 'azure_openai_throttling', dependency, reason: 'Azure OpenAI is throttling or quota-limited; review model quota, TPM/RPM and retry policy.' };
  }
  if (dependency === 'Azure OpenAI' && /timeout|timed out|unavailable|connection|failed|error|\b5\d\d\b/.test(text)) {
    return { severity: 'high', action: 'owner_alert', category: 'azure_openai_dependency', dependency, reason: 'Application is reachable but its Azure OpenAI dependency is failing.' };
  }
  if (/configuration|environment variable|connection string|secret|certificate|dns|name resolution|database|sql|redis|dependency/.test(text)) {
    return { severity: 'high', action: 'owner_alert', category: 'dependency', dependency, reason: 'Configuration/dependency issue should be investigated before changing infrastructure.' };
  }
  if (/timeout|econnreset|econnrefused|socket|502|503|504|crash|worker|process|http_error/.test(text)) {
    return { severity: 'high', action: dependency ? 'owner_alert' : 'auto_restart_then_alert', category: dependency ? 'dependency' : 'app_service', dependency, reason: dependency ? `${dependency} connectivity failure requires dependency investigation.` : 'Likely transient App Service/process issue; a controlled restart is permitted when enabled.' };
  }
  return { severity: 'medium', action: 'owner_alert', category: dependency ? 'dependency' : 'application', dependency, reason: dependency ? `${dependency} error requires investigation.` : 'Unknown application error; manual investigation required.' };
}


async function getAzureAppServiceRuntimeState(useCase) {
  try {
    const resourceId = azureLogs.resolveResourceId(useCase);
    if (!resourceId) return { available: false, state: null, reason: 'resource_id_missing' };
    const token = await getAccessToken('https://management.azure.com/.default');
    if (!token?.token) return { available: false, state: null, reason: 'token_unavailable' };
    const endpoint = `https://management.azure.com${resourceId}?api-version=2024-11-01`;
    const response = await fetch(endpoint, { headers: { Authorization: `Bearer ${token.token}` } });
    if (!response.ok) return { available: false, state: null, reason: `arm_http_${response.status}` };
    const body = await response.json();
    return { available: true, state: String(body?.properties?.state || '').toLowerCase(), resourceId };
  } catch (err) {
    return { available: false, state: null, reason: err.message };
  }
}

async function restartApp(useCase) {
  if (!ENABLE_AUTO_RESTART) return { attempted: false, reason: 'auto_restart_disabled' };
  const resourceId = azureLogs.resolveResourceId(useCase);
  if (!resourceId) return { attempted: false, reason: 'azureResourceId_missing' };
  const previous = restartHistory.get(useCase.id);
  if (previous && Date.now() - previous < AUTO_RESTART_COOLDOWN_MS) {
    return { attempted: false, reason: 'restart_cooldown' };
  }
  const token = await getAccessToken('https://management.azure.com/.default');
  if (!token?.token) throw new Error('Unable to acquire Azure management token');
  const endpoint = `https://management.azure.com${resourceId}/restart?api-version=2026-03-15&softRestart=true&synchronous=true`;
  const response = await fetch(endpoint, { method: 'POST', headers: { Authorization: `Bearer ${token.token}` } });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Azure restart failed (${response.status}): ${body.slice(0, 500)}`);
  }
  restartHistory.set(useCase.id, Date.now());
  return { attempted: true, reason: 'restart_requested' };
}

async function collectApplicationErrors(useCase, minutes = 60) {
  try {
    return await azureLogs.getErrors(azureLogs.resolveResourceIds(useCase), minutes, 100);
  } catch (err) {
    logIncident({ useCaseId: useCase.id, solution: useCase.title, level: 'log_query_failed', message: `Could not retrieve Azure application errors: ${err.message}` });
    return { configured: true, errors: [], reason: err.message };
  }
}

/** Human-readable "how long ago" for incident log messages, e.g. "12min". */
function timeAgoMs(iso) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return '<1min';
  if (mins < 60) return `${mins}min`;
  return `${Math.round(mins / 60)}h`;
}

/**
 * Owner notification without SMTP.
 *
 * Recommended production pattern: Azure Monitor Scheduled Query Alert + Action Group.
 * This function optionally calls an Azure Logic App / Power Automate / Function webhook
 * for immediate, app-aware notification. The webhook receives owner + CC addresses.
 * If no webhook is configured, the incident remains visible/queued while Azure Monitor
 * Action Groups can send mail directly from the Log Analytics alert rule.
 */
async function notifyOwner(useCase, record) {
  const dependency = record.lastError?.dependency || record.dependencyHealth?.failingDependency || null;
  const payload = {
    eventType: 'genai-playground-health-alert',
    severity: record.errorSeverity || 'urgent',
    applicationId: useCase.id,
    application: useCase.title,
    applicationUrl: useCase.launchUrl,
    owner: useCase.owner || null,
    to: useCase.ownerEmail || null,
    cc: OWNER_NOTIFICATION_CC ? [OWNER_NOTIFICATION_CC] : [],
    status: record.status,
    dependency,
    lastError: record.lastError || null,
    consecutiveFailures: record.consecutiveFailures || 0,
    lastChecked: record.lastChecked || new Date().toISOString(),
    remediation: record.remediation || null,
    subject: `[GenAI Playground] ${String(record.status || 'alert').toUpperCase()}: "${useCase.title}" requires attention`,
  };

  if (!OWNER_NOTIFICATION_WEBHOOK_URL) {
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'notify_pending',
      severity: record.errorSeverity || 'urgent',
      actionRequired: true,
      message: `Owner alert queued for ${useCase.owner || 'application owner'} <${useCase.ownerEmail || 'no email'}>; CC ${OWNER_NOTIFICATION_CC}. No SMTP is required. Configure Azure Monitor Action Group alerting (recommended) or OWNER_NOTIFICATION_WEBHOOK_URL for immediate app-triggered delivery.`,
    });
    return { sent: false, reason: 'azure_notification_not_configured', provider: 'azure-native', ...payload };
  }

  try {
    const response = await fetch(OWNER_NOTIFICATION_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Notification webhook failed (${response.status}): ${body.slice(0, 300)}`);
    }
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'notify_sent',
      severity: record.errorSeverity || 'urgent',
      actionRequired: true,
      message: `Azure-native notification sent to ${useCase.owner || 'owner'} <${useCase.ownerEmail}> with CC ${OWNER_NOTIFICATION_CC}.`,
    });
    return { sent: true, provider: 'azure-webhook', ...payload };
  } catch (err) {
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'notify_failed',
      severity: 'urgent',
      actionRequired: true,
      message: `Failed to invoke Azure-native owner notification: ${err.message}`,
    });
    return { sent: false, reason: err.message, provider: 'azure-webhook', ...payload };
  }
}

async function maybeNotifyOwner(useCase, record, previousRecord) {
  if (!useCase.ownerEmail) return record;
  const last = previousRecord?.lastNotification || record.lastNotification;
  // Apply cooldown whether the last delivery was sent or queued, so repeated log
  // lines from one dependency outage cannot spam the owner/notification workflow.
  const lastAt = last?.at;
  const withinCooldown = lastAt && (Date.now() - new Date(lastAt).getTime()) < NOTIFY_COOLDOWN_MS;
  if (withinCooldown) {
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'notify_suppressed',
      severity: record.errorSeverity || 'high',
      actionRequired: true,
      message: `Owner alert suppressed: an alert for this application was already generated ${timeAgoMs(lastAt)} ago (cooldown ${NOTIFY_COOLDOWN_MS / 60000}min).`,
    });
    record.lastNotification = last;
    return record;
  }
  const notification = await notifyOwner(useCase, record);
  record.lastNotification = { ...notification, at: new Date().toISOString() };
  return record;
}

/**
 * Run the full pipeline for one use case:
 *   probe -> if auth-restricted, stop (that's not an outage) ->
 *   otherwise if failing, auto-fix retries -> if still failing, notify owner
 *
 * Guarded against re-entrancy: if a check for this useCase.id is already
 * in flight (from the background sweep or another manual click), this
 * call waits for it and returns that result instead of starting a second,
 * overlapping probe/retry/notify cycle against the same app.
 */
async function runCheck(useCase) {
  if (inFlightIds.has(useCase.id)) {
    // Poll briefly for the in-flight check to finish rather than starting
    // a duplicate one. Simple and sufficient at this app's scale/traffic.
    while (inFlightIds.has(useCase.id)) {
      // eslint-disable-next-line no-await-in-loop
      await sleep(200);
    }
    return healthStore.get(useCase.id);
  }
  inFlightIds.add(useCase.id);
  try {
    return await runCheckInternal(useCase);
  } finally {
    inFlightIds.delete(useCase.id);
  }
}

async function runCheckInternal(useCase) {
  if (!useCase.launchUrl) {
    const record = {
      id: useCase.id, title: useCase.title, launchUrl: null,
      status: 'unknown', lastChecked: new Date().toISOString(),
      latencyMs: null, statusCode: null, consecutiveFailures: 0,
      lastError: null, autoFixAttempts: [], lastNotification: null,
      owner: useCase.owner || null, ownerEmail: useCase.ownerEmail || null,
    };
    healthStore.set(useCase.id, record);
    return record;
  }

  const prev = healthStore.get(useCase.id);
  let result = await probe(useCase.launchUrl);
  const autoFixAttempts = [];
  let latestAzureErrors = [];
  let diagnosis = { severity: null, action: null, reason: null };

  // Azure's standard stopped-app page also returns HTTP 403. Detect that
  // separately from a genuine access restriction so the dashboard reports
  // "Stopped · HTTP 403" instead of the misleading "Restricted" state.
  if (result.appStopped) {
    if (prev?.status !== 'stopped') {
      logIncident({
        useCaseId: useCase.id,
        solution: useCase.title,
        level: 'stopped',
        severity: 'critical',
        actionRequired: true,
        message: `Azure App Service is stopped (HTTP ${result.statusCode}). Start the App Service to restore availability.`,
      });
    }
    const record = {
      id: useCase.id,
      title: useCase.title,
      launchUrl: useCase.launchUrl,
      status: 'stopped',
      lastChecked: new Date().toISOString(),
      latencyMs: result.latencyMs ?? null,
      statusCode: result.statusCode ?? null,
      consecutiveFailures: (prev?.status === 'stopped' ? (prev?.consecutiveFailures || 0) : 0) + 1,
      lastError: { errorType: result.errorType, errorMessage: result.errorMessage, statusCode: result.statusCode ?? null },
      errorSeverity: 'critical',
      actionRequired: true,
      remediation: 'Start Azure App Service',
      autoFixAttempts: [],
      lastNotification: prev?.lastNotification || null,
      owner: useCase.owner || null,
      ownerEmail: useCase.ownerEmail || null,
    };
    await maybeNotifyOwner(useCase, record, prev);
    healthStore.set(useCase.id, record);
    return record;
  }

  // A 401/403 means the app itself answered — it's up and enforcing its own
  // auth/IP-restriction rules. That's a configuration fact, not an outage:
  // retrying won't change it and the owner doesn't need a "your app is down"
  // email about something working as designed.
  if (result.authRestricted) {
    if (prev?.status !== 'restricted') {
      logIncident({
        useCaseId: useCase.id,
        solution: useCase.title,
        level: 'restricted',
        message: `App is reachable but access-restricted (HTTP ${result.statusCode}) — likely App Service auth or an IP allowlist. Treated as up, not an outage.`,
      });
    }
    const record = {
      id: useCase.id,
      title: useCase.title,
      launchUrl: useCase.launchUrl,
      status: 'restricted',
      lastChecked: new Date().toISOString(),
      latencyMs: result.latencyMs ?? null,
      statusCode: result.statusCode ?? null,
      consecutiveFailures: 0,
      lastError: { errorType: result.errorType, errorMessage: result.errorMessage },
      autoFixAttempts: [],
      lastNotification: prev?.lastNotification || null,
      owner: useCase.owner || null,
      ownerEmail: useCase.ownerEmail || null,
    };
    healthStore.set(useCase.id, record);
    return record;
  }

  // DNS/name-resolution failures describe the monitoring host/network, not the
  // Azure App Service runtime. Do not label the application Down or restart it
  // when the checker itself cannot resolve the configured hostname.
  const isDnsMonitoringFailure = !result.ok && result.errorType === 'network_error' &&
    /ENOTFOUND|EAI_AGAIN|getaddrinfo|name resolution|dns/i.test(String(result.errorMessage || ''));
  if (isDnsMonitoringFailure) {
    // The public URL can be perfectly valid while the machine/container running
    // this dashboard has a transient/custom-DNS resolution problem. Ask Azure
    // Resource Manager for the App Service runtime state before assigning an
    // application status. This prevents a monitor-side DNS failure from becoming
    // an application incident.
    const azureState = await getAzureAppServiceRuntimeState(useCase);
    if (azureState.available && azureState.state === 'running') {
      const record = {
        id: useCase.id, title: useCase.title, launchUrl: useCase.launchUrl,
        status: 'restricted', lastChecked: new Date().toISOString(),
        latencyMs: result.latencyMs ?? null, statusCode: null, consecutiveFailures: 0,
        lastError: null, errorSeverity: null, actionRequired: false,
        remediation: null, autoFixAttempts: [], lastNotification: prev?.lastNotification || null,
        owner: useCase.owner || null, ownerEmail: useCase.ownerEmail || null,
        monitoringNote: `HTTP probe DNS resolution failed, but Azure Resource Manager confirms App Service is Running (${azureState.resourceId}).`,
      };
      if (prev?.status === 'monitoring_error') {
        logIncident({
          useCaseId: useCase.id, solution: useCase.title, level: 'resolved', severity: 'info',
          actionRequired: false,
          message: 'Monitoring DNS error cleared as an application incident: Azure Resource Manager confirms the App Service is Running.',
        });
      }
      healthStore.set(useCase.id, record);
      return record;
    }
    if (azureState.available && ['stopped', 'stopping'].includes(azureState.state)) {
      const record = {
        id: useCase.id, title: useCase.title, launchUrl: useCase.launchUrl, status: 'stopped',
        lastChecked: new Date().toISOString(), latencyMs: result.latencyMs ?? null, statusCode: null,
        consecutiveFailures: (prev?.status === 'stopped' ? (prev?.consecutiveFailures || 0) : 0) + 1,
        lastError: { errorType: 'app_stopped', errorMessage: `Azure Resource Manager reports App Service state: ${azureState.state}` },
        errorSeverity: 'critical', actionRequired: true, remediation: 'Start Azure App Service',
        autoFixAttempts: [], lastNotification: prev?.lastNotification || null,
        owner: useCase.owner || null, ownerEmail: useCase.ownerEmail || null,
      };
      healthStore.set(useCase.id, record);
      return record;
    }

    // ARM could not verify the runtime either. Keep this as a monitor-local
    // diagnostic only: no Azure severity, no owner escalation, no restart.
    const record = {
      id: useCase.id, title: useCase.title, launchUrl: useCase.launchUrl,
      status: 'monitoring_error', lastChecked: new Date().toISOString(),
      latencyMs: result.latencyMs ?? null, statusCode: null,
      consecutiveFailures: (prev?.status === 'monitoring_error' ? (prev?.consecutiveFailures || 0) : 0) + 1,
      lastError: { errorType: 'monitoring_dns_error', errorMessage: result.errorMessage },
      errorSeverity: null, actionRequired: false,
      remediation: 'Check DNS/network access from the GENAIPLAYG monitoring host',
      autoFixAttempts: [], lastNotification: prev?.lastNotification || null,
      owner: useCase.owner || null, ownerEmail: useCase.ownerEmail || null,
      monitoringNote: `Azure runtime verification unavailable: ${azureState.reason || 'unknown reason'}`,
    };
    healthStore.set(useCase.id, record);
    return record;
  }

  if (!result.ok) {
    const azureErrors = await collectApplicationErrors(useCase, 60);
    latestAzureErrors = azureErrors.errors || [];
    diagnosis = classifyError({ errorType: result.errorType, errorMessage: result.errorMessage }, azureErrors.errors || []);
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'error',
      severity: diagnosis.severity,
      actionRequired: true,
      message: `Health check failed: ${result.errorType} — ${result.errorMessage}. ${diagnosis.reason}`,
      httpStatus: result.statusCode || null,
      azureErrors: (azureErrors.errors || []).slice(0, 10),
    });

    // UC2: first retry for transient/cold-start failures.
    for (let attempt = 1; attempt <= AUTO_FIX_RETRIES && !result.ok && !result.authRestricted && !result.appStopped && !(Number(result.statusCode) >= 500); attempt += 1) {
      logIncident({
        useCaseId: useCase.id,
        solution: useCase.title,
        level: 'auto_fix',
        message: `Auto-fix attempt ${attempt}/${AUTO_FIX_RETRIES}: retrying after ${AUTO_FIX_BACKOFF_MS / 1000}s backoff (handles cold-start/sleeping app instances).`,
      });
      await sleep(AUTO_FIX_BACKOFF_MS);
      result = await probe(useCase.launchUrl);
      autoFixAttempts.push({ attempt, ok: result.ok, ...result });
    }

    if (result.ok) {
      logIncident({
        useCaseId: useCase.id,
        solution: useCase.title,
        level: 'resolved',
        message: `Auto-fix succeeded — app responded after retry (HTTP ${result.statusCode}). No owner notification needed.`,
      });
    } else if (diagnosis.action === 'auto_restart_then_alert') {
      try {
        const restart = await restartApp(useCase);
        logIncident({
          useCaseId: useCase.id,
          solution: useCase.title,
          level: restart.attempted ? 'auto_restart' : 'auto_restart_skipped',
          severity: diagnosis.severity,
          actionRequired: true,
          message: restart.attempted
            ? 'Controlled Azure App Service restart completed/requested. Re-probing application.'
            : `Automatic restart skipped: ${restart.reason}.`,
        });
        if (restart.attempted) {
          await sleep(5000);
          result = await probe(useCase.launchUrl);
          autoFixAttempts.push({ attempt: 'restart', ok: result.ok, ...result });
          if (result.ok) {
            logIncident({ useCaseId: useCase.id, solution: useCase.title, level: 'resolved', message: 'Application recovered after controlled Azure App Service restart.' });
          }
        }
      } catch (err) {
        logIncident({ useCaseId: useCase.id, solution: useCase.title, level: 'auto_restart_failed', severity: 'urgent', actionRequired: true, message: `Automatic restart failed: ${err.message}` });
      }
    }
  }

  // A retry may have surfaced the Azure stopped page where the first attempt
  // saw a transient failure. Keep that distinct from access restriction.
  if (result.appStopped) {
    const record = {
      id: useCase.id,
      title: useCase.title,
      launchUrl: useCase.launchUrl,
      status: 'stopped',
      lastChecked: new Date().toISOString(),
      latencyMs: result.latencyMs ?? null,
      statusCode: result.statusCode ?? null,
      consecutiveFailures: (prev?.status === 'stopped' ? (prev?.consecutiveFailures || 0) : 0) + 1,
      lastError: { errorType: result.errorType, errorMessage: result.errorMessage, statusCode: result.statusCode ?? null },
      errorSeverity: 'critical',
      actionRequired: true,
      remediation: 'Start Azure App Service',
      autoFixAttempts,
      lastNotification: prev?.lastNotification || null,
      owner: useCase.owner || null,
      ownerEmail: useCase.ownerEmail || null,
    };
    await maybeNotifyOwner(useCase, record, prev);
    healthStore.set(useCase.id, record);
    return record;
  }

  // A retry may have surfaced access-restriction where the first attempt saw
  // a transient error — re-check before falling through to the failure path.
  if (result.authRestricted) {
    const record = {
      id: useCase.id,
      title: useCase.title,
      launchUrl: useCase.launchUrl,
      status: 'restricted',
      lastChecked: new Date().toISOString(),
      latencyMs: result.latencyMs ?? null,
      statusCode: result.statusCode ?? null,
      consecutiveFailures: 0,
      lastError: { errorType: result.errorType, errorMessage: result.errorMessage },
      autoFixAttempts,
      lastNotification: prev?.lastNotification || null,
      owner: useCase.owner || null,
      ownerEmail: useCase.ownerEmail || null,
    };
    healthStore.set(useCase.id, record);
    return record;
  }

  const consecutiveFailures = result.ok ? 0 : (prev?.consecutiveFailures || 0) + 1;
  // Re-read the durable latch immediately before the final write. A Log
  // Analytics sweep may have detected a dependency failure while this HTTP
  // probe was in flight; using the latch captured before the probe creates a
  // race where the later HTTP-200 write can overwrite Degraded with Healthy.
  const latestPersistentLatch = getPersistentLatch(useCase.id);
  const latched = latestPersistentLatch || (healthStore.get(useCase.id)?.dependencyIncidentLatched ? healthStore.get(useCase.id) : null) || (prev?.dependencyIncidentLatched ? prev : null);
  const preserveDegraded = Boolean(result.ok && latched);

  const record = {
    id: useCase.id,
    title: useCase.title,
    launchUrl: useCase.launchUrl,
    status: result.ok ? (preserveDegraded ? 'degraded' : 'active') : 'inactive',
    lastChecked: new Date().toISOString(),
    latencyMs: result.latencyMs ?? null,
    statusCode: result.statusCode ?? null,
    consecutiveFailures,
    lastError: preserveDegraded ? (latched.lastError || prev?.lastError || null) : (result.ok ? null : { errorType: result.errorType, errorMessage: result.errorMessage }),
    errorSeverity: preserveDegraded ? 'critical' : (result.ok ? null : 'critical'),
    actionRequired: preserveDegraded ? true : !result.ok,
    remediation: preserveDegraded ? (latched.remediation || prev?.remediation || 'owner_alert') : (result.ok ? null : (diagnosis.action || 'owner_alert')),
    dependencyHealth: preserveDegraded ? (latched.dependencyHealth || prev?.dependencyHealth || { status: 'unhealthy', failingDependency: latched.lastError?.dependency || 'Application dependency', category: latched.lastError?.category || 'application', lastChanged: latched.detectedAt || new Date().toISOString() }) : null,
    azureErrors: preserveDegraded
      ? ((Array.isArray(latched.azureErrors) && latched.azureErrors.length)
          ? latched.azureErrors.slice(0, 25)
          : (prev?.azureErrors || []))
      : latestAzureErrors.slice(0, 25),
    dependencyIncidentLatched: preserveDegraded,
    autoFixAttempts,
    lastNotification: prev?.lastNotification || null,
    owner: useCase.owner || null,
    ownerEmail: useCase.ownerEmail || null,
  };

  // State transition audit: when availability returns, record recovery instead
  // of leaving only the historical outage/restriction incident in the feed.
  if (result.ok && !preserveDegraded && prev && ['stopped', 'inactive', 'restricted'].includes(prev.status)) {
    logIncident({
      useCaseId: useCase.id,
      solution: useCase.title,
      level: 'resolved',
      severity: 'info',
      actionRequired: false,
      message: `Application recovered automatically: ${prev.status} → Healthy (HTTP ${result.statusCode || 200}).`,
    });
  }

  // UC3: escalate to the owner if the app is still genuinely down after auto-fix retries.
  // Cooldown prevents repeated Azure-native owner alerts for one ongoing outage.
  if (!result.ok) {
    await maybeNotifyOwner(useCase, record, prev);
  }

  healthStore.set(useCase.id, record);
  return record;
}

async function monitorApplicationLogs(useCases, minutes = STATUS_LOG_WINDOW_MINUTES) {
  if (!process.env.AZURE_LOG_ANALYTICS_WORKSPACE_ID) return;

  const targets = useCases.filter(uc => uc.launchUrl);
  if (!targets.length) return;

  try {
    // IMPORTANT ARCHITECTURE CHANGE:
    // Query all mapped frontend/backend resources in one Log Analytics request.
    // The returned telemetry is the source of truth for dependency status.
    // Dedupe is used ONLY for notifications/incidents; it must never suppress
    // health-state reconciliation for an error we have already seen.
    const result = await azureLogs.getErrorsForApplications(targets, minutes, 100);
    const appErrors = result.apps || {};

    for (const useCase of targets) {
      const errors = Array.isArray(appErrors[useCase.id]) ? appErrors[useCase.id] : [];
      const existing = healthStore.get(useCase.id) || {};
      const persistentLatch = getPersistentLatch(useCase.id);
      const previousKeys = processedLogKeysFor(useCase.id);

      const actionableErrors = errors.filter((e) => isActionableSeverity(e.Severity || e.Level));
      // Health state is driven by fresh telemetry, not by every historical row
      // still inside the rolling query window. Complete Error Logs remains raw/history.
      const freshCutoffMs = Date.now() - Math.max(5 * 60 * 1000, LOG_MONITOR_INTERVAL_MS * 2);
      const currentActionableErrors = actionableErrors.filter((e) => {
        const ts = new Date(e.TimeGenerated || 0).getTime();
        return Number.isFinite(ts) && ts >= freshCutoffMs;
      });

      if (currentActionableErrors.length > 0) {
        // Reconcile health from the highest-impact currently observed error, not
        // simply the newest row. This prevents an informational row from masking
        // a critical Azure OpenAI / dependency failure in the same query window.
        const severityRank = { critical: 4, high: 3, medium: 2, low: 1 };
        const ordered = currentActionableErrors.slice().sort((a, b) => {
          const ar = severityRank[normalizeOperationalSeverity(a.Severity || a.Level)] || 0;
          const br = severityRank[normalizeOperationalSeverity(b.Severity || b.Level)] || 0;
          if (br !== ar) return br - ar;
          return new Date(b.TimeGenerated || 0).getTime() - new Date(a.TimeGenerated || 0).getTime();
        });
        const newest = ordered[0];
        const diagnosis = classifyError(
          { errorType: 'azure_log_error', errorMessage: newest.Message },
          [newest]
        );
        diagnosis.severity = normalizeOperationalSeverity(newest.Severity || diagnosis.severity);
        if (diagnosis.dependency) diagnosis.severity = 'critical';
        const current = healthStore.get(useCase.id) || existing;
        const appIsDown = current.status === 'stopped' || current.status === 'inactive';
        const enrichedLastError = {
          errorType: 'azure_log_error',
          errorMessage: newest.Message,
          dependency: diagnosis.dependency || newest.Dependency || null,
          category: diagnosis.category || newest.ErrorCategory || null,
          timeGenerated: newest.TimeGenerated,
          source: newest.Source,
          resourceRole: newest.ResourceRole || null,
          resourceName: newest.ResourceName || null,
        };
        const record = {
          id: useCase.id,
          title: useCase.title,
          launchUrl: useCase.launchUrl,
          status: appIsDown ? current.status : 'degraded',
          lastChecked: current.lastChecked || new Date().toISOString(),
          latencyMs: current.latencyMs ?? null,
          statusCode: current.statusCode ?? null,
          consecutiveFailures: current.consecutiveFailures || 0,
          lastError: enrichedLastError,
          errorSeverity: diagnosis.dependency ? 'critical' : diagnosis.severity,
          actionRequired: true,
          dependencyIncidentLatched: true,
          remediation: diagnosis.action,
          dependencyHealth: {
            status: 'unhealthy',
            failingDependency: diagnosis.dependency || newest.Dependency || 'Application dependency',
            category: diagnosis.category || newest.ErrorCategory || 'application',
            lastChanged: newest.TimeGenerated || new Date().toISOString(),
          },
          owner: useCase.owner || null,
          ownerEmail: useCase.ownerEmail || null,
          lastNotification: current.lastNotification || persistentLatch?.lastNotification || null,
          autoFixAttempts: current.autoFixAttempts || [],
          azureErrors: currentActionableErrors.slice(0, 25),
          telemetryObservedAt: new Date().toISOString(),
          statusSource: 'azure_monitor',
          recoverySuccessCycles: 0,
          lastRecoveryCheckAt: new Date().toISOString(),
        };

        // Persist BEFORE publishing to healthStore so a simultaneous URL probe
        // cannot legitimately conclude "Healthy" from endpoint availability.
        persistDependencyLatch(useCase, record);
        healthStore.set(useCase.id, record);

        // Process only genuinely new rows for incident history / notification.
        // Seen rows still enforce Degraded above on every poll.
        for (const log of errors.slice().reverse()) {
          const key = `${log.TimeGenerated}|${log.Source}|${log._ResourceId || ''}|${log.Message}`;
          if (previousKeys.has(key)) continue;
          previousKeys.add(key);
          if (!isActionableSeverity(log.Severity || log.Level)) continue;
          const logDiagnosis = classifyError({ errorType: 'azure_log_error', errorMessage: log.Message }, [log]);
          logDiagnosis.severity = normalizeOperationalSeverity(log.Severity || logDiagnosis.severity);

          logIncident({
            useCaseId: useCase.id,
            solution: useCase.title,
            level: logDiagnosis.dependency ? 'dependency_error' : 'azure_log_error',
            severity: logDiagnosis.severity,
            actionRequired: true,
            dependency: logDiagnosis.dependency,
            category: logDiagnosis.category,
            message: `${logDiagnosis.dependency ? `${logDiagnosis.dependency} failure` : 'Azure application error'} detected while the app is ${appIsDown ? 'unavailable' : 'reachable'}: ${log.Message}`,
            azureError: log,
            remediation: logDiagnosis.action,
          });
        }

        // Notification cooldown is handled inside maybeNotifyOwner. Calling it
        // after reconciliation keeps state and alerting independent.
        await maybeNotifyOwner(useCase, record, current);
      } else if (persistentLatch || (existing.status === 'degraded' && existing.dependencyIncidentLatched)) {
        // Automatic recovery: a historical incident must not keep an application
        // Degraded forever. Require repeated successful availability checks AND
        // repeated Log Analytics cycles with no currently actionable evidence.
        const latch = persistentLatch || existing;
        const availabilityHealthy = existing.status !== 'stopped' && existing.status !== 'inactive' &&
          (existing.statusCode == null || (Number(existing.statusCode) >= 200 && Number(existing.statusCode) < 400));
        const recoverySuccessCycles = availabilityHealthy ? Number(latch.recoverySuccessCycles || 0) + 1 : 0;

        if (availabilityHealthy && recoverySuccessCycles >= RECOVERY_SUCCESS_CYCLES) {
          clearPersistentLatch(useCase.id);
          const recovered = {
            ...existing,
            id: useCase.id,
            title: useCase.title,
            launchUrl: useCase.launchUrl,
            status: 'active',
            consecutiveFailures: 0,
            lastError: null,
            errorSeverity: null,
            actionRequired: false,
            remediation: null,
            dependencyHealth: null,
            dependencyIncidentLatched: false,
            azureErrors: [],
            recoverySuccessCycles: 0,
            statusSource: 'automatic_recovery',
            lastChecked: new Date().toISOString(),
          };
          healthStore.set(useCase.id, recovered);
          logIncident({
            useCaseId: useCase.id,
            solution: useCase.title,
            level: 'resolved',
            severity: 'info',
            actionRequired: false,
            message: `Application automatically recovered after ${RECOVERY_SUCCESS_CYCLES} consecutive healthy availability/log cycles. Previous degraded dependency incident cleared.`,
          });
        } else {
          const retained = {
            ...existing,
            id: useCase.id,
            title: useCase.title,
            launchUrl: useCase.launchUrl,
            status: (existing.status === 'stopped' || existing.status === 'inactive') ? existing.status : 'degraded',
            actionRequired: true,
            dependencyIncidentLatched: true,
            lastError: latch.lastError || existing.lastError || null,
            errorSeverity: 'critical',
            remediation: latch.remediation || existing.remediation || 'owner_alert',
            dependencyHealth: latch.dependencyHealth || existing.dependencyHealth || {
              status: 'unhealthy',
              failingDependency: latch.lastError?.dependency || 'Application dependency',
              category: latch.lastError?.category || 'application',
              lastChanged: latch.detectedAt || latch.lastError?.timeGenerated || new Date().toISOString(),
            },
            azureErrors: (Array.isArray(latch.azureErrors) && latch.azureErrors.length)
              ? latch.azureErrors.slice(0, 25)
              : (existing.azureErrors || []),
            lastNotification: latch.lastNotification || existing.lastNotification || null,
            recoverySuccessCycles,
            lastRecoveryCheckAt: new Date().toISOString(),
            statusSource: 'recovery_validation',
          };
          persistDependencyLatch(useCase, retained);
          healthStore.set(useCase.id, retained);
        }
      }

      trimProcessedLogKeys(useCase.id, previousKeys);
    }
  } catch (err) {
    logIncident({
      useCaseId: 'platform',
      solution: 'Azure Monitor',
      level: 'log_query_failed',
      severity: 'urgent',
      actionRequired: true,
      message: `Azure error monitor failed: ${err.message}`,
    });
  }
}

function processedLogKeysFor(id) {
  if (!processedLogKeys.has(id)) processedLogKeys.set(id, new Set());
  return processedLogKeys.get(id);
}

function trimProcessedLogKeys(id, set) {
  if (set.size <= 500) return;
  const values = Array.from(set);
  processedLogKeys.set(id, new Set(values.slice(-250)));
}

async function investigateApplication(useCase) {
  // Manual Investigate is a reconciliation action, not only an HTTP probe.
  // Re-check availability AND the current Azure Monitor evidence. Historical
  // rows remain in Complete Error Logs, but they must not keep the live status
  // degraded when the application is reachable and no actionable event is
  // present in the current monitoring window.
  const probe = await runCheck(useCase);

  if (!process.env.AZURE_LOG_ANALYTICS_WORKSPACE_ID) return probe;

  try {
    const result = await azureLogs.getErrorsForApplications([useCase], STATUS_LOG_WINDOW_MINUTES, 100);
    const errors = Array.isArray(result.apps?.[useCase.id]) ? result.apps[useCase.id] : [];
    const freshCutoffMs = Date.now() - Math.max(5 * 60 * 1000, LOG_MONITOR_INTERVAL_MS * 2);
    const currentActionable = errors.filter((e) => {
      if (!isActionableSeverity(e.Severity || e.Level)) return false;
      const ts = new Date(e.TimeGenerated || 0).getTime();
      return Number.isFinite(ts) && ts >= freshCutoffMs;
    });

    // If fresh evidence still exists, use the normal monitor reconciliation so
    // the application remains Degraded with the actual current evidence.
    if (currentActionable.length) {
      await monitorApplicationLogs([useCase], STATUS_LOG_WINDOW_MINUTES);
      return healthStore.get(useCase.id) || probe;
    }

    const current = healthStore.get(useCase.id) || probe;
    const reachable = current.status !== 'stopped' && current.status !== 'inactive' && current.status !== 'monitoring_error' &&
      (current.status === 'restricted' || current.statusCode == null || (Number(current.statusCode) >= 200 && Number(current.statusCode) < 400));

    if (reachable) {
      const previous = getPersistentLatch(useCase.id) || current;
      clearPersistentLatch(useCase.id);
      const recoveredStatus = current.status === 'restricted' ? 'restricted' : 'active';
      const recovered = {
        ...current,
        status: recoveredStatus,
        consecutiveFailures: 0,
        lastError: recoveredStatus === 'restricted' ? current.lastError : null,
        errorSeverity: null,
        actionRequired: false,
        remediation: null,
        dependencyHealth: null,
        dependencyIncidentLatched: false,
        azureErrors: [],
        recoverySuccessCycles: 0,
        statusSource: 'manual_investigation_recovery',
        lastChecked: new Date().toISOString(),
      };
      healthStore.set(useCase.id, recovered);
      if (previous?.dependencyIncidentLatched || previous?.status === 'degraded') {
        logIncident({
          useCaseId: useCase.id,
          solution: useCase.title,
          level: 'resolved',
          severity: 'info',
          actionRequired: false,
          message: 'Investigation verified recovery: application is reachable and no current actionable Azure Monitor dependency/error evidence remains. Historical evidence is retained in Complete Error Logs.',
        });
      }
      return recovered;
    }

    return current;
  } catch (err) {
    // A Log Analytics query failure must not falsely clear an existing incident.
    return healthStore.get(useCase.id) || probe;
  }
}

async function runCheckAll(useCases) {
  // Guard against an overlapping sweep: if the background timer and a manual
  // "Check All" (or two manual clicks) land at the same time, the second
  // caller just waits for the first sweep's results instead of kicking off
  // a second full pass — each individual runCheck() is already re-entrancy
  // safe per-id, but this avoids duplicating the *whole* sequential sweep.
  if (sweepInFlight) {
    while (sweepInFlight) {
      // eslint-disable-next-line no-await-in-loop
      await sleep(200);
    }
    return getHealthSnapshot(useCases);
  }

  sweepInFlight = true;
  try {
    const targets = useCases.filter((uc) => uc.launchUrl);
    // Probe the catalog concurrently: serial probing made the UI wait behind
    // every prior app (including timeout/retry delays), often several minutes.
    // Per-app in-flight guards still prevent duplicate checks.
    return await Promise.all(targets.map((uc) => runCheck(uc)));
  } finally {
    sweepInFlight = false;
  }
}

function getHealthSnapshot(useCases) {
  const persistent = readPersistentLatches();
  return useCases
    .filter((uc) => uc.launchUrl)
    .map((uc) => {
      const current = healthStore.get(uc.id) || {
        id: uc.id, title: uc.title, launchUrl: uc.launchUrl,
        status: 'checking', lastChecked: null, latencyMs: null, statusCode: null,
        consecutiveFailures: 0, lastError: null, errorSeverity: null, actionRequired: false, remediation: null, dependencyHealth: null, azureErrors: [], autoFixAttempts: [], lastNotification: null,
        owner: uc.owner || null, ownerEmail: uc.ownerEmail || null,
      };
      const latch = persistent[uc.id]?.active ? persistent[uc.id] : null;
      if (!latch || current.status === 'stopped' || current.status === 'inactive') return current;

      // Current recovered state is authoritative. Once recovery validation has
      // cleared dependencyIncidentLatched/actionRequired, a stale persisted
      // latch must never re-degrade the application on the next snapshot.
      if (current.status === 'active' && current.dependencyIncidentLatched === false && current.actionRequired === false) {
        clearPersistentLatch(uc.id);
        return {
          ...current,
          lastError: null,
          errorSeverity: null,
          remediation: null,
          dependencyHealth: null,
          azureErrors: [],
        };
      }
      return {
        ...current,
        status: 'degraded',
        actionRequired: true,
        dependencyIncidentLatched: true,
        lastError: latch.lastError || current.lastError,
        errorSeverity: (latch.dependencyHealth?.status === 'unhealthy' || current.dependencyHealth?.status === 'unhealthy' || latch.status === 'degraded') ? 'critical' : (latch.errorSeverity || current.errorSeverity || 'high'),
        remediation: latch.remediation || current.remediation || 'owner_alert',
        dependencyHealth: latch.dependencyHealth || current.dependencyHealth || {
          status: 'unhealthy',
          failingDependency: latch.lastError?.dependency || 'Application dependency',
          category: latch.lastError?.category || 'application',
          lastChanged: latch.detectedAt || new Date().toISOString(),
        },
        azureErrors: (Array.isArray(latch.azureErrors) && latch.azureErrors.length)
          ? latch.azureErrors.slice(0, 25)
          : (current.azureErrors || []),
        lastNotification: latch.lastNotification || current.lastNotification || null,
      };
    });
}

function getIncidents(limit = 50) {
  const persistent = readPersistentLatches();
  return incidentLog.slice(0, limit).map((incident) => {
    const latch = incident?.useCaseId ? persistent[incident.useCaseId] : null;
    const current = incident?.useCaseId ? healthStore.get(incident.useCaseId) : null;
    const criticalDependency = Boolean(
      (latch?.active && latch?.status === 'degraded' && (latch?.dependencyHealth?.status === 'unhealthy' || latch?.dependencyIncidentLatched !== false)) ||
      (current?.status === 'degraded' && current?.dependencyHealth?.status === 'unhealthy')
    );
    return criticalDependency
      ? { ...incident, severity: 'critical', actionRequired: true }
      : incident;
  });
}

/** Kick off periodic background monitoring. Returns a stop() function. */
function startMonitoring(useCases, intervalMs = Math.max(15000, Number(process.env.HEALTH_CHECK_INTERVAL_MS) || 30000)) {
  // Availability sweep every 30 seconds by default; Azure dependency/error logs
  // are checked on their configured interval to surface degraded states promptly.
  const kickoff = setTimeout(async () => {
    // Rehydrate dependency incidents before the first availability sweep so a
    // freshly deployed worker cannot publish a transient all-Healthy snapshot.
    await monitorApplicationLogs(useCases, INCIDENT_REHYDRATE_WINDOW_MINUTES);
    await runCheckAll(useCases);
  }, 3000);
  const healthInterval = setInterval(async () => {
    await runCheckAll(useCases);
  }, intervalMs);
  const logInterval = setInterval(async () => {
    await monitorApplicationLogs(useCases);
  }, LOG_MONITOR_INTERVAL_MS);
  return () => {
    clearTimeout(kickoff);
    clearInterval(healthInterval);
    clearInterval(logInterval);
  };
}

module.exports = {
  runCheck,
  investigateApplication,
  runCheckAll,
  getHealthSnapshot,
  getIncidents,
  startMonitoring,
  // Exported for deterministic integration tests/diagnostics.
  monitorApplicationLogs,
};

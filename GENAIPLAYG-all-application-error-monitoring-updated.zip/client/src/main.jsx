import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'

// Entra/MSAL is intentionally NOT initialized here.
// Authentication belongs only to the Admin route so a missing/misconfigured
// Admin registration can never block Business Journey, Use-Cases or other tabs.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

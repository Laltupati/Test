export function timeAgo(iso) {
  if (!iso) return 'Never checked';
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export function statusBadge(status) {
  if (status === 'active') return { cls: 'ad-badge-ok', label: 'Healthy', dot: '●' };
  if (status === 'degraded') return { cls: 'ad-badge-degraded', label: 'Degraded', sub: 'Application reachable · dependency/error detected' };
  if (status === 'restricted') return { cls: 'ad-badge-restricted', label: 'Healthy · Restricted', sub: 'Reachable · authentication / access restricted' };
  if (status === 'stopped') return { cls: 'ad-badge-down', label: 'Stopped · HTTP 403', sub: 'Azure App Service stopped' };
  if (status === 'inactive') return { cls: 'ad-badge-down', label: 'Down' };
  if (status === 'monitoring_error') return { cls: 'ad-badge-warn', label: 'Monitoring Error', sub: 'Health checker could not reach/resolve endpoint' };
  if (status === 'checking') return { cls: 'ad-badge-warn', label: 'Checking…' };
  return { cls: 'ad-badge-unknown', label: 'Unknown' };
}

export function incidentSeverity(level, severity) {
  const explicit = String(severity || '').toLowerCase();
  if (['critical', 'urgent', 'fatal'].includes(explicit)) return { label: 'Critical', cls: 'ad-sev-critical' };
  if (explicit === 'high') return { label: 'High', cls: 'ad-sev-high' };
  if (['medium', 'warning'].includes(explicit)) return { label: 'Warning', cls: 'ad-sev-warning' };
  if (explicit === 'low') return { label: 'Info', cls: 'ad-sev-info' };
  switch (level) {
    case 'error': case 'dependency_error': case 'azure_log_error': case 'notify_failed':
      return { label: 'Critical', cls: 'ad-sev-critical' };
    case 'stopped':
      return { label: 'Critical', cls: 'ad-sev-critical' };
    case 'auto_fix': case 'notify_pending': case 'notify_suppressed':
      return { label: 'Warning', cls: 'ad-sev-warning' };
    case 'notify_sent':
      return { label: 'High', cls: 'ad-sev-high' };
    case 'restricted':
      return { label: 'Info', cls: 'ad-sev-info' };
    default:
      return { label: 'Info', cls: 'ad-sev-info' };
  }
}

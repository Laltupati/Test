const toolDetails = {
  "proscreener": {
    title: "Proscreener",
    overview:
      "Pro Screener is an AI-powered resume screening application designed to streamline and accelerate the hiring process by identifying the most suitable candidates for a given role. Pro Screener allows users to upload a job description file along with multiple candidate resumes, then intelligently compares each resume against the job requirements. The application analyzes candidate profiles based on key hiring criteria such as Experience, Average Score, Big 4 Experience, and Resume to Job Description Comparison, helping recruiters and hiring teams quickly shortlist top talent with greater consistency and efficiency",
    capabilities: [
      "Job Description Based Screening & Match Analysis: Evaluates resumes against uploaded job descriptions, highlighting alignment with role requirements and identifying the best fit candidates.",

      "Bulk Resume Processing & AI Assessment: Screens multiple resumes simultaneously, analyzing skills, qualifications, experience, and overall suitability for the role.",

      "Experience Evaluation & Candidate Scoring: Assesses candidate experience levels and generates weighted scores based on job description alignment and screening criteria.",

      "Advanced Candidate Insights: Identifies Big 4 experience and provides comparison-driven insights to support faster filtering, prioritization, and shortlisting decisions."
    ]
  },

  "natural-language-data-querying": {
    title: "Reimagine AI Analyst",

    overview:
      "Reimagine AI Analyst enables investment teams to analyze fund, sales, and performance data using natural language questions. It uncovers trends and root causes through evidence based analysis and transparent reasoning. The platform automatically generates charts, dashboards, KPIs, and executive ready reports to accelerate decision making.",

    capabilities: [
      "Multi-Dimensional Investigation: Analyzes fund, sales, channel, territory, and organizational data to uncover patterns, trends, and root causes.",

      "Intelligent Insights & Reasoning: Delivers persona-aware, evidence-backed insights through hypothesis testing, transparent reasoning, and auditable citations.",

      "AI Powered Analytics: Automatically generates charts, KPIs, dashboards, and visualizations while applying governed business definitions for consistent interpretation.",

      "Reusable Reporting & Dashboards: Creates reusable dashboards and executive-ready reports with embedded analysis for leadership and client decision making."
    ]
  },

  // "bank-complaint-automation": {
  //   title: "Bank Complaint Automation",
  //   overview:
  //     "TD Bank Complaints Management Assistant is an AI-powered complaints management solution designed to streamline and automate the end-to-end customer complaints handling process. The application enables users to capture key complaint metadata such as Bank Name, Date, Customer Name, Communication Channel, State, Product, Associated Product, Business Line, Business Unit, Level 3, and Level 4 classification. Users can enter the customer complaint details in the Customer Verbatim field, after which the assistant analyzes the complaint and supports faster complaint review, classification, routing, and resolution. By combining structured complaint data with AI-driven analysis, the solution helps banking teams manage complaints more consistently, efficiently, and accurately.",
  //   capabilities: [
  //     "Complaint Intake Management: Allows users to capture customer complaint information through a structured interface, including customer details, communication channel, product information, and complaint classification fields.",
  //     "Metadata Capture: Records important complaint metadata such as bank name, date, customer name, state, product, associated product, business line, business unit, and complaint category levels.",
  //     "Product and Service Classification: Supports classification of complaints based on banking products such as checking accounts, savings accounts, payment services, and related sub-products",
  //     "Complaint Categorization: Helps organize complaints using hierarchical classification levels such as Level 3 and Level 4, enabling better tracking and reporting of complaint types."
  //   ]
  // },

  // "archi-made-easy": {
  //   title: "Archi-Made-Easy",
  //   overview:
  //     "Archi-Made-Easy is an AI-powered architecture analysis assistant designed to support technology architects, consultants, and solution design teams in understanding complex architectural visuals with greater speed and clarity. Archi-Made-Easy uses generative AI models to analyze, compare, and decipher complex architectural images. The application acts as a digital buddy for architects by helping interpret architecture diagrams, identify key components, understand relationships between systems, and simplify technical visuals into meaningful insights. Since the application currently includes a single video, it can be positioned as a focused demonstration or guided walkthrough that showcases how AI can assist in architectural understanding and decision-making. ",
  //   capabilities: [
  //     "Architecture Image Analysis: Analyzes complex architectural diagrams and helps users understand the systems, components, layers, and relationships represented in the visual.",
  //     "Generative AI-Powered Interpretation: Uses generative AI models to decipher architecture images and convert complex technical visuals into easier-to-understand explanations.",
  //     "Architectural Comparison Support: Supports comparison of architectural images or patterns to help users identify similarities, differences, gaps, or design variations.",
  //     "Diagram Deciphering: Helps break down dense architecture diagrams into simpler explanations by identifying key elements such as applications, services, integrations, infrastructure layers, and data flows.",
  //     "Consultant and Architect Assistance: Acts as a companion tool for technology architects and consultants by reducing the time required to review and interpret technical architecture visuals.",
  //     "Simplified Architecture Understanding: Transforms complex architecture content into concise, readable insights, making architectural designs easier to communicate with technical and business stakeholders.",
  //     "Visual Knowledge Extraction: Extracts meaningful information from architecture images, helping users understand design intent, dependencies, and possible architectural considerations.",
  //     "Architecture Review Enablement: Assists in reviewing architectural diagrams by highlighting important components and supporting better design discussions.",
  //     "Single Video-Based Experience: Provides a focused video-based experience or demonstration that showcases the application’s capabilities and guides users through its intended usage.",
  //     "Faster Decision Support: Helps architecture and consulting teams accelerate analysis, comparison, and understanding of solution designs, supporting faster and more informed decision-making."
  //   ]
  // },

  "pro-manager": {
    title: "Pro-Manager",
    overview:
      "PAM is an AI and GenAI-powered project management solution designed to support project teams across the full engagement lifecycle. It helps automate planning, reporting, financial tracking, agile delivery, meeting support, documentation, and change management activities.",
    capabilities: [
      "Project Planning & Delivery: Supports project initiation, planning, resource alignment, agile delivery, sprint management, and execution tracking across the engagement lifecycle.",

      "Monitoring & Reporting: Provides real-time project health insights, progress tracking, risk and issue management, and automated management reporting.",

      "Financial & Performance Management: Enhances oversight of budgets, revenue, costs, pricing, staffing mix, margins, and overall engagement profitability.",

      "Productivity & Change Enablement: Streamlines meetings, documentation, action tracking, communications, and organizational change impact assessment."
    ]
  },

  "qualiverse-ai": {
    title: "QualiVerse AI",
    overview:
      "QualiVerse AI is an enterprise AI-initiatives directory and dashboard that gives leadership and delivery teams a single place to see every internal AI project. It tracks each initiative across its lifecycle stage (Concept, Dev, or Live), and lets users tag, filter, and search projects by business area, technology, or owner. A split-screen viewer opens alongside each project so reviewers can inspect its architecture diagram, watch a recorded demo, and read supporting documentation without leaving the dashboard.",
    capabilities: [
      "Lifecycle Tracking: Records the stage of every internal AI initiative (Concept \u2192 Dev \u2192 Live) so leadership can see portfolio progress at a glance.",

      "Tagging & Filtering: Organizes initiatives with business-area, technology, and ownership tags, making it fast to find related or comparable projects.",

      "Split-Screen Project Viewer: Opens each project's architecture diagram, video demo, and documentation side by side for quick review.",

      "Portfolio Visibility: Gives stakeholders a consolidated, searchable directory of AI initiatives across the organization, reducing duplicate effort and improving governance."
    ]
  },

  "resume-creator": {
    title: "Resume Creator",
    overview:
      "Resume Creator is an AI powered document processing tool designed to streamline and standardize the creation of professional profile slides from resumes in PDF, Word, or PowerPoint formats. The tool enables users to automatically extract key professional details and convert them into a consistent, branded, presentation-ready profile slide, significantly reducing manual formatting effort and improving accuracy and uniformity across organizational deliverables.",
    capabilities: [
      "Multi-Format Resume Processing: Supports PDF, Word, and PowerPoint resumes, enabling seamless upload and automated profile extraction.",

      "Automated Information Extraction: Identifies and captures key professional details, including summary, skills, education, specialization, and engagement experience.",

      "AI Powered Profile Generation: Structures unstructured resume content into standardized, branded, presentation-ready profile slides aligned with organizational templates.",

      "Rapid & Accurate Output: Produces polished profile slides within seconds, improving consistency, accuracy, and reducing manual formatting effort."
    ]
  },

  // "tom-asset-comparisons": {
  //   title: "Tom Asset Comparisons",
  //   overview:
  //     "Tom Asset Comparisons is an automated comparison tool designed to simplify the review of security controls and role‑based process flows within Target Operating Model assessments. By allowing users to upload Source and Target files, the tool highlights differences across asset classes and provides a structured way to evaluate how operating models align. This helps teams complete TOM comparisons more efficiently, maintain consistency in assessments, and reduce the time spent on manual file reviews",
  //   capabilities: [
  //     " Automated File Comparison: Allows users to upload Source and Target files for side‑by‑side comparison of security controls and process flows.",
  //     "Security Control Matching: Automatically analyzes, compares, and maps security controls across asset classes to highlight gaps and alignment issues.",
  //     "Process Flow Evaluation: Supports L1–L4 role‑based process flow comparisons using the Source file as the reference model for assessment.",
  //     "Standardized Format Compliance: Ensures uploaded files adhere to approved formats (such as ARIS), enabling accurate and structured comparisons.", 
  //     "End‑to‑End Analysis Automation: Reduces manual review effort by processing and generating comparison insights, even for large and complex TOM files.",
  //     "Scalable Performance: Handles large input files with processing windows typically ranging from 1–2 hours, depending on file size and complexity."
  //   ]
  // },

  // "financial-outlook-generator": {
  //   title: "Financial Outlook Generator",
  //   overview:
  //     "Financial Outlook Generator is an AI‑assisted reporting tool designed to help teams create comprehensive financial and market outlook documents. By combining user inputs with AI‑generated insights, the tool produces structured reports that summarize market trends, highlight key economic indicators, and present forward‑looking perspectives. This enables teams to develop consistent, well‑organized outlook reports while reducing the time and effort typically required for research and manual drafting.",
  //   capabilities: [
  //     "Automated Report Generation: Creates structured financial and market outlook reports based on user inputs and AI‑supported analysis.",
  //     "Trend & Indicator Analysis: Summarizes relevant market movements, economic indicators, and thematic trends in a clear, organized format.", 
  //     "Insight‑Driven Narratives: Produces readable, cohesive narratives that help teams communicate strategic viewpoints effectively.",
  //     "Customizable Sections: Allows users to tailor report focus areas such as macroeconomic trends, sector insights, and market expectations.", 
  //     "Consistent Output Format: Generates reports following a uniform structure, helping maintain alignment across teams and use cases.",
  //     "Time‑Saving Workflow: Reduces the effort involved in manual data interpretation, drafting, and formatting while preserving report quality."
  //   ]
  // },

  // "power-bi-publication-scoreboard": {
  //   title: "Power BI Publication Scoreboard",
  //   overview:
  //     "Power BI Publication Scoreboard is an analytics dashboard designed to track and visualize the performance of internal Power BI publications and marketing communications. The tool consolidates publication activity, consumer engagement, usage patterns, and template correlation into a single interactive workspace, helping teams monitor trends and assess the effectiveness of their content. This enables stakeholders to maintain visibility on publication output, understand audience behavior, and support data‑driven decisions for improving marketing and communication strategies.",
  //   capabilities: [
  //     " Publication Performance Tracking: Displays year‑to‑date publication metrics, consumer counts, and exhibit usage to show overall content activity.",
  //     "Audience & Distribution Insights: Highlights who consumes the publications and how they are distributed across channels such as email, web, and print.", 
  //     "Trend Visualization: Presents visual trends over time, including monthly usage patterns and shifts in publication activity.",
  //     "Template Correlation Analysis: Compares publication templates to identify similarities, usage patterns, and alignment across content types.", 
  //     "Interactive Power BI Dashboard: Provides an intuitive interface with filters, drill‑downs, and subject‑based navigation for detailed analysis.", 
  //     "Centralized Reporting View: Consolidates key marketing metrics in one place to support regular reporting and informed decision‑making."
  //   ]
  // },

  "augmented-insights-discovery": {
    title: "Augmented Insights and Discovery Engine",
    overview:
      "Augmented Insights & Discovery Engine (AIDE) is an AI-powered advisor search and analytics platform that combines advisor biographies with sales and asset data using HybridGraphRAG, LLMs, and NLP. It enables natural language search, comparison, and analysis across advisor's skills, geography and experience. The platform delivers grounded insights, context aware conversations, and demographic and comparative analytics through intelligent query routing.",
    capabilities: [
      "Natural Language Search & Discovery: Enables users to find and analyze financial advisors using conversational queries across certifications, skills, specialization, geography, and experience.",

      "HybridGraphRAG Intelligence: Combines unstructured advisor biographies with structured sales and asset data to deliver accurate, grounded, and relevant results.",

      "Context Aware Analysis & Comparison: Supports follow-up questions, advisor comparisons, and multidimensional analysis across expertise, credentials, location, and experience.",

      "Insight Generation & Query Routing: Produces summaries, trends, demographic and geographic insights while intelligently routing queries for the most relevant response."
    ]
  },

  "kpmg-agenda-creator": {
    title: "KPMG Agenda Creator",
    overview:
      "The KPMG Agenda Creator is a standalone AI powered tool that helps Sales Managers build personalized meeting agendas for financial advisors. It uses a multi-agent pipeline to analyze advisor profile data, AUM and sales metrics, portfolio composition, meeting history, engagement signals, and supporting product or article content, then synthesizes these inputs into a structured agenda. The application supports both Auto Mode, where relevant funds and articles are selected automatically, and Manual Mode, where users can guide the selection process. The final output includes advisor context, portfolio insights, recent meeting themes, recommendations, action items, and visual portfolio summaries, with options to export or share the agenda.",
    capabilities: [
      "Advisor Intelligence & Context Retrieval: Analyzes advisor profiles, AUM, sales performance, portfolio composition, engagement history, and meeting context.",

      "Multi-Agent AI Agenda Creation: Uses specialized AI agents to evaluate advisor data, meeting insights, recommendations, and agenda content.",

      "Automated & Guided Planning: Supports both Auto Mode and Manual Mode for agenda creation, fund selection, and article recommendations.",

      "Meeting Insights & Output Generation: Produces structured agendas with portfolio analysis, key discussion themes, recommendations, action items, visual summaries, and export options."
    ]
  },

  "advisor-intelligence": {
    title: "Advisor Intelligence",
    overview:
      "Advisor Intelligence is an AI-powered platform that streamlines advisor engagement and pre-meeting preparation by combining advisor profiles, portfolio data, relationship history, fund analytics, and market intelligence. It delivers advisor fund fit analysis, opportunity prioritization, personalized pitches, meeting briefs, and at risk relationship alerts. Powered by a multi-agent architecture and Neo4j knowledge graph, it provides structured, context aware insights for more effective advisor conversations.",
    capabilities: [
      "Advisor Fund Intelligence & Prioritization: Evaluates advisor suitability for specific funds and identifies high value opportunities using portfolio, relationship, sentiment, and AUM insights.",

      "Personalized Engagement Recommendations: Generates tailored pitch scripts, talking points, objection handling guidance, and follow up messaging for advisor interactions.",

      "AI Powered Meeting Preparation: Creates comprehensive pre-meeting briefs by combining advisor context, historical interactions, fund analytics, and live market intelligence.",

      "Relationship Risk Monitoring & Knowledge Graph Intelligence: Detects at-risk advisor relationships and leverages graph-based data with multi-agent AI orchestration to deliver actionable, context-aware insights."
    ]
  },

  "synthdataforge": {
    title: "SynthDataForge",
    overview:
      "SynthDataForge is an AI powered synthetic data platform that creates realistic, privacy safe datasets for testing, analytics, demos, and AI development while preserving data quality, business rules, and relationships. It streamlines the entire synthetic data lifecycle from generation and validation to export and governance.",
    capabilities: [
      "Schema & Relationship Modeling: Builds synthetic data schemas manually, from templates, or uploaded files while maintaining table relationships and dependency structures.",

      "Hybrid Data Generation Engine: Combines LLM/SmartMock, Faker, and SDV technologies to generate realistic, scalable, and privacy-safe multi-table datasets.",

      "Data Integrity & Quality Assurance: Preserves referential integrity, validates parent-child relationships, and provides quality analysis with dataset previews and metrics.",

      "End-to-End Data Operations: Supports configurable generation controls, export-ready outputs, monitoring, and AI-assisted querying for efficient synthetic data workflows."
    ]
  }
};

export default toolDetails;
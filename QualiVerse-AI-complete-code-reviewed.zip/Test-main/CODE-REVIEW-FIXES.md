# QualiVerse AI – code package notes

This package is based on the supplied `Test-main (5).zip` source. Existing application structure, UI, API routes, database models, and deployment targets are retained.

## Included deployment corrections

- Raised the minimum `pydantic-settings` version to 2.4.0 and constrained it below 3.0.0. The backend uses `NoDecode` for `CORS_ORIGINS`; older dependency resolution could install a version that does not support this behaviour consistently.
- Added backend bytecode compilation to the GitHub Actions deployment workflow before packaging.
- Added build output for the commit SHA and the packaged `app/core/config.py` tail so the deployed artifact can be compared with Kudu `/home/site/wwwroot/app/core/config.py`.

## Important deployment checks

1. Deploy this package through the intended pipeline and verify the pipeline commit SHA.
2. In Kudu, run `nl -ba /home/site/wwwroot/app/core/config.py | tail -n 20` and compare the `settings = Settings()` line with the packaged source.
3. Keep `CORS_ORIGINS` as a valid JSON array or comma-separated list of exact frontend origins. Do not include quotes around the entire value in the Azure App Setting editor.
4. Confirm the App Service runtime, Terraform runtime, and Docker runtime are intentionally aligned before changing the runtime version. The supplied project currently contains Python 3.11 deployment definitions while the previously shared App Service log showed Python 3.13.18.
5. The GitHub callback currently accepts a caller-supplied email when OAuth does not return a verified identity. This is a security risk and must be replaced with a verified SSO/OAuth identity flow before production use. This package does not silently change that login experience.
6. Production JWT and database credentials must be supplied through secure App Settings/Key Vault references. Do not rely on the sample fallback credentials in the source.

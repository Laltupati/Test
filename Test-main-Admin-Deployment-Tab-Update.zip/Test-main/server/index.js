const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { useCases, systemHealth, monitoringData, executionStats } = require('./data');
const adminHealth = require('./adminHealth');
const costMetrics = require('./costMetrics');
const azureLogs = require('./azureLogs');
const { requireEntraAuth, allowedEmailsCount } = require('./entraAuth');

const app = express();

// Deployment source intake: ZIP uploads are quarantined as opaque files. They are
// never extracted or executed by the Admin Panel process. Pipeline scanning and
// deployment remain separate, isolated Azure DevOps jobs.
const DEPLOY_UPLOAD_LIMIT_BYTES = Math.max(1, Number(process.env.DEPLOY_UPLOAD_LIMIT_MB || 25)) * 1024 * 1024;
const DEPLOY_QUARANTINE_DIR = process.env.DEPLOY_QUARANTINE_DIR || path.join(os.tmpdir(), 'genai-admin-deployment-quarantine');
const deploymentUploads = [];
fs.mkdirSync(DEPLOY_QUARANTINE_DIR, { recursive: true, mode: 0o700 });
const uploadExpiryMs = Math.max(1, Number(process.env.DEPLOY_UPLOAD_RETENTION_HOURS || 24)) * 60 * 60 * 1000;
function cleanupDeploymentUploads() {
  const cutoff = Date.now() - uploadExpiryMs;
  for (let i = deploymentUploads.length - 1; i >= 0; i -= 1) {
    const item = deploymentUploads[i];
    if (Date.parse(item.createdAt) < cutoff) {
      try { fs.unlinkSync(item.filePath); } catch { /* already gone */ }
      deploymentUploads.splice(i, 1);
    }
  }
}
setInterval(cleanupDeploymentUploads, 30 * 60 * 1000).unref();
// Azure provides the port via process.env.PORT
const port = process.env.PORT || 3000;

// Initialize mock launches for sorting
useCases.forEach(uc => {
  uc.launches = 0;
});

app.use(cors());
app.use(express.json());

// Admin Panel > Deployment: pipeline readiness and source upload intake.
// This version deliberately does not claim to scan or deploy yet: uploaded source
// is quarantined pending the Azure DevOps pipeline/source handoff integration.
app.get('/api/admin/deployment/readiness', requireEntraAuth, (req, res) => {
  res.set('Cache-Control', 'no-store');
  const adoCredentialsPresent = !!(process.env.AZDO_ORG_URL && process.env.AZDO_PROJECT && process.env.AZDO_PIPELINE_ID && process.env.AZDO_PAT);
  res.json({
    uploadEnabled: true,
    pipelineConfigured: false,
    adoCredentialsPresent: adoCredentialsPresent,
    pipelineIntegration: 'not-integrated',
    sourceTransferConfigured: false,
    scanners: { secretScan: false, sast: false, dependencyScan: false, iacScan: false },
    maxUploadBytes: DEPLOY_UPLOAD_LIMIT_BYTES,
    note: 'Source intake is enabled. Pipeline scanning, source handoff, infrastructure provisioning and deployment are not active until the DevOps integration is implemented and configured.'
  });
});


app.get('/api/admin/deployment/uploads', requireEntraAuth, (req, res) => {
  cleanupDeploymentUploads();
  res.json(deploymentUploads.slice(0, 25).map(({ filePath, ...metadata }) => metadata));
});


app.post('/api/admin/deployment/upload', requireEntraAuth, (req, res) => {
  const declaredSize = Number(req.headers['content-length'] || 0);
  const filename = String(req.headers['x-upload-filename'] || 'application.zip').replace(/[\\/\r\n\0]/g, '_').slice(0, 180);
  const targetEnvironment = String(req.headers['x-target-environment'] || 'DEV').toUpperCase();
  if (!['DEV', 'TEST', 'PROD'].includes(targetEnvironment)) return res.status(400).json({ error: 'Invalid target environment.' });
  if (!filename.toLowerCase().endsWith('.zip')) return res.status(400).json({ error: 'Only ZIP source packages are accepted.' });
  if (declaredSize && declaredSize > DEPLOY_UPLOAD_LIMIT_BYTES) return res.status(413).json({ error: `Upload exceeds ${Math.round(DEPLOY_UPLOAD_LIMIT_BYTES / 1024 / 1024)} MB limit.` });
  const uploadId = crypto.randomUUID();
  const filePath = path.join(DEPLOY_QUARANTINE_DIR, `${uploadId}.zip`);
  const output = fs.createWriteStream(filePath, { flags: 'wx', mode: 0o600 });
  let bytes = 0;
  let firstChunk = Buffer.alloc(0);
  let failed = false;
  const fail = (status, message) => {
    if (failed) return;
    failed = true;
    output.destroy();
    try { fs.unlinkSync(filePath); } catch { /* no file or already removed */ }
    if (!res.headersSent) res.status(status).json({ error: message });
  };
  req.on('data', (chunk) => {
    if (failed) return;
    bytes += chunk.length;
    if (bytes > DEPLOY_UPLOAD_LIMIT_BYTES) return fail(413, `Upload exceeds ${Math.round(DEPLOY_UPLOAD_LIMIT_BYTES / 1024 / 1024)} MB limit.`);
    if (firstChunk.length < 4) firstChunk = Buffer.concat([firstChunk, chunk.subarray(0, 4 - firstChunk.length)]);
  });
  req.on('aborted', () => fail(400, 'Upload was interrupted.'));
  req.pipe(output);
  output.on('error', (err) => fail(500, `Unable to store upload: ${err.message}`));
  output.on('finish', () => {
    if (failed) return;
    // ZIP signatures commonly start PK, PK or PK.
    const isZip = firstChunk.length >= 4 && firstChunk[0] === 0x50 && firstChunk[1] === 0x4b && [0x03, 0x05, 0x07].includes(firstChunk[2]) && [0x04, 0x06, 0x08].includes(firstChunk[3]);
    if (!isZip || bytes === 0) return fail(400, 'The uploaded file does not appear to be a ZIP archive.');
    const record = { uploadId, filename, targetEnvironment, sizeBytes: bytes, createdAt: new Date().toISOString(), intakeStatus: 'quarantined', pipelineStatus: 'not-started', filePath };
    deploymentUploads.unshift(record);
    cleanupDeploymentUploads();
    res.status(201).json({ uploadId, filename, targetEnvironment, sizeBytes: bytes, createdAt: record.createdAt, intakeStatus: record.intakeStatus, pipelineStatus: record.pipelineStatus, message: 'Upload accepted into quarantine. Security scanning and deployment pipeline are not yet connected.' });
  });
});


// Public, non-secret MSAL bootstrap configuration. The browser needs these
// identifiers before it can sign in. Keep secrets/credentials out of this route.
// Environment-specific values let one frontend artifact work in TEST and PROD.
app.get('/api/auth/config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    tenantId: process.env.ENTRA_TENANT_ID || '',
    clientId: process.env.ENTRA_SPA_CLIENT_ID || process.env.ENTRA_CLIENT_ID || process.env.VITE_ENTRA_CLIENT_ID || '',
    apiScope: process.env.ENTRA_API_SCOPE || process.env.VITE_ENTRA_API_SCOPE || '',
    redirectUri: process.env.ENTRA_REDIRECT_URI || process.env.VITE_ENTRA_REDIRECT_URI || '',
  });
});

app.get('/api/use-cases', (req, res) => {
  res.json(useCases);
});

app.post('/api/use-cases/:id/launch', (req, res) => {
  const id = req.params.id;
  const useCase = useCases.find(uc => uc.id === id);
  if (useCase) {
    useCase.launches = (useCase.launches || 0) + 1;
    res.json({ success: true, launches: useCase.launches });
  } else {
    res.status(404).json({ error: 'Use case not found' });
  }
});

app.get('/api/system-health', (req, res) => {
  res.json({
    overview: systemHealth,
    monitoring: monitoringData,
    executionStats: executionStats
  });
});

/* ── Admin tab: real status checks + auto-fix + owner notification ── */
/*    All routes below require a valid Entra ID sign-in (see entraAuth.js). */

// UC1: current status of every use case with a live launchUrl
app.get('/api/admin/health', requireEntraAuth, (req, res) => {
  const apps = adminHealth.getHealthSnapshot(useCases);
  const checkedApps = apps.filter(a => a.lastChecked);
  res.json({
    apps,
    summary: {
      total: apps.length,
      active: apps.filter(a => a.status === 'active').length,
      stopped: apps.filter(a => a.status === 'stopped').length,
      inactive: apps.filter(a => a.status === 'inactive').length,
      checking: apps.filter(a => a.status === 'checking').length,
      avgLatencyMs: checkedApps.length
        ? Math.round(checkedApps.reduce((sum, a) => sum + (a.latencyMs || 0), 0) / checkedApps.length)
        : null,
    },
  });
});

// UC1+2+3 for a single app: re-probe now, auto-fix via retry, notify owner if still down
app.post('/api/admin/health/:id/check', requireEntraAuth, async (req, res) => {
  const useCase = useCases.find(uc => uc.id === req.params.id);
  if (!useCase) return res.status(404).json({ error: 'Use case not found' });
  const record = await adminHealth.investigateApplication(useCase);
  res.json(record);
});

// UC1+2+3 across every app in the catalog
app.post('/api/admin/health/check-all', requireEntraAuth, async (req, res) => {
  const records = await adminHealth.runCheckAll(useCases);
  res.json({ apps: records });
});

// Live feed for the "Active Alerts" panel: detections, auto-fix attempts, resolutions, notifications
app.get('/api/admin/incidents', requireEntraAuth, (req, res) => {
  const limit = Number(req.query.limit) || 50;
  res.json(adminHealth.getIncidents(limit));
});

// Azure Monitor / Log Analytics: errors only, grouped per registered application.
app.get('/api/admin/logs/errors', requireEntraAuth, async (req, res) => {
  try {
    const minutes = Math.min(Math.max(Number(req.query.minutes) || 60, 1), 1440);
    const result = await azureLogs.getErrorsForApplications(useCases.filter(uc => uc.launchUrl), minutes, 50);
    res.json(result);
  } catch (err) {
    res.status(200).json({ configured: true, queryError: true, error: err.message, apps: {} });
  }
});

app.get('/api/admin/logs/errors/:id', requireEntraAuth, async (req, res) => {
  const useCase = useCases.find(uc => uc.id === req.params.id);
  if (!useCase) return res.status(404).json({ error: 'Use case not found' });
  try {
    const minutes = Math.min(Math.max(Number(req.query.minutes) || 60, 1), 31 * 24 * 60);
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
    const range = req.query.start && req.query.end ? { start: req.query.start, end: req.query.end } : null;
    const result = await azureLogs.getErrorsForUseCase(useCase, minutes, limit, range);
    // Operational severity is contextual. If the application currently has a
    // latched, unhealthy dependency that makes the workflow unusable, every
    // error row shown for that incident is escalated to Critical in the admin
    // evidence view. Preserve the raw row severity for diagnostics.
    const health = adminHealth.getHealthSnapshot([useCase])[0];
    // Preserve the live probe result in the detail view even when the target
    // application does not emit HTTP diagnostics (or ingestion is delayed).
    // This is explicitly labeled as monitor evidence, not an Azure log row.
    if (health && Number(health.statusCode) >= 500 && health.lastError) {
      result.errors = Array.isArray(result.errors) ? result.errors : [];
      const alreadyPresent = result.errors.some((row) => String(row.Message || '').includes(`HTTP ${health.statusCode}`));
      if (!alreadyPresent) result.errors.unshift({
        TimeGenerated: health.lastChecked || new Date().toISOString(),
        Source: 'Health Monitor',
        Level: 'Error',
        Severity: 'critical',
        Message: `Live health probe received HTTP ${health.statusCode}: ${health.lastError.errorMessage || 'Application returned a server error'}`,
        _ResourceId: azureLogs.resolveResourceId(useCase),
        ResourceName: useCase.title,
        IsSynthetic: true,
      });
    }
    const criticalDependency = ['degraded', 'inactive'].includes(health?.status) &&
      health?.dependencyHealth?.status === 'unhealthy';
    if (criticalDependency && Array.isArray(result.errors)) {
      result.errors = result.errors.map((row) => ({
        ...row,
        RawSeverity: row.RawSeverity || row.Severity || row.Level || null,
        Severity: 'critical',
        OperationalSeverityReason: `Application is unavailable because of an unresolved ${health.dependencyHealth?.failingDependency || 'dependency'} failure`,
      }));
      result.operationalSeverity = 'critical';
    }
    res.json(result);
  } catch (err) {
    res.status(200).json({ configured: true, queryError: true, error: err.message, errors: [] });
  }
});

// Non-sensitive config summary for the Security & Access / Configuration tabs —
// exposes counts only (never the actual allowlisted emails).
app.get('/api/admin/config', requireEntraAuth, (req, res) => {
  const webhookConfigured = !!(process.env.OWNER_NOTIFICATION_WEBHOOK_URL || process.env.AZURE_NOTIFICATION_WEBHOOK_URL);
  res.json({
    allowedEmailsCount,
    notifications: {
      provider: webhookConfigured ? 'Logic App webhook' : 'Not configured',
      webhookConfigured,
      cc: String(process.env.OWNER_NOTIFICATION_CC || 'laltupati@kpmg.com')
        .split(/[;,]/).map((email) => email.trim()).filter(Boolean),
      smtpRequired: false,
    },
  });
});

// Real Azure spend for "Usage & Cost" and the Overview's Cost & Consumption
// panel. Returns { configured: false } until AZURE_SUBSCRIPTION_ID is set —
// see README-AZURE-COST.md.
app.get('/api/admin/cost', requireEntraAuth, async (req, res) => {
  try {
    const startDate = req.query.start || req.query.startDate || undefined;
    const endDate = req.query.end || req.query.endDate || undefined;
    const force = String(req.query.force || '').toLowerCase() === '1' || String(req.query.force || '').toLowerCase() === 'true';
    res.json(await costMetrics.getCostIntelligence(useCases, { startDate, endDate, force }));
  } catch (err) {
    res.status(500).json({ configured: true, error: err.message });
  }
});

// Background sweep so status is fresh even before anyone opens the Admin tab
adminHealth.startMonitoring(useCases);

// Serve frontend in production (Azure)
const clientBuildPath = path.join(__dirname, '../client/dist');
app.use(express.static(clientBuildPath));

// Catch-all route to serve index.html for Single Page Application routing
app.use((req, res) => {
  res.sendFile(path.join(clientBuildPath, 'index.html'));
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});

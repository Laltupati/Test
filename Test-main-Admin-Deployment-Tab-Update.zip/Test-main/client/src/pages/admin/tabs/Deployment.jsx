import React, { useCallback, useEffect, useMemo, useState } from 'react';

const FLOW = [
  { title: 'Source validation', detail: 'ZIP package and file intake checks', icon: '01' },
  { title: 'Security scan', detail: 'Secrets, SAST, dependencies, IaC and container checks', icon: '02' },
  { title: 'Security gate', detail: 'Remediation, or eligible waiver with audit trail', icon: '03' },
  { title: 'Infrastructure plan', detail: 'Approved Azure templates and what-if preview', icon: '04' },
  { title: 'Provision Azure', detail: 'Scoped resource creation and configuration', icon: '05' },
  { title: 'Build & deploy', detail: 'Build, tests, artifact and release', icon: '06' },
  { title: 'Smoke test', detail: 'Health verification and deployment results', icon: '07' },
];

function formatSize(bytes) {
  if (!Number.isFinite(bytes)) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}


export default function Deployment({ adminFetch }) {
  const [readiness, setReadiness] = useState(null);
  const [history, setHistory] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [environment, setEnvironment] = useState('DEV');
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const [readyRes, historyRes] = await Promise.all([
        adminFetch('/api/admin/deployment/readiness'),
        adminFetch('/api/admin/deployment/uploads'),
      ]);
      if (readyRes.ok) setReadiness(await readyRes.json());
      if (historyRes.ok) setHistory(await historyRes.json());
    } catch (err) {
      setError(err?.message || 'Unable to load deployment configuration.');
    }
  }, [adminFetch]);

  useEffect(() => { refresh(); }, [refresh]);

  const maxBytes = readiness?.maxUploadBytes || 25 * 1024 * 1024;
  const chooseFile = (file) => {
    setMessage('');
    setError('');
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.zip')) return setError('Please upload a ZIP package.');
    if (file.size > maxBytes) return setError(`File exceeds the ${formatSize(maxBytes)} upload limit.`);
    setSelectedFile(file);
  };

  const upload = async () => {
    if (!selectedFile || uploading) return;
    setUploading(true);
    setMessage('');
    setError('');
    try {
      const response = await adminFetch('/api/admin/deployment/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/zip',
          'X-Upload-Filename': selectedFile.name,
          'X-Target-Environment': environment,
        },
        body: selectedFile,
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Upload failed (${response.status}).`);
      setMessage(`${data.filename} uploaded and quarantined successfully. Scanning and deployment are not yet connected.`);
      setSelectedFile(null);
      await refresh();
    } catch (err) {
      setError(err?.message || 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const stats = useMemo(() => ({
    uploads: history.length,
    queued: history.filter((item) => item.pipelineStatus === 'queued').length,
    completed: history.filter((item) => item.pipelineStatus === 'completed').length,
  }), [history]);

  return (
    <div className="ad-deployment-page">
      <div className="ad-page-header">
        <div>
          <h1 className="ad-page-title">Deployment</h1>
          <p className="ad-page-subtitle">Upload source code and initiate the application delivery workflow from this Admin Panel section.</p>
        </div>
        <button type="button" className="ad-deployment-refresh" onClick={refresh} disabled={uploading}>↻ Refresh</button>
      </div>


      <div className="ad-deployment-banner">
        <div className="ad-deployment-banner-icon">⇪</div>
        <div>
          <strong>Infra Deployment + DevSecOps Pipeline</strong>
          <p>Target experience: upload code once, then automated validation, security scans, Azure infrastructure planning, provisioning, build, deployment and post-deployment checks.</p>
        </div>
      </div>


      <div className="ad-deployment-stat-grid">
        <div className="ad-deployment-stat"><span>Source uploads</span><strong>{stats.uploads}</strong><small>Recent quarantined packages</small></div>
        <div className="ad-deployment-stat"><span>Pipeline integration</span><strong className={readiness?.pipelineConfigured ? 'configured' : 'not-configured'}>{readiness?.pipelineConfigured ? 'Configured' : 'Not configured'}</strong><small>Azure DevOps connection status</small></div>
        <div className="ad-deployment-stat"><span>Security scanning</span><strong className="not-configured">Not connected</strong><small>Scan stages pending integration</small></div>
      </div>


      <div className="ad-deployment-main-grid">
        <section className="ad-deployment-card">
          <div className="ad-deployment-card-header">
            <div><h2>Upload Application Source</h2><p>Upload a ZIP source package to the deployment intake.</p></div>
            <span className="ad-deployment-badge">INTAKE</span>
          </div>
          <div
            className={`ad-deployment-dropzone${dragging ? ' dragging' : ''}${selectedFile ? ' has-file' : ''}`}
            onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(event) => { event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files?.[0]); }}
          >
            <div className="ad-deployment-upload-icon">↑</div>
            <strong>Drag and drop your application ZIP here</strong>
            <span>or choose a file from your computer</span>
            <label className="ad-deployment-browse">
              Browse files
              <input type="file" accept=".zip,application/zip" onChange={(event) => chooseFile(event.target.files?.[0])} />
            </label>
            <small>ZIP only · Maximum {formatSize(maxBytes)}</small>
          </div>

          {selectedFile && <div className="ad-deployment-file-chip"><span>▣</span><div><b>{selectedFile.name}</b><small>{formatSize(selectedFile.size)}</small></div><button type="button" aria-label="Remove file" onClick={() => setSelectedFile(null)}>×</button></div>}
          <div className="ad-deployment-options">
            <label htmlFor="deployment-env">Target environment</label>
            <select id="deployment-env" value={environment} onChange={(event) => setEnvironment(event.target.value)}>
              <option value="DEV">Development</option><option value="TEST">Test</option><option value="PROD">Production</option>
            </select>
            <p>Environment selection is recorded in this UI only until the deployment pipeline integration is completed.</p>
          </div>
          <button type="button" className="ad-deployment-upload-button" disabled={!selectedFile || uploading} onClick={upload}>{uploading ? 'Uploading…' : 'Upload source package'}</button>
          {message && <div className="ad-deployment-feedback success" role="status">✓ {message}</div>}
          {error && <div className="ad-deployment-feedback error" role="alert">! {error}</div>}
        </section>


        <section className="ad-deployment-card">
          <div className="ad-deployment-card-header"><div><h2>Automated Workflow</h2><p>Planned end-to-end execution stages</p></div></div>
          <div className="ad-deployment-workflow">
            {FLOW.map((stage, index) => (
              <div className="ad-deployment-stage" key={stage.title}>
                <div className="ad-deployment-stage-number">{stage.icon}</div>
                <div><strong>{stage.title}</strong><span>{stage.detail}</span></div>
                <span className="ad-deployment-stage-state">Pending</span>
              </div>
            ))}
          </div>
        </section>
      </div>


      <section className="ad-deployment-card ad-deployment-history-card">
        <div className="ad-deployment-card-header"><div><h2>Recent Uploads</h2><p>Packages received by the Admin Panel</p></div></div>
        {history.length === 0 ? <div className="ad-deployment-empty">No source packages uploaded yet.</div> : (
          <div className="ad-deployment-history-list">
            {history.map((item) => (
              <div className="ad-deployment-history-row" key={item.uploadId}>
                <div className="ad-deployment-history-icon">ZIP</div>
                <div className="ad-deployment-history-details"><strong>{item.filename}</strong><span>{new Date(item.createdAt).toLocaleString()} · {formatSize(item.sizeBytes)}</span><small>Environment: {item.targetEnvironment || 'DEV'} · Intake: {item.intakeStatus}</small></div>
                <span className="ad-deployment-status-pill pending">Pipeline not started</span>
              </div>
            ))}
          </div>
        )}
      </section>

      <div className="ad-deployment-integration-note"><strong>Integration status:</strong> This code update adds the Deployment navigation, secure ZIP intake and upload history. Azure DevOps source handoff, real security scanner execution, Bicep provisioning, pipeline run tracking, build/deploy and rollback are not wired yet; they are explicitly shown as pending instead of simulated as complete.</div>
    </div>
  );
}

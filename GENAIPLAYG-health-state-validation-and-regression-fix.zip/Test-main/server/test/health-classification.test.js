const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Load the pure classifier without loading Azure SDK dependencies. This tests
// the exact function source used by azureLogs.js while keeping tests offline.
const source = fs.readFileSync(path.join(__dirname, '..', 'azureLogs.js'), 'utf8');
const helperStart = source.indexOf('function resourceNameFromId(');
const helperEnd = source.indexOf('\nfunction buildAppServiceResourceId', helperStart);
const classifierStart = source.indexOf('function classifyLogRow(');
const classifierEnd = source.indexOf('\nfunction consoleErrorWhereClause', classifierStart);
assert.ok(helperStart >= 0 && helperEnd > helperStart);
assert.ok(classifierStart >= 0 && classifierEnd > classifierStart);
const sandbox = { module: { exports: {} } };
vm.runInNewContext(
  `${source.slice(helperStart, helperEnd)}\n${source.slice(classifierStart, classifierEnd)}\nmodule.exports = { classifyLogRow };`,
  sandbox,
);
const { classifyLogRow } = sandbox.module.exports;

function severity(message, sourceName = 'Console', level = 'Error') {
  return classifyLogRow({ Message: message, Source: sourceName, Level: level }).Severity;
}

test('successful npm registry cache-miss fetch is informational even when Azure labels it Error', () => {
  assert.equal(severity('npm http fetch GET 200 https://registry.npmjs.org/ajv/-/ajv-8.18.0.tgz 676ms (cache miss)'), 'low');
});

test('Always On root-path 404 is informational, including structured INFO request logs', () => {
  assert.equal(severity('INFO: 169.254.132.3:50084 - "GET / HTTP/1.1" 404 Not Found ua=AlwaysOn'), 'low');
  assert.equal(severity('2026-11-17 | INFO | resume_generator.request | GET / status=404 ua=AlwaysOn'), 'low');
});

test('ordinary backend root 404 remains visible but does not alone declare outage', () => {
  assert.equal(severity('404 GET /', 'HTTP', 'Warning'), 'low');
});

test('primary application HTTP 5xx remains a high-severity signal', () => {
  assert.equal(severity('503 GET /api/generate', 'HTTP', 'Error'), 'high');
});

test('Azure OpenAI authentication failure is critical dependency evidence', () => {
  assert.equal(severity('Azure OpenAI request failed: HTTP 401 invalid API key', 'Application Insights Dependency', 'Error'), 'critical');
});

test('successful informational dependency trace is not treated as an outage', () => {
  assert.equal(severity('INFO | Azure OpenAI request completed successfully status=200', 'Console', 'Error'), 'low');
});

test('non-fatal application exception is high and can be confirmed across monitoring cycles', () => {
  assert.equal(severity('TypeError: cannot read property from undefined', 'Application Insights Exception', 'Error'), 'high');
});


test('Resume Creator requires its exact configured Azure OpenAI API-key setting', () => {
  const { useCases } = require('../data');
  const resume = useCases.find((item) => item.id === 'resume-creator');
  const group = resume.requiredAppSettingGroups.find((item) => item.name === 'Azure OpenAI API key');
  assert.equal(group.matchMode, 'exact');
  assert.deepEqual(Array.from(group.patterns), ['AZURE_OPENAI_API_KEY']);
  assert.deepEqual(Array.from(group.roles), ['backend']);
});

test('all monitored applications retain the requested owner email', () => {
  const { useCases } = require('../data');
  assert.ok(useCases.length > 0);
  for (const useCase of useCases) {
    assert.equal(useCase.ownerEmail, 'laltupati@kpmg.com', `${useCase.id} owner email`);
  }
});

test('transient Azure OpenAI 503 is high for multi-cycle confirmation, not immediate critical', () => {
  assert.equal(severity('Azure OpenAI request failed: HTTP 503 service unavailable', 'Application Insights Dependency', 'Error'), 'high');
});


// Exercise the actual required-setting validator with mocked ARM responses.
// No setting values are printed or persisted by the production implementation.
const adminSource = fs.readFileSync(path.join(__dirname, '..', 'adminHealth.js'), 'utf8');
const settingsStart = adminSource.indexOf('async function checkRequiredAppSettings(useCase) {');
const settingsEnd = adminSource.indexOf('\nasync function restartApp(useCase)', settingsStart);
assert.ok(settingsStart >= 0 && settingsEnd > settingsStart);

async function runRequiredSettingsCheck({ targets, payload, status = 200, token = true }) {
  const sandbox = {
    module: { exports: {} },
    azureLogs: {
      resolveResourceTargets: () => targets,
      getKeyVaultReferenceErrors: async () => [],
    },
    awaitWithTimeout: async (promise) => promise,
    getAccessToken: async () => token ? ({ token: 'mock-token' }) : null,
    AbortSignal,
    console,
    fetch: async () => ({
      ok: status >= 200 && status < 300,
      status,
      json: async () => payload,
    }),
  };
  vm.runInNewContext(
    `${adminSource.slice(settingsStart, settingsEnd)}\nmodule.exports = checkRequiredAppSettings;`,
    sandbox,
  );
  return sandbox.module.exports({
    id: 'resume-creator',
    requiredAppSettingGroups: [{
      name: 'Azure OpenAI API key',
      roles: ['backend'],
      matchMode: 'exact',
      patterns: ['AZURE_OPENAI_API_KEY'],
    }],
  });
}

test('required backend setting check marks an exactly missing API key as a confirmed failure', async () => {
  const result = await runRequiredSettingsCheck({
    targets: [{ role: 'backend', name: 'resume-backend', resourceId: '/subscriptions/s/resourceGroups/rg/providers/Microsoft.Web/sites/resume-backend' }],
    payload: { properties: { OTHER_SETTING: 'configured' } },
  });
  assert.equal(result.ok, false);
  assert.equal(result.unknown, false);
  assert.equal(result.errors.length, 1);
  assert.match(result.errors[0].message, /is missing/i);
});

test('required backend setting check accepts a present non-empty exact API key setting', async () => {
  const result = await runRequiredSettingsCheck({
    targets: [{ role: 'backend', name: 'resume-backend', resourceId: '/subscriptions/s/resourceGroups/rg/providers/Microsoft.Web/sites/resume-backend' }],
    payload: { properties: { AZURE_OPENAI_API_KEY: 'do-not-log-this-secret' } },
  });
  assert.equal(result.ok, true);
  assert.equal(result.unknown, false);
  assert.equal(result.errors.length, 0);
});

test('required backend setting check treats ARM permission failure as inconclusive, not as a missing key', async () => {
  const result = await runRequiredSettingsCheck({
    targets: [{ role: 'backend', name: 'resume-backend', resourceId: '/subscriptions/s/resourceGroups/rg/providers/Microsoft.Web/sites/resume-backend' }],
    status: 403,
  });
  assert.equal(result.ok, false);
  assert.equal(result.unknown, true);
  assert.equal(result.errors.length, 0);
  assert.match(result.monitoringNote, /Microsoft\.Web\/sites\/config\/list\/action/);
});

test('required backend setting check reports unresolved resource mapping explicitly', async () => {
  const result = await runRequiredSettingsCheck({
    targets: [{ role: 'backend', name: 'resume-backend', resourceId: null }],
    payload: { properties: {} },
  });
  assert.equal(result.ok, false);
  assert.equal(result.unknown, true);
  assert.match(result.monitoringNote, /AZURE_SUBSCRIPTION_ID/);
});

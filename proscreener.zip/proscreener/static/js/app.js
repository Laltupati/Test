$(document).ready(function() {
  function showSpinner() {
      $("#spinner").show();
      $("#content").addClass("blur");
  }

  function hideSpinner() {
      $("#spinner").hide();
      $("#content").removeClass("blur");
  }

  $(document).ready(function() {
      $("#upload-form").submit(function(event) {
          event.preventDefault();
          var formData = new FormData(this);

          // showLoader();
          showSpinner();

          $.ajax({
              url: "/upload",
              type: "POST",
              data: formData,
              contentType: false,
              processData: false,
              success: function(data) {
                  var fileListHtml = "Job Description: " + data.jd + "<br>Resumes:" + data.resumes.map(function(resume) {
                      return "<br>" + resume.path;
                  }).join("");
                  hideSpinner();
                  // $("#results").html("fileListHtml");
                  $("#results").html("<div style='display: flex; justify-content: center; align-items: center; text-align: center;'>Files are loaded successfully!!</div>");
                  // Hide loading image
                  // $("loader").hide(); 
                  alert("Files are uploaded successfully!");
              },
              error: function() {
                  $("#results").html("Error Occurred.");
                  hideSpinner();
              }
          });
      });   
    

      $(document).ready(function() {
        $("#display-skills-ranking-table").click(function() {
            // var gender = $("#gender").val();
            var locations = $("#location").val();

            showSpinner();

            $.ajax({
                url: "/api/display_skills_ranking_table",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    // gender: gender,
                    location: locations
                }),
                success: function(response) {
                    $("#results").html(`<div style='text-align: center;'>${response.results}</div>`);
                  hideSpinner();
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + error);
                    $("#results").html("Error occurred.");
                    hideSpinner();
                }
            });
        });
      });

      $("#screening_questions_for_hr").click(function () {
        showSpinner();
        $.ajax({
          url: "/api/screening_questions_hr",
          type: "POST",
          success: function (data) {
            let content = "";
            data.results.forEach((result) => {
              content += result.replace("Level 1", "<b>Level 1</b>")
                              .replace("Level 2", "<b>Level 2</b>")
                              .replace("Level 3", "<b>Level 3</b>");
              content += "<hr>";
            });
            $("#results").html(content);
            hideSpinner();
          },
          error: function () {
            $("#results").html("Error occurred.");
            hideSpinner();
          },
        });
    });   
      

      $("#display-pros-cons-table").click(function () {
          showSpinner();
          $.ajax({
            url: "/api/display_pros_cons_table",
            type: "POST",
            success: function (data) {
              let content = "";
              data.results.forEach((result) => {
                content += result.replace("Pros:", "<br>Pros:").replace("Cons:", "<br>Cons:");
                content += "<hr>";
              });
              $("#results").html(content);
              hideSpinner();
            },
            error: function () {
              $("#results").html("Error occurred.");
              hideSpinner();
            },
          });
      });     

      $("#send-prompt").click(function () {
          const prompt = $("#prompt-input").val().trim();
          if (!prompt) {
            alert("Please enter a prompt before sending.");
            return;
          }

          showSpinner();
        
          $.ajax({
            url: "/api/send_custom_prompt",
            type: "POST",
            data: { prompt: prompt, conversation_history: "" },
            success: function (data) {
              const generated_text = data.response;
              // Display the GPT-3 response
              $("#results").html(`<p>${generated_text}</p>`);
              hideSpinner();
              $("#prompt-input").val(""); // Clear the text input
            },
            error: function () {
              alert("An error occurred.");
              hideSpinner();
            },
          });
      });     

      $("#export-output-in-ms-word").click(function () {
        const content = $("#results").text();
        $.ajax({
            url: "/api/export_output_in_ms_word",
            type: "POST",
            data: { content: content },
            xhrFields: {
                responseType: "blob",
            },
            success: function (blob) {
                var link = document.createElement("a");
                var url = URL.createObjectURL(blob);
                link.href = url;
                link.download = "output.docx";
                document.body.appendChild(link);
                link.click();
                setTimeout(function () {
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                }, 100);
    
                // Display message to the user
                alert("The content has been downloaded as a Word document. Please check your downloads folder.");
            },
            error: function () {
                alert("An error occurred.");
            },
        });
      });

  //     function clearResults() {
  //       $("#results").html("");
  //     }  
      
  // });

////////////////////////////////////////////////// Internal Resumes //////////////////////////////////////////////////

$(document).ready(function() {
  $("#display-internal-skills-ranking-table").click(function() {
      var employee_level = $("#employee_level").val();
      var locations = $("#location").val();

      showSpinner();

      $.ajax({
          url: "/api/get_jd",
          type: "GET",
          success: function(data) {
              var jd = data.jd;

              $.ajax({
                  url: "/api/display_internal_skills_ranking_table",
                  type: "POST",
                  contentType: "application/json",
                  data: JSON.stringify({
                      jd: jd,
                      employee_level: employee_level,
                      locations: locations
                  }),
                  success: function(response) {
                      $("#results").html(`<div style='text-align: center;'>${response.results}</div>`);
                      hideSpinner();
                  },
                  error: function(xhr, status, error) {
                      console.error("Error: " + error);
                      $("#results").html("Error occurred.");
                      hideSpinner();
                  }
              });
          },
          error: function(xhr, status, error) {
              console.error("Error: " + error);
              $("#results").html("Error occurred.");
              hideSpinner();
          }
      });
  });
});

function clearResults() {
  $("#results").html("");
}
});
});

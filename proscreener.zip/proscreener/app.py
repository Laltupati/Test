import os
import re
import requests
import json
from flask import Flask, render_template, request, jsonify, send_file, session
from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from flask_session import Session
from PyPDF2 import PdfReader
import docx,urllib.parse
from collections import Counter
from docx import Document
from docx.shared import Inches  
from flask.helpers import send_from_directory
from azure.storage.blob import ContainerClient
from azure.storage.blob import BlobServiceClient, BlobClient
from io import BytesIO
import tempfile
import docx2txt
import io
from uuid import uuid4
from datetime import datetime, timedelta
from flask.sessions import SessionInterface, SessionMixin
from werkzeug.datastructures import CallbackDict
# Suppress InsecureRequestWarning
import urllib3
import pandas as pd
import tiktoken
from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from azure.core.credentials import AzureKeyCredential
from pptx import Presentation


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
app.secret_key = "super_secret_key"
# AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=kgsgenaistorage;AccountKey=6QO87Nokle+rQeJCB0zLZQ0hR7M4u/LhK9TXm28B+FC0S/jI9lU7wnkBn+QbnqKggsfiH95cDRqt+AStLo/HDw==;EndpointSuffix=core.windows.net"
UPLOAD_CONTAINER_NAME = "uploaded-files"
ACCOUNT_NAME = "kgsgenaistorages"
ACCOUNT_KEY = "f8m6jnSOfu1MY5U4DFlkQ7PcvNbVXOlnQ0hAol3/C8dnufw3LKZ/FSHcdXptWSc8a9Lpic7/SxRA+AStp1Wfvg=="
AZURE_STORAGE_CONNECTION_STRING = f"DefaultEndpointsProtocol=https;AccountName={ACCOUNT_NAME};AccountKey={ACCOUNT_KEY};EndpointSuffix=core.windows.net"
# SESSION_CONTAINER_NAME = "session-data"
class AzureBlobStorageSession(CallbackDict, SessionMixin):
    def __init__(self, container_client, session_id):
        self.container_client = container_client
        self.session_id = session_id
        data = {}
        try:
            blob_client = container_client.get_blob_client(session_id)
            blob_data = blob_client.download_blob().content_as_text()
            data = json.loads(blob_data)
        except Exception:
            pass
        super(AzureBlobStorageSession, self).__init__(data)

class AzureBlobStorageSessionInterface(SessionInterface):
    def __init__(self, container_name):
        self.container_name = container_name
    def _get_container_client(self):
        return ContainerClient.from_connection_string(conn_str=AZURE_STORAGE_CONNECTION_STRING, container_name=self.container_name)
    def get_expiration_time(self, app, session):
        return datetime.utcnow() + timedelta(seconds=app.config['PERMANENT_SESSION_LIFETIME'])
    def get_session_id(self):
        return f"session_{uuid4()}"
    def open_session(self, app, request):
        session_id = request.cookies.get(app.session_cookie_name)
        container_client = self._get_container_client()
        return AzureBlobStorageSession(container_client, session_id)
    def save_session(self, app, session, response):
        expiration_time = self.get_expiration_time(app, session)
        session_id = session.session_id if session.session_id else self.get_session_id()
        container_client = self._get_container_client()
        blob_client = container_client.get_blob_client(session_id)
        blob_data = json.dumps(dict(session))
        blob_client.upload_blob(blob_data, blob_type='BlockBlob', overwrite=True)
        response.set_cookie(app.session_cookie_name, session_id, expires=expiration_time, httponly=True, domain=self.get_cookie_domain(app))
# app.config["PERMANENT_SESSION_LIFETIME"] = 86400  # Duration in seconds (one day)
# app.session_interface = AzureBlobStorageSessionInterface(SESSION_CONTAINER_NAME)
# Session(app)
ALLOWED_EXTENSIONS = {"pdf", "docx"}
QUALITIES = ['communication', 'programming', 'leadership', 'teamwork', 'analytical', 'creative']
def allowed_file(filename):
    return (
        "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )
def get_container_client(container_name):
    return ContainerClient.from_connection_string(conn_str=AZURE_STORAGE_CONNECTION_STRING, container_name=container_name)
def upload_file_to_blob(file, container_name):
    container_client = get_container_client(container_name)
    blob_client = container_client.get_blob_client(file.filename)
    with BytesIO() as file_stream:
        file.save(file_stream)
        file_stream.seek(0)
        blob_client.upload_blob(file_stream, overwrite=True)
    return blob_client.url
def download_blob_to_text(blob_url, is_binary=False):
    response = requests.get(blob_url)
    if is_binary:
        return response.content
    else:
        return response.text
def extract_resume_skill_scores(resume_lines):
    total_skill_score = 0
    for line in resume_lines:
        match = re.match(r"\s*\|\s*[^|]+\s*\|\s*\d+\s*\|\s*(\d+)\s*\|", line)
        if match:
            skill_score = int(match.group(1))
            total_skill_score += skill_score
    return total_skill_score
def get_blob_sas(account_name, account_key, container_name, blob_name):
    sas_token = generate_blob_sas(
        account_name=account_name,
        account_key=account_key,
        container_name=container_name,
        blob_name=blob_name,
        permission=BlobSasPermissions(read=True),  # set permissions according to your requirement
        expiry=datetime.utcnow() + timedelta(hours=1)  # SAS token will expire 1 hour from now
    )
    return sas_token
def read_document_content(blob_url):
    resume_file_name = os.path.basename(blob_url)
    sas_token = get_blob_sas(ACCOUNT_NAME, ACCOUNT_KEY, UPLOAD_CONTAINER_NAME, urllib.parse.unquote(resume_file_name))
    blob_url = f"https://{ACCOUNT_NAME}.blob.core.windows.net/{UPLOAD_CONTAINER_NAME}/{resume_file_name}?{sas_token}"
    # blob_url = f"{blob_url}?{sas_token}"
    response = requests.get(blob_url)
    file_data = response.content
    # print(f"file_data: {file_data}")
    if resume_file_name.endswith(".pdf"):
        with BytesIO(file_data) as f:
            try:
                pdf_reader = PdfReader(f)
                extracted_text = ""
                for page in pdf_reader.pages:
                    extracted_text += page.extract_text()
            except Exception as e:
                # print(f"Error while reading PDF file: {e}")
                extracted_text = ""
        return extracted_text
    elif resume_file_name.endswith(".docx"):
        try:
            document = docx.Document(io.BytesIO(file_data))
            extracted_text = ""
            for paragraph in document.paragraphs:
                extracted_text += paragraph.text + "\n"
        except Exception as e:
            # print(f"Error while reading .docx file: {e}")
            extracted_text = ""
        return extracted_text

def count_tokens(text):
    encoding = tiktoken.get_encoding("gpt-4o-mini")
    tokens = encoding.encode(text)
    return len(tokens)        
    
@app.route("/")
def index():
    return render_template("index.html")

@app.route('/internal_profiles.html')
def internal_profiles():
    return render_template('internal_profiles.html')

@app.route("/upload", methods=["POST"])
def upload():
    resume_files = request.files.getlist("resumes")
    jd_file = request.files["jd"]
    jd_filepath = upload_file_to_blob(jd_file, UPLOAD_CONTAINER_NAME)
    uploaded_resumes = []
    for file in resume_files:
        if file and allowed_file(file.filename):
            file_url = upload_file_to_blob(file, UPLOAD_CONTAINER_NAME)
            uploaded_resumes.append({"name": file.filename, "path": file_url})
    # Store uploaded resumes and JD in session
    session["resumes"] = uploaded_resumes
    session["jd"] = jd_filepath
    return jsonify({"resumes": uploaded_resumes, "jd": jd_filepath})

@app.route("/api/send_prompt", methods=["POST"])
def send_prompt():
    prompt = request.form.get("prompt")
    conversation_history = request.form.get("conversation_history")

    resource_name = "oai-use-promanager-dev"
    deployment_name = "gpt-4o-mini"
    api_version = "2024-02-15-preview"
    api_key ="c54567fe809b451fac1a1b16eff22e0f"
    
    api_url = f"https://{resource_name}.openai.azure.com/openai/deployments/{deployment_name}/chat/completions?api-version={api_version}"
    # api_key = "052bc9aaeb0b4ae6bccc42ef4d05e1b5"
    headers = {"Content-Type": "application/json", "api-key": api_key}
    query_data = {"temperature": 0, "top_p": 1, "frequency_penalty": 0, "presence_penalty": 0, "max_tokens": 10000, "stop": None, "messages": [ {"role": "system", "content": system_role}, {"role": "user", "content": prompt}]}
    
    response = requests.post(api_url, headers=headers, data=json.dumps(data), timeout=600)
    response_data = response.json()
    generated_text = response_data["choices"][0]["message"]["content"].strip()
    # print(generated_text)
    return jsonify({"response": generated_text})

def send_gpt3_request(prompt):

    # added azure emdpoints below:
    # resource_name = "oai-use-promanager-dev"
    # deployment_name = "gpt-4o-mini"
    # api_version = "2024-02-15-preview"
    # api_key ="c54567fe809b451fac1a1b16eff22e0f"
    
    resource_name = "oai-use-promanager-dev"
    deployment_name = "gpt-4o-mini"
    api_version = "2024-02-15-preview"
    api_key ="c54567fe809b451fac1a1b16eff22e0f"
    
    api_url = f"https://{resource_name}.openai.azure.com/openai/deployments/{deployment_name}/chat/completions?api-version={api_version}"
    # api_key = "052bc9aaeb0b4ae6bccc42ef4d05e1b5"
    headers = {"Content-Type": "application/json", "api-key": api_key}
    system_role = """You are an expert in talent acquisition. Separate this job description into 3-4 more focused aspects for efficient resume retrieval. 
                    Make sure every single relevant aspect of the query is covered in at least one query. You may choose to remove irrelevant information that doesn't contribute to finding resumes such as the expected salary of the job, the ID of the job, the duration of the contract, etc.
                    Only use the information provided in the initial query. Do not make up any requirements of your own.
                    Put each result in one line, separated by a linebreak."""
    query_data = {"temperature": 0.8, "top_p": 1, "frequency_penalty": 0, "presence_penalty": 0, "max_tokens": 10000, "stop": None, "messages": [ {"role": "system", "content": system_role}, {"role": "user", "content": prompt}]}
    
    # response = requests.post(api_url, headers=headers, data=json.dumps(data), timeout=600)
    #########################################################################################    
    # api_url = "https://gpt-llm-35-0613.openai.azure.com/openai/deployments/gpt-35-turbo-16k/chat/completions?api-version=2023-03-15-preview"
    # api_key = "052bc9aaeb0b4ae6bccc42ef4d05e1b5"
    # headers = {"api-key": api_key}
    # query_data = {
    #     "messages": [
    #             {"role": "system", "content": prompt}
    #         ],
    #         "temperature": 0.3,
    #         "top_p": 1,
    #         "frequency_penalty": 0,
    #         "presence_penalty": 0,
    #         "max_tokens": 4000,
    #         "stop": None,
    #     }
    
    try:
        response = requests.post(api_url, headers=headers, json=query_data, verify=False)
        response_data = response.json()
        if "choices" not in response_data:
            print("Error response from the GPT 4o mini API:", response_data)
            return {"choices": [{"text": ""}]}
        return response_data
    
    except Exception as e:
        print(f"Error while sending request to GPT-3 API: {e}")
        return {"choices": [{"text": ""}]}
def extract_skills_score(generated_text):
    match = re.match(
        r"\s*Total Skillset Score:\s*(\d+)",
        generated_text,
    )
    if match:
        return int(match.group(1))
    return 0

@app.route("/api/display_skills_ranking_table", methods=["POST"])
def display_skills_ranking_table():
    data = request.get_json()
    # gender = data.get("gender")
    locations = data.get("locations")
    resumes = session.get("resumes")
    # print(gender, location)
    jd = session.get("jd")
    jd_file_name = os.path.basename(jd)
    if not resumes or not jd:
        return "Error: Missing job description or resumes."
    jd_text = read_document_content(jd)
    print(jd_text)
    results = []
    for index, resume in enumerate(resumes, start=1):
        resume_text = read_document_content(resume["path"])
        resume_file_name = resume["path"]
        prompt = (
            f"""Based on the job description and resume content, provide a total skillset score for the following candidate.
            Use the format:'Resume{index}: {resume_file_name} - Total Skillset Score: {{score}}'.
            Give the Total Skillset Score considering the Skills given in the Job Description:{jd_text} and Skills in the Resume Content:{resume_text}. 
            Also give the score for Primary Skillset match and Secondary Skillset match for the {resume_text}, taking {jd_text} as the reference.
            The Total Skillset Score should also consider the location of the candidate in {resume_text} and the location given in the {jd_text}. Give more weightage if the locations match.
            Also provide the number of years of experience the candidate holdswith respect to Job description.
            Refer the {resume_text} of the candidate and check of the candidate has worked for any of the Big 4 companies (Pwc,Delloite,E&Y,KPMG) previously. Respond to this as either Yes or No.
            Filter the candidates keeping {locations} in the input as reference with the location of candidate in the {resume_text}.
            Strictly give the response in Json format as shown below. No extra annotation or text like '''json  should be provided before and after the json brackets.
            """
        )

        prompt += """
                  Example of Response:  
                    {
                    Name of the Candidate: Mikinj
                    Total years of experience: 4 years  
                    Primary Skillset Score: 90%
                    Secondary Skillset Score: 70%
                    Total skillset Score : 80%        
                    Resume File Name: {resume_file_name}   
                    Big4 Exp: Yes
                    }
        """
        response_data = send_gpt3_request(prompt)
        generated_text = response_data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
        if not generated_text:
            results.append((resume_file_name, "Error: No response from GPT-3."))
            continue
        # print(f"GPT Response for Resume {index}:{resume_file_name}:", generated_text)
        generated_text = generated_text.replace("-","<br>")
        parts_generated_text = generated_text.split('/')
        candidate_generated_text = parts_generated_text[-1]
        formatted_text = f"Candidate {index}: {candidate_generated_text}\n"
        # print(formatted_text)
        results.append(formatted_text)
    print(results)    
    # Format the Resume name and score and store it in the session
    formatted_text_list = []
    for result in results:
        formatted_text = result.replace("Candidate", "<br>").replace("Total Skillset Score:", "<br>")
        formatted_text += "<hr>"
        formatted_text_list.append(formatted_text)  
        # print(formatted_text_list)      

    # Extract Resume Name and Total Skillset Score
    names = []
    years_of_experience = []
    skillset_scores = []
    resume_file_names = []
    primary_skillset_scores = []
    secondary_skillset_scores = []
    big4_exp = []

    for result in results:
        try:
            candidate_data = json.loads(result.split(": ", 1)[1])
            names.append(candidate_data["Name of the Candidate"])
            years_of_experience.append(candidate_data["Total years of experience"])
            skillset_scores.append(candidate_data["Total skillset Score"])
            resume_file_names.append(candidate_data["Resume File Name"])
            primary_skillset_scores.append(candidate_data["Primary Skillset Score"])
            secondary_skillset_scores.append(candidate_data["Secondary Skillset Score"])
            big4_exp.append(candidate_data["Big4 Exp"])
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            print(f"Error parsing result: {result}, error: {e}")

    # Convert to DataFrame
    df = pd.DataFrame({
        "Name of the Candidate": names,
        "Total years of experience": years_of_experience,
        "Primary Skillset Score": primary_skillset_scores,
        "Secondary Skillset Score": secondary_skillset_scores,
        "Total Skillset Score": skillset_scores,
        "Resume File Name": resume_file_names,
        "Big4 Exp": big4_exp,
    })

    # Align headings to center and add green color to Total skillset Score text
    df_styled = df.style.set_table_styles({
        'Name of the Candidate': [{'selector': 'th', 'props': [('text-align', 'center')]}],
        'Total years of experience': [{'selector': 'th', 'props': [('text-align', 'center')]}],
        'Big4 Exp': [{'selector': 'th', 'props': [('text-align', 'center')]}],
        'Primary Skillset Score': [{'selector': 'th', 'props': [('text-align', 'center')]}],
        'Secondary Skillset Score': [{'selector': 'th', 'props': [('text-align', 'center')]}],
        'Total Skillset Score': [
            {'selector': 'th', 'props': [('text-align', 'center')]},
            {'selector': 'td', 'props': [('color', 'green')]}
        ],
        'Resume File Name': [
        {'selector': 'th', 'props': [('text-align', 'center')]},
        {'selector': 'td', 'props': [('color', 'lightorange'), ('font-style', 'italic')]},
        ],
    })

    # Align headings to center, add green color to Total skillset Score text, and ensure table lines are present
    df_styled = df.style.set_table_styles([
        {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
        {'selector': 'td', 'props': [('border', '1px solid black')]},
        {'selector': 'td:nth-child(6)', 'props': [('color', 'green')]}  # Assuming 'Total Skillset Score' is the 6th column
    ]).hide(axis='index')

    def color_total_skillset_score(val):
        num_val = float(val.rstrip('%'))
        color = 'green' if num_val > 50 else 'red'
        return f'color: {color}'
    
    def color_big4_exp(val):
        color = 'green' if val == 'Yes' else 'red'
        return f'color: {color}'

    df_styled = df.style.applymap(color_total_skillset_score, subset=['Total Skillset Score']).applymap(color_big4_exp,subset=['Big4 Exp']).set_table_styles([
        {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
        {'selector': 'td', 'props': [('border', '1px solid black')]},
        {'selector': 'td:nth-child(6)', 'props': [('color', '#FF5D29'), ('font-style', 'italic')]}  # 'Resume File Name' is the 6th column
    ]).hide(axis='index')

    df_to_html = df_styled.to_html(index=False, escape=False)

    # Optionally, you can store the DataFrame as HTML in the session
    session["resume_score_html"] = "".join(formatted_text_list)

    # Or return the DataFrame as a JSON response
    return jsonify({"results": df_to_html})    


@app.route("/api/display_pros_cons_table", methods=["POST"])
def display_pros_cons_table():
    resumes = session.get("resumes")
    jd = session.get("jd")
    results = []
    for index, resume in enumerate(resumes, start=1):
        resume_file_name = os.path.basename(resume["path"])
        prompt= f"""Display the pros and cons of candidate {index}: {resume_file_name}. Use the format: \"Pros: {{pros}}; Cons: {{cons}}\". 
                    Strictly return only 5 important Pros and Cons for all the candidates. Display the responses as pointers as shown in the sample.
                    Strictly maintain the consistency of having "**" after each pointer for all the candidates. This should not be missed.
                     
                    Sample Response:
                    Pros:**
                    1. 6 years of software development experience in Java/J2EE technologies.**
                    2. Strong knowledge of Software Development Life Cycle (SDLC) methodologies including Agile, RUP, and Waterfall.**
                    3. Expertise in web development technologies such as HTML, CSS, JavaScript, jQuery, AngularJS, and Node.js.**
                    4. Experience with MVC frameworks like Struts and Spring, and ORM tools like Hibernate.**
                    5. Proficient in RESTful and SOAP web services.**
                    Cons:**
                    1. Limited experience with data science or machine learning technologies.**
                    2. No mention of experience with Python or R, which are often required for data related roles.**
                    3. Lack of specific experience with large datasets or distributed computing frameworks (e.g., Hadoop, Spark).**
                    4. No explicit mention of experience with A/B testing or statistical analysis.** 
                                        
                    """
        conversation_history_with_prompt = f"{read_document_content(resume['path'])}\n{read_document_content(jd)}\n{prompt}"
        response_data = send_gpt3_request(conversation_history_with_prompt)
        generated_text = response_data["choices"][0]["message"]["content"].strip()
        # generated_text = generated_text.replace("-","<br>")
        formatted_text = f"Candidate {index}: {urllib.parse.unquote(resume_file_name)} - {generated_text}\n"
        results.append(formatted_text)

    formatted_text_list = []

    for result in results:
        formatted_text = result.replace("**","<br>")
        formatted_text_list.append(formatted_text)
        print(formatted_text_list)
    
    session["pros_cons_html"] = "".join(formatted_text_list)
    return jsonify({"results": formatted_text_list})

def extract_pros_and_cons(generated_text):
    match = re.match(r"\s*Pros:\s*(.+)\s*;\s*Cons:\s*(.+)", generated_text)
    if match:
        return match.groups()
    return "", ""

@app.route("/api/send_custom_prompt", methods=["POST"])
def send_custom_prompt():
    prompt = request.form.get("prompt")
    resumes_text = "\n".join([read_document_content(resume["path"]) for resume in session.get("resumes")])
    conversation_history = request.form.get("conversation_history", "")
    skill_ranking_table_html = session.get("resume_score_html", "")
    pros_cons_html = session.get("pros_cons_html", "")
    hr_qsn_ans_html = session.get("hr_qsn_ans_html", "")
    prompt_with_content = (f"{resumes_text}\n"
                           f"{read_document_content(session['jd'])}\n"
                           f"{skill_ranking_table_html}\n"
                           f"{pros_cons_html}\n"
                           f"{conversation_history}\n"
                           f"{hr_qsn_ans_html}\n"
                           f"{prompt}\n")
    prompt_with_content +="""Answer only with the details that are uploaded and provide Concise responses in 1-2 sentences.
                             Answer straight to the questions asked. Do not add additional irrelevant information.    
                             Provide quantification whenever possible."""
    
    response_data = send_gpt3_request(prompt_with_content)
    generated_text = response_data["choices"][0]["message"]["content"].strip()
    return jsonify({"response": generated_text})

def convert_to_html_table(data):
    html_table = '<table border="1" cellpadding="5" cellspacing="0">'
    html_table += "<tr><th colspan='2'>Skills Ranking Table</th></tr>"
    html_table += "<tr><th>Resume</th><th>Skills Score</th></tr>"
    for row in data:
        html_table += f"<tr><td>{row[0]}</td><td>{row[1]}</td></tr>"
    html_table += "</table>"
    return html_table

@app.route("/api/export_output_in_ms_word", methods=["POST"])
def export_output_in_ms_word():
    content = request.form.get("content")
    document = Document()
    p = document.add_paragraph(content)
    # Save the document
    output_file = "output.docx"
    document.save(output_file)
    # Send the file to the user
    return send_file(output_file, as_attachment=True, download_name=output_file)

@app.route("/api/screening_questions_hr", methods=["POST"])
def screening_questions_hr():
    # resumes = session.get("resumes")
    jd = session.get("jd")
    results = []
    # for index, resume in enumerate(resumes, start=1):
    # resume_file_name = os.path.basename(resume["path"])
    jd_file_name = os.path.basename(jd)
    prompt = f"""Imagine you are screening candidates among many candidates and prepare a set of high level technical interview screening questions and answers to be asked by HR based on the inputs from the {read_document_content(jd)}.
                Generate 6 questions and answers as points in small sentences. The Questions should not be too much technical, rather should be to understand the Candidate's skillset . 
                The Questions should be in 3 levels of difficulty that is Level1 with 2 questions and answers , Level2 with 2 questions and answers, Level3 with 2 questions and answers.
                Striclty give only questions and answers , no extra text should be added.Add *** after each question and each answer.
                Example:
                    Level 1:---
                    Question 1: What is your experience with the data science project lifecycle?
                    Expected Answer: The candidate should talk about multiple projects worked on, deployments and maintainance
                """
    conversation_history_with_prompt = f"{prompt}"
    # print (f">>>>>conversation history {conversation_history_with_prompt}")
    response_data = send_gpt3_request(conversation_history_with_prompt)
    generated_text = response_data["choices"][0]["message"]["content"].strip()
    print(generated_text)
    generated_text = generated_text.replace("---", "<br>")
    generated_text = generated_text.replace("***", "<br>")
    
    results.append(generated_text)
    session["hr_qsn_ans_html"] = "".join(results)
    return jsonify({"results": results})

###################################Internal Profile Search######################

search_endpoint = "https://ais-promanager.search.windows.net"
search_key = "LV6B8GdzAAtnaXMl138FktDEV577IdrKfYRykDJEVVAzSeAM7t82"
search_index = "vector-1739343245377"

search_client = SearchClient(endpoint=search_endpoint, index_name=search_index, credential=AzureKeyCredential(search_key))

def search_rag(question, history=None):
    print("question: ", question)
    results = search_client.search(
        search_text = question,
        top=20,
        select="chunk,title",
        query_type = QueryType.SEMANTIC,
        semantic_configuration_name = "vector-1739343245377-semantic-configuration")
    return results

@app.route("/api/get_jd", methods=["GET"])
def get_jd():
    jd = session.get("jd")
    jd_text = read_document_content(jd)
    return jsonify({"jd": jd_text})


@app.route("/api/display_internal_skills_ranking_table", methods=["POST"])
def display_internal_skills_ranking_table():
    data = request.get_json()
    employee_level = data.get("employee_level")
    locations = data.get("locations")
    jd = session.get("jd")
    # print("jd: ", jd)
    jd_text = read_document_content(jd)
    # print(jd_text)
    
    results = []
    response_rag_search = search_rag(jd_text)

    for result in response_rag_search:
        # title = result.get("title")
        # chunk = result.get("chunk")
        results.append({
            "title": result.get("title"),
            "chunk": result.get("chunk")
        })

    titles = [result["title"] for result in results]
    print(titles)

    # Fetch files for each title from Azure Blob Storage
    ACCOUNT_NAME_INTERNAL = "sadbtestdev"
    ACCOUNT_KEY_INTERNAL = "8DLNe/PruVpLZR/FSJ1M6aiXAlWNs4a+JOCGrCO67QV/K9OKuRu4uccGe3Cma7OhPg/haM1/zbn1+AStCPG5gg=="
    AZURE_STORAGE_CONNECTION_STRING_INTERNAL_RESUMES = f"DefaultEndpointsProtocol=https;AccountName={ACCOUNT_NAME_INTERNAL};AccountKey={ACCOUNT_KEY_INTERNAL};EndpointSuffix=core.windows.net"
    container_client = ContainerClient.from_connection_string(conn_str=AZURE_STORAGE_CONNECTION_STRING_INTERNAL_RESUMES, container_name="internal-resume-db")
    files_content = {}
    for title in titles:
        blob_client = container_client.get_blob_client(title)
        try:
            blob_data = blob_client.download_blob().readall()
            if title.endswith('.pptx'):
                # Process .pptx file to extract text
                pptx_file = Presentation(io.BytesIO(blob_data))
                text_content = []
                for slide in pptx_file.slides:
                    for shape in slide.shapes:
                        if hasattr(shape, "text"):
                            text_content.append(shape.text)
                files_content[title] = "\n".join(text_content)
            else:
                files_content[title] = blob_data.decode('utf-8')
        except Exception as e:
            print(f"Error fetching file for title {title}: {e}")    

    results_str = json.dumps(results)
    locations_str = json.dumps(locations)
    files_content_str = json.dumps(files_content)

    # prompt = """You are an Expert Human Resource Recruiter will be picking the best 25 internal employees within the organisation for the """  + str(jd_text) + """. You will be using the """ + str(jd_text) + """ to evaluate the employees in """ + str(results_str) + """ that is coming from the RAG. Take """ + str(employee_level) + """ and """ + str(locations_str) + """ as strict parameters for filtering. You will be giving a Skillset match Score in percentage as shown in the example below for each candidate considering the Role Summary/Description, Primary purpose and goal,Responsibilities and tasks,Prior Experience, Job Requirements(skills, abilities & qualifications) """ + str(jd_text) + """ as the requirement and Background, Professional and industry experience of candidate in """ + str(results_str) + """.  The final result should be given by filtering for the """ + str(employee_level) + """ that is sent as input with the employee level in """ + str(results_str) + """. The results_str should be given strictly in the Json format as shown below, it should not include any preceding and succeding texts like  ```json in the output. Example of the response: "{"Employee Name": "Nithin D", "Employee EmailID": "nithin@kpmg.com", "Skillset Match Score": "78%" }, { "Employee Name": "Harish TR", "Employee EmailID": "Harish@kpmg.com", "Skillset Match Score": "79%" }"""
    prompt ="""You are an expert Human Resource Recruiter selecting the best 15 internal employees for the following job description: """ + str(jd_text) + """. Please use the provided job description to evaluate employees listed in from RAG""" + str(results_str) + """ and resumes """+str(files_content_str)+ """ of the same employees from input. Filter using the specified """ + str(employee_level) + """ and """ + str(locations_str) + """ parameters very strictly.You will assign a Skillset Match Score (in percentage) for each candidate based on their Background, Professional, and Industry experience as noted in their results against the job description's Role Summary/Description, Primary Purpose and Goal, Responsibilities and Tasks, Prior Experience, and Job Requirements (Skills, Abilities & Qualifications).The final filtered list must adhere to the specified employee level and location from the input data and be presented in the specified JSON format, as shown in the example below: Example of the response: "{"Employee Name": "Nithin D", "Employee EmailID": "nithin@kpmg.com", "Skillset Match Score": "78%" }, { "Employee Name": "Harish TR", "Employee EmailID": "Harish@kpmg.com", "Skillset Match Score": "79%" }. The response should be given strictly in the Json format as shown , it should not include any preceding and succeding texts like  ```json in the output.It should include delimiter "," in the json  """
    response_data = send_gpt3_request(prompt)  
    generated_text = response_data["choices"][0]["message"]["content"].strip()

    print(generated_text) 
    
    try:
        cleaned_json_text = f"[{generated_text}]"

        json_data = json.loads(cleaned_json_text)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        return jsonify({"error": "Failed to decode JSON response from GPT-4"}), 500
    
    df = pd.DataFrame(json_data)
    print(df)

    df['Employee EmailID'] = df['Employee EmailID'].str.lower()

    #Sorting the Scores in descending order
    df['Skillset Match Score'] = df['Skillset Match Score'].str.rstrip('%').astype('float')
    df = df.sort_values(by='Skillset Match Score', ascending=False)
    
    availability_df = pd.read_csv('availability.csv')

    merged_df = pd.merge(df, availability_df, left_on='Employee EmailID', right_on='EmailID')
    print(merged_df)
    
    filtered_df = merged_df[merged_df['Available'] == 'Yes']
    filtered_df = filtered_df.drop(columns=['EmailID'])
    print(filtered_df)

    df_to_html = filtered_df.to_html(index=False, escape=True)

    session["internal_profile_score_html"] = "".join(filtered_df)
    
    return jsonify({"results": df_to_html})


@app.route("/api/display_pros_cons_table_internal", methods=["POST"])
def display_pros_cons_table_internal():

    data = request.get_json()
    jd = session.get("jd")
    jd_text = read_document_content(jd)
    
    results = []
    response_rag_search = search_rag(jd_text)

    for result in response_rag_search:
        title = result.get("title")
        chunk = result.get("chunk")
        results.append({
            "title": title,
            "chunk": chunk
        })
        
    # for index, resume in enumerate(resumes, start=1):
    #     resume_file_name = os.path.basename(resume["path"])
    #     prompt= f"""Display the pros and cons of candidate {index}: {resume_file_name}. Use the format: \"Pros: {{pros}}; Cons: {{cons}}\". 
    #                 Strictly return only 5 important Pros and Cons for all the candidates. Display the responses as pointers as shown in the sample.
    #                 Strictly maintain the consistency of having "**" after each pointer for all the candidates. This should not be missed.
                     
    #                 Sample Response:
    #                 Pros:**
    #                 1. 6 years of software development experience in Java/J2EE technologies.**
    #                 2. Strong knowledge of Software Development Life Cycle (SDLC) methodologies including Agile, RUP, and Waterfall.**
    #                 3. Expertise in web development technologies such as HTML, CSS, JavaScript, jQuery, AngularJS, and Node.js.**
    #                 4. Experience with MVC frameworks like Struts and Spring, and ORM tools like Hibernate.**
    #                 5. Proficient in RESTful and SOAP web services.**
    #                 Cons:**
    #                 1. Limited experience with data science or machine learning technologies.**
    #                 2. No mention of experience with Python or R, which are often required for data related roles.**
    #                 3. Lack of specific experience with large datasets or distributed computing frameworks (e.g., Hadoop, Spark).**
    #                 4. No explicit mention of experience with A/B testing or statistical analysis.** 
                                        
    #                 """
    #     conversation_history_with_prompt = f"{read_document_content(resume['path'])}\n{read_document_content(jd_text)}\n{prompt}"
    #     response_data = send_gpt3_request(conversation_history_with_prompt)
    #     generated_text = response_data["choices"][0]["message"]["content"].strip()
    #     # generated_text = generated_text.replace("-","<br>")
    #     formatted_text = f"Candidate {index}: {urllib.parse.unquote(resume_file_name)} - {generated_text}\n"
    #     results.append(formatted_text)

    formatted_text_list = []

    for result in results:
        formatted_text = result.replace("**","<br>")
        formatted_text_list.append(formatted_text)
        print(formatted_text_list)
    
    session["pros_cons_html"] = "".join(formatted_text_list)
    return jsonify({"results": formatted_text_list})

if __name__ == "__main__":
    app.run()
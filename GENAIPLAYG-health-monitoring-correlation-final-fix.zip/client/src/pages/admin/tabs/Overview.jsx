import React from 'react';
import { timeAgo } from '../format';
import {
  mockPlatformServices,
  mockSecurityPosture,
  mockAiUsage,
  mockCost,
  mockTrends,
  mockRecentDeployments,
} from '../mockData';

function Sparkline({ points, color }) {
  if (!points || points.length < 2) return null;
  const w = 100, h = 28;
  const min = Math.min(...points), max = Math.max(...points);
  const range = max - min || 1;
  const step = w / (points.length - 1);
  const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${i * step} ${h - ((p - min) / range) * h}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="34" preserveAspectRatio="none">
      <path d={d} fill="none" stroke={color} strokeWidth="2" />
    </svg>
  );
}

export default function Overview({ apps, summary, incidents, checkAll, checkingAll, onNavigate, onOpenApp, cost }) {
  const realCost = cost && cost.configured && !cost.error;
  const costView = realCost ? cost : mockCost;
  const total = summary?.total ?? apps.length;
  const healthyCount = apps.filter((a) => ['active', 'restricted', 'monitoring_error'].includes(a.status)).length;
  const degradedCount = apps.filter((a) => a.status === 'degraded').length;
  const stoppedCount = apps.filter((a) => a.status === 'stopped').length;
  const inactiveCount = apps.filter((a) => a.status === 'inactive').length;
  const unavailableCount = inactiveCount;
  const downCount = stoppedCount + unavailableCount;
  const platformHealthy = total > 0 && downCount === 0;
  const allApplicationsHealthy = total > 0 && healthyCount === total;
  const applicationHealthDegraded = degradedCount > 0 || downCount > 0;
  const applicationHealthStatus = allApplicationsHealthy
    ? 'Healthy'
    : stoppedCount > 0
      ? 'Stopped / Down'
      : unavailableCount > 0
        ? 'Unavailable'
        : degradedCount > 0
          ? 'Partially Available'
          : 'Unknown';
  const applicationHealthTone = allApplicationsHealthy
    ? 'g'
    : stoppedCount > 0
      ? 'stopped-health'
      : unavailableCount > 0
        ? 'r'
        : degradedCount > 0
          ? 'amber'
          : 'b';
  const avgLatency = summary?.avgLatencyMs;
  const attentionCount = degradedCount + downCount;
  const monitoredCount = apps.filter((a) => a.lastChecked).length;
  const coveragePct = total ? Math.round((monitoredCount / total) * 100) : 0;
  const healthPct = total ? Math.round((healthyCount / total) * 100) : 0;
  const operationalScore = total
    ? Math.max(0, Math.round(((healthyCount * 100) + (degradedCount * 55)) / total))
    : 0;
  const responseBand = avgLatency == null ? 'No data' : avgLatency <= 100 ? 'Excellent' : avgLatency <= 250 ? 'Good' : avgLatency <= 500 ? 'Watch' : 'Slow';
  const priorityApps = apps.filter((a) => ['degraded', 'stopped', 'inactive'].includes(a.status));

  const criticalCount = incidents.filter((i) => ['error', 'dependency_error', 'azure_log_error', 'notify_failed'].includes(i.level)).length;
  const warningCount = incidents.filter((i) => ['auto_fix', 'notify_pending', 'notify_suppressed'].includes(i.level)).length;
  const highCount = incidents.filter((i) => i.level === 'stopped' || i.level === 'notify_sent').length;

  const attentionItems = [
    ...apps
      .filter((a) => a.status === 'degraded')
      .map((a) => ({
        key: `degraded-${a.id}`,
        crit: true,
        icon: '⚠',
        title: a.title,
        sub: `${a.dependencyHealth?.failingDependency || a.lastError?.dependency || 'Dependency'} failure — some functionality may be unavailable`,
        time: timeAgo(a.lastError?.timeGenerated || a.lastChecked),
      })),
    ...apps
      .filter((a) => a.status === 'stopped')
      .map((a) => ({
        key: `stopped-${a.id}`,
        crit: true,
        icon: '■',
        title: a.title,
        sub: 'Stopped in Azure — start the App Service.',
        time: timeAgo(a.lastChecked),
      })),
    ...apps
      .filter((a) => a.status === 'inactive')
      .map((a) => ({
        key: `inactive-${a.id}`,
        crit: true,
        icon: '⚠',
        title: a.title,
        sub: a.lastError?.errorMessage || `Down — ${a.consecutiveFailures} consecutive failure(s)`,
        time: timeAgo(a.lastChecked),
      })),
  ].slice(0, 5);

  return (
    <>
      <div className="ad-page-header">
        <div>
          <h1 className="ad-page-title">Platform Overview</h1>
          <p className="ad-page-subtitle">Real-time health and operations overview of GenAI Playground platform</p>
        </div>
        <div className="ad-page-header-right">
          <span>Last updated: {timeAgo(apps[0]?.lastChecked)}</span>
          <button type="button" className="ad-btn" onClick={checkAll} disabled={checkingAll}>
            {checkingAll ? 'Checking…' : '↻ Refresh'}
          </button>
        </div>
      </div>

      {/* ── KPI row: mix of real (health/apps/latency/alerts) and mock (availability/AI usage/cost) ── */}
      <div className="ad-kpi-row">
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className={`ad-kpi-icon ${applicationHealthTone}`}>{allApplicationsHealthy ? '✓' : '!'}</div><span className="ad-kpi-label">Application Health</span></div>
          <div className={`ad-kpi-value ${applicationHealthTone}`}>{applicationHealthStatus}</div>
          <div className="ad-kpi-sub">{allApplicationsHealthy
            ? `All ${total} applications are healthy`
            : applicationHealthDegraded
              ? [
                degradedCount ? `${degradedCount} partially available` : null,
                unavailableCount ? `${unavailableCount} unavailable` : null,
                stoppedCount ? `${stoppedCount} stopped` : null,
              ].filter(Boolean).join(' · ')
              : 'Application health checks are pending'}</div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon b">▦</div><span className="ad-kpi-label">Applications</span></div>
          <div className="ad-kpi-value">{apps.length} / {total}</div>
          <div className="ad-kpi-sub">Registered · {degradedCount} partially available · {unavailableCount} unavailable · {stoppedCount} stopped</div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon tq">📈</div><span className="ad-kpi-label">Availability (30d)</span></div>
          <div className="ad-kpi-value">{mockTrends.availabilityPct}%</div>
          <div className="ad-kpi-sub">SLA: 99.90% <em style={{ fontStyle: 'normal', opacity: 0.7 }}>(illustrative)</em></div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon b">◷</div><span className="ad-kpi-label">Monitoring Coverage</span></div>
          <div className="ad-kpi-value">{coveragePct}%</div>
          <div className="ad-kpi-sub">{monitoredCount} of {total} applications checked</div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon r">🛡</div><span className="ad-kpi-label">Critical Alerts</span></div>
          <div className="ad-kpi-value">{criticalCount}</div>
          <div className="ad-kpi-sub">High: {highCount} · Warning: {warningCount}</div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon g">⏱</div><span className="ad-kpi-label">Avg Response Time</span></div>
          <div className="ad-kpi-value">{avgLatency != null ? `${avgLatency} ms` : '—'}</div>
          <div className="ad-kpi-sub">across last checks</div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon p">✦</div><span className="ad-kpi-label">AI Requests Today</span></div>
          <div className="ad-kpi-value">{(mockAiUsage.requestsToday / 1000).toFixed(1)}K</div>
          <div className="ad-kpi-sub">↑ {mockAiUsage.requestsDeltaPct}% vs yesterday <em style={{ fontStyle: 'normal', opacity: 0.7 }}>(illustrative)</em></div>
        </div>
        <div className="ad-kpi-card">
          <div className="ad-kpi-icon-row"><div className="ad-kpi-icon tq">$</div><span className="ad-kpi-label">AI Cost Today</span></div>
          <div className="ad-kpi-value">${mockAiUsage.costTodayUsd}</div>
          <div className="ad-kpi-sub">↑ {mockAiUsage.costDeltaPct}% vs yesterday <em style={{ fontStyle: 'normal', opacity: 0.7 }}>(illustrative)</em></div>
        </div>
      </div>

      <div className="ad-grid-2">
        <div>
          {/* ── Executive Operations Pulse: intentionally different from Health & Monitoring ── */}
          <div className="ad-panel ad-overview-ops-pulse">
            <div className="ad-panel-header ad-overview-ops-header">
              <div>
                <div className="ad-overview-eyebrow">EXECUTIVE OPERATIONS PULSE</div>
                <h2 className="ad-panel-title">Platform Readiness</h2>
                <div className="ad-overview-health-caption">One-screen view of readiness, risk, monitoring coverage and user experience.</div>
              </div>
              <button type="button" className="ad-panel-link" onClick={() => onNavigate('health')}>Open diagnostics →</button>
            </div>

            {apps.length === 0 ? (
              <div className="ad-empty-note">No applications with a live launch URL yet.</div>
            ) : (
              <>
                <div className="ad-overview-pulse-grid">
                  <div className={`ad-overview-score-card ${platformHealthy ? 'healthy' : 'attention'}`}>
                    <div className="ad-overview-score-ring" style={{ '--score': operationalScore }}>
                      <div className="ad-overview-score-inner">
                        <strong>{operationalScore}</strong>
                        <span>/ 100</span>
                      </div>
                    </div>
                    <div className="ad-overview-score-copy">
                      <span>Operational readiness</span>
                      <strong>{platformHealthy ? 'Stable' : 'Attention required'}</strong>
                      <small>{healthPct}% of applications currently healthy</small>
                    </div>
                  </div>

                  <div className="ad-overview-signal-card">
                    <span className="ad-overview-signal-label">Monitoring coverage</span>
                    <div className="ad-overview-signal-value">{coveragePct}%</div>
                    <div className="ad-overview-progress"><span style={{ width: `${coveragePct}%` }} /></div>
                    <small>{monitoredCount} of {total} apps reporting status</small>
                  </div>

                  <div className="ad-overview-signal-card">
                    <span className="ad-overview-signal-label">User experience</span>
                    <div className="ad-overview-signal-value">{avgLatency != null ? `${avgLatency} ms` : '—'}</div>
                    <div className={`ad-overview-signal-badge ${responseBand.toLowerCase().replace(' ', '-')}`}>{responseBand}</div>
                    <small>Average application response time</small>
                  </div>

                  <div className={`ad-overview-signal-card ${attentionCount ? 'needs-attention' : ''}`}>
                    <span className="ad-overview-signal-label">Action queue</span>
                    <div className="ad-overview-signal-value">{attentionCount}</div>
                    <div className="ad-overview-signal-badge">{attentionCount ? 'Investigate' : 'Clear'}</div>
                    <small>{attentionCount ? 'Apps need operator attention' : 'No operator action pending'}</small>
                  </div>
                </div>

                <div className="ad-overview-status-track" aria-label="Application health distribution">
                  <div className="ad-overview-status-track-bar">
                    {healthyCount > 0 && <span className="healthy" style={{ width: `${(healthyCount / total) * 100}%` }} />}
                    {degradedCount > 0 && <span className="degraded" style={{ width: `${(degradedCount / total) * 100}%` }} />}
                    {unavailableCount > 0 && <span className="unavailable" style={{ width: `${(unavailableCount / total) * 100}%` }} />}
                    {stoppedCount > 0 && <span className="stopped" style={{ width: `${(stoppedCount / total) * 100}%` }} />}
                  </div>
                  <div className="ad-overview-status-track-legend">
                    <span><i className="healthy" />{healthyCount} healthy</span>
                    <span><i className="degraded" />{degradedCount} partially available</span>
                    <span><i className="unavailable" />{unavailableCount} unavailable</span>
                    <span><i className="stopped" />{stoppedCount} stopped / down</span>
                  </div>
                </div>

                {priorityApps.length > 0 ? (
                  <div className="ad-overview-risk-spotlight">
                    <div className="ad-overview-risk-icon">!</div>
                    <div className="ad-overview-risk-main">
                      <div className="ad-overview-risk-kicker">TOP OPERATIONAL RISK</div>
                      <strong>{priorityApps[0].title}</strong>
                      <span>{priorityApps[0].dependencyHealth?.failingDependency || priorityApps[0].lastError?.dependency || (priorityApps[0].status === 'stopped' ? 'Application stopped' : 'Application availability')} · {priorityApps[0].status === 'degraded' ? 'Partially available: feature or dependency issue' : priorityApps[0].status === 'stopped' ? 'Service is stopped' : 'Service is unavailable'}</span>
                    </div>
                    <div className="ad-overview-risk-meta">
                      <span>Owner</span>
                      <strong>{priorityApps[0].owner || priorityApps[0].ownerName || 'Application owner'}</strong>
                    </div>
                    <button type="button" className="ad-btn ad-overview-investigate-btn" onClick={() => onNavigate('health')}>Investigate</button>
                  </div>
                ) : (
                  <div className="ad-overview-all-clear">
                    <span className="ad-overview-all-clear-icon">✓</span>
                    <div><strong>All systems operating normally</strong><small>No partially available, unavailable or stopped applications detected.</small></div>
                  </div>
                )}

                <div className="ad-overview-insight-strip">
                  <div><span>Healthy capacity</span><strong>{healthyCount}/{total}</strong></div>
                  <div><span>Critical attention</span><strong>{criticalCount}</strong></div>
                  <div><span>Monitoring coverage</span><strong>{coveragePct}%</strong></div>
                  <div><span>Last platform check</span><strong>{timeAgo(apps[0]?.lastChecked)}</strong></div>
                </div>
              </>
            )}
          </div>

          {/* ── Platform Services / Security Posture / AI Usage — MOCK, see README-DASHBOARD.md ── */}
          <div className="ad-grid-3">
            <div className="ad-panel">
              <div className="ad-panel-header"><h2 className="ad-panel-title">Platform Services</h2></div>
              {mockPlatformServices.map((svc) => (
                <div className="ad-service-row" key={svc.name}>
                  <span className="ad-service-name">{svc.name}</span>
                  <span className="ad-dot-ok">● {svc.status}</span>
                </div>
              ))}
              <div className="ad-mock-note">Illustrative — not yet wired to Azure Resource Health.</div>
            </div>

            <div className="ad-panel">
              <div className="ad-panel-header"><h2 className="ad-panel-title">Security Posture</h2></div>
              <div className="ad-score-ring-wrap">
                <div className="ad-score-ring" style={{ '--pct': mockSecurityPosture.score }}>
                  <div className="ad-score-ring-inner">{mockSecurityPosture.score}%</div>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Security Score</div>
              </div>
              {mockSecurityPosture.checks.slice(0, 5).map((c) => (
                <div className="ad-check-row" key={c.label}>
                  <span>{c.ok ? '✓' : '✕'} {c.label}</span>
                  <span style={{ color: 'var(--text-muted)' }}>{c.value}</span>
                </div>
              ))}
              <div className="ad-mock-note">Illustrative — not yet wired to Entra ID Secure Score.</div>
            </div>

            <div className="ad-panel">
              <div className="ad-panel-header"><h2 className="ad-panel-title">AI Usage (Today)</h2></div>
              <div style={{ display: 'flex', gap: 14, marginBottom: 10 }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{(mockAiUsage.requestsToday / 1000).toFixed(1)}K</div>
                  <div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Requests</div>
                </div>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{(mockAiUsage.tokensToday / 1e6).toFixed(1)}M</div>
                  <div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Tokens</div>
                </div>
              </div>
              {mockAiUsage.topModels.map((m) => (
                <div className="ad-model-row" key={m.name}>
                  <div className="ad-model-row-top"><span>{m.name}</span><span>{m.pct}%</span></div>
                  <div className="ad-model-bar-bg"><div className="ad-model-bar-fill" style={{ width: `${m.pct}%` }} /></div>
                </div>
              ))}
              <div className="ad-mock-note">Illustrative — not yet wired to Azure OpenAI usage metrics.</div>
            </div>
          </div>

          {/* ── Trends — MOCK ── */}
          <div className="ad-panel">
            <div className="ad-panel-header"><h2 className="ad-panel-title">Trends (Last 7 Days)</h2></div>
            <div className="ad-grid-4">
              <div className="ad-spark-card">
                <div className="ad-spark-top"><span className="ad-spark-label">Availability</span><span className="ad-spark-value">{mockTrends.availabilityPct}%</span></div>
                <Sparkline points={[99.9, 99.95, 99.99, 99.97, 99.98, 100, mockTrends.availabilityPct]} color="var(--green-s)" />
              </div>
              <div className="ad-spark-card">
                <div className="ad-spark-top"><span className="ad-spark-label">Avg Response Time</span><span className="ad-spark-value">{mockTrends.avgResponseMs} ms</span></div>
                <Sparkline points={[40, 38, 42, 36, 33, 35, mockTrends.avgResponseMs]} color="var(--kpmg-blue-light)" />
              </div>
              <div className="ad-spark-card">
                <div className="ad-spark-top"><span className="ad-spark-label">Error Rate</span><span className="ad-spark-value">{mockTrends.errorRatePct}%</span></div>
                <Sparkline points={[0.8, 0.6, 0.7, 0.5, 0.4, 0.5, mockTrends.errorRatePct]} color="var(--red-s)" />
              </div>
              <div className="ad-spark-card">
                <div className="ad-spark-top"><span className="ad-spark-label">Requests</span><span className="ad-spark-value">{(mockTrends.requestsToday / 1000).toFixed(1)}K</span></div>
                <Sparkline points={[18, 20, 19, 22, 21, 23, mockTrends.requestsToday / 1000]} color="var(--kpmg-light-purple)" />
              </div>
            </div>
            <div className="ad-mock-note">Illustrative — this app doesn't yet store day-over-day history.</div>
          </div>
        </div>

        <div>
          {/* ── What requires my attention — real, derived from apps + incidents ── */}
          <div className="ad-panel">
            <div className="ad-panel-header">
              <h2 className="ad-panel-title">What requires my attention?</h2>
              <button type="button" className="ad-panel-link" onClick={() => onNavigate('alerts')}>View all →</button>
            </div>
            {attentionItems.length === 0 ? (
              <div className="ad-empty-note">Nothing needs attention right now.</div>
            ) : (
              attentionItems.map((item) => (
                <div className="ad-attn-item" key={item.key}>
                  <div className={`ad-attn-icon ${item.crit ? 'crit' : 'warn'}`}>{item.icon}</div>
                  <div style={{ flex: 1 }}>
                    <div className="ad-attn-title">{item.title}</div>
                    <div className="ad-attn-sub">{item.sub}</div>
                  </div>
                  <div className="ad-attn-time">{item.time}</div>
                </div>
              ))
            )}
          </div>

          {/* ── Active Alerts — real, derived from incident log ── */}
          <div className="ad-panel">
            <div className="ad-panel-header">
              <h2 className="ad-panel-title">Active Alerts</h2>
              <button type="button" className="ad-panel-link" onClick={() => onNavigate('alerts')}>View all →</button>
            </div>
            <div className="ad-severity-row">
              <div className="ad-severity-cell"><div className="ad-severity-num ad-sev-critical">{criticalCount}</div><div className="ad-severity-label">Critical</div></div>
              <div className="ad-severity-cell"><div className="ad-severity-num ad-sev-high">{highCount}</div><div className="ad-severity-label">High</div></div>
              <div className="ad-severity-cell"><div className="ad-severity-num ad-sev-warning">{warningCount}</div><div className="ad-severity-label">Warning</div></div>
              <div className="ad-severity-cell"><div className="ad-severity-num ad-sev-info">{incidents.length}</div><div className="ad-severity-label">Info</div></div>
            </div>
            {incidents.slice(0, 4).map((inc) => (
              <div className="ad-check-row" key={inc.id}>
                <span>{inc.message?.slice(0, 42)}{inc.message?.length > 42 ? '…' : ''}</span>
                <span className="ad-attn-time">{timeAgo(inc.timestamp)}</span>
              </div>
            ))}
          </div>

          {/* ── Cost & Consumption ── */}
          {(() => {
            const palette = ['var(--kpmg-blue-mid)', 'var(--kpmg-light-blue)', 'var(--kpmg-light-purple)', 'var(--kpmg-green)', 'var(--kpmg-yellow)', 'var(--text-muted)'];
            const services = costView.byService || [];
            // Collapse anything past the top 5 into "Other" so the donut/legend stay readable
            // regardless of how many services Cost Management actually returns.
            const top = services.slice(0, 5);
            const restPct = services.slice(5).reduce((sum, s) => sum + s.pct, 0);
            const restAmount = services.slice(5).reduce((sum, s) => sum + s.amount, 0);
            const slices = restPct > 0.05 ? [...top, { name: 'Other', amount: restAmount, pct: restPct }] : top;

            let cumulative = 0;
            const stops = slices.map((s, i) => {
              const from = cumulative;
              cumulative += s.pct;
              return `${palette[i % palette.length]} ${from}% ${cumulative}%`;
            });

            return (
              <div className="ad-panel">
                <div className="ad-panel-header">
                  <h2 className="ad-panel-title">Cost & Consumption (This Month)</h2>
                  {realCost && <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Live — {costView.currency}</span>}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div><div style={{ fontSize: 17, fontWeight: 700 }}>${costView.totalCost.toLocaleString()}</div><div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Total Cost</div></div>
                  <div><div style={{ fontSize: 17, fontWeight: 700 }}>{costView.budget != null ? `$${costView.budget.toLocaleString()}` : '—'}</div><div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Budget</div></div>
                  <div><div style={{ fontSize: 17, fontWeight: 700 }}>{costView.consumedPct != null ? `${costView.consumedPct}%` : '—'}</div><div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>Consumed</div></div>
                </div>
                {slices.length > 0 && (
                  <div className="ad-donut-wrap">
                    <div className="ad-donut" style={{ background: `conic-gradient(${stops.join(', ')})` }}>
                      <div className="ad-donut-hole" />
                    </div>
                    <div className="ad-donut-legend">
                      {slices.map((s, i) => (
                        <div className="ad-donut-legend-row" key={s.name}>
                          <span className="ad-donut-swatch" style={{ background: palette[i % palette.length] }} />
                          {s.name} — ${s.amount.toLocaleString()} ({s.pct}%)
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {cost?.error ? (
                  <div className="ad-mock-note" style={{ color: 'var(--red-s)' }}>
                    Couldn't load real cost data: {cost.error}. Showing illustrative numbers —
                    check the Managed Identity's role assignment (see README-AZURE-COST.md).
                  </div>
                ) : !realCost ? (
                  <div className="ad-mock-note">Illustrative — set AZURE_SUBSCRIPTION_ID to wire up real Azure Cost Management data (see README-AZURE-COST.md).</div>
                ) : null}
              </div>
            );
          })()}

          {/* ── Recent Deployments — MOCK ── */}
          <div className="ad-panel">
            <div className="ad-panel-header">
              <h2 className="ad-panel-title">Recent Deployments</h2>
              <button type="button" className="ad-panel-link" onClick={() => onNavigate('deployments')}>View all →</button>
            </div>
            {mockRecentDeployments.map((d) => (
              <div className="ad-deploy-row" key={d.app}>
                <div className="ad-deploy-icon">⇪</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>{d.app}</div>
                  <div style={{ color: 'var(--text-muted)', fontSize: 10.5 }}>{d.team} · {d.when}</div>
                </div>
                <span className="ad-status-pill ok">{d.status}</span>
              </div>
            ))}
            <div className="ad-mock-note">Illustrative — this app doesn't yet track deployment history.</div>
          </div>
        </div>
      </div>
    </>
  );
}

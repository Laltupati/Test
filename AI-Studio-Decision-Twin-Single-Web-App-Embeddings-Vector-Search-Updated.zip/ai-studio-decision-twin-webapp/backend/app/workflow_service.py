"""Allow-listed starter templates and structural validation for workflows."""
from typing import Any

TEMPLATES: dict[str, list[dict[str, Any]]] = {
    "risk": [
        {"id":"start","type":"start","label":"Business question","description":"Define the risk question","config":{}},
        {"id":"knowledge","type":"knowledge","label":"Retrieve evidence","description":"Search approved sources (connector not wired in this POC)","config":{}},
        {"id":"agent","type":"agent","label":"Risk analyst","description":"Organise evidence and options (model not wired in this POC)","config":{}},
        {"id":"approval","type":"approval","label":"Human approval","description":"Review before consequential action","config":{}},
        {"id":"output","type":"output","label":"Decision dossier","description":"Prepare a structured result","config":{}},
    ],
    "documents": [
        {"id":"start","type":"start","label":"Document request","description":"Define the question","config":{}},
        {"id":"knowledge","type":"knowledge","label":"Retrieve documents","description":"Approved document source placeholder","config":{}},
        {"id":"agent","type":"agent","label":"Summarise evidence","description":"Model integration not enabled","config":{}},
        {"id":"output","type":"output","label":"Summary","description":"Return structured findings","config":{}},
    ],
    "decision": [
        {"id":"start","type":"start","label":"Decision question","description":"Define options and assumptions","config":{}},
        {"id":"simulation","type":"simulation","label":"Scenario simulation","description":"Run transparent calculations","config":{}},
        {"id":"approval","type":"approval","label":"Human review","description":"Review assumptions and results","config":{}},
        {"id":"output","type":"output","label":"Decision brief","description":"Summarise options and limitations","config":{}},
    ],
    "itops": [
        {"id":"start","type":"start","label":"Operational alert","description":"Define issue and scope","config":{}},
        {"id":"knowledge","type":"knowledge","label":"Retrieve runbooks","description":"Runbook source placeholder","config":{}},
        {"id":"agent","type":"agent","label":"Triage assistant","description":"Model integration not enabled","config":{}},
        {"id":"approval","type":"approval","label":"Operator approval","description":"Approve remediation before action","config":{}},
        {"id":"output","type":"output","label":"Incident summary","description":"Produce triage notes","config":{}},
    ],
}

def list_templates() -> list[dict[str, str]]:
    return [{"id": key, "name": key.title(), "description": f"Predefined {key} workflow starter"} for key in TEMPLATES]

def draft_workflow(prompt: str, template: str) -> dict[str, Any]:
    """Return an approved template; this is intentionally not a live LLM call."""
    key = template if template in TEMPLATES else "risk"
    nodes = [dict(node) for node in TEMPLATES[key]]
    edges = [{"id": f"e{i+1}", "source": nodes[i]["id"], "target": nodes[i+1]["id"]} for i in range(len(nodes)-1)]
    return {"name": f"{key.title()} workflow", "description": prompt, "template": key, "nodes": nodes, "edges": edges,
            "note": "Generated from a predefined demo template; no live LLM was called."}

def validate_workflow(workflow: dict[str, Any]) -> dict[str, Any]:
    nodes, edges = workflow.get("nodes", []), workflow.get("edges", [])
    errors: list[str] = []
    warnings: list[str] = []
    ids = [node.get("id") for node in nodes]
    known_ids = set(ids)
    if not nodes: errors.append("Workflow must contain at least one node.")
    if len(ids) != len(known_ids): errors.append("Node IDs must be unique.")
    if sum(1 for node in nodes if node.get("type") == "start") != 1: errors.append("Workflow must contain exactly one start node.")
    if not any(node.get("type") == "output" for node in nodes): errors.append("Workflow should contain an output node.")
    for edge in edges:
        if edge.get("source") not in known_ids or edge.get("target") not in known_ids:
            errors.append(f"Connection {edge.get('id', '(unnamed)')} references a missing node.")
    if not any(node.get("type") == "approval" for node in nodes): warnings.append("No human approval node found. Add one before consequential actions.")
    if not edges and len(nodes) > 1: warnings.append("Multiple nodes exist but there are no connections.")
    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings, "node_count": len(nodes), "edge_count": len(edges)}

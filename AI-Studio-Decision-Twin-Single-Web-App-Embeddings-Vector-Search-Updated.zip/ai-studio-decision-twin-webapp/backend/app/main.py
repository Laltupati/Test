"""FastAPI entry point for the standalone AI Studio + Decision Twin POC."""
import os
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .config import cors_origins
from .schemas import WorkflowValidationRequest, WorkflowDraftRequest, SimulationRequest
from .workflow_service import list_templates, draft_workflow, validate_workflow
from .simulation import simulate
from .integrations import integration_status, answer_query

STATIC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "static"))

app = FastAPI(title="AI Studio + Decision Twin API", version="0.2.0", description="Client-demo starter. Configure integrations and security before production use.")
app.add_middleware(CORSMiddleware, allow_origins=cors_origins(), allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["Content-Type", "Authorization"] )

class QueryRequest(BaseModel):
    mode: str = Field(pattern="^(workflow|documents|scenario|security)$")
    query: str = Field(min_length=3, max_length=12000)

@app.get("/api/search/index/status")
def search_index_info():
    from .integrations import search_index_status
    return search_index_status()

@app.get("/api/health")
def health():
    return {"status": "ok", "environment": os.getenv("APP_ENV", "development")}

@app.get("/api/integrations/status")
def integrations():
    return integration_status()

@app.post("/api/query")
def run_query(request: QueryRequest):
    try:
        return answer_query(request.mode, request.query)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        # Do not return stack traces, credentials, or provider payloads to the browser.
        print(f"Query execution failed: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=502, detail="The query could not be completed. Check backend logs and Azure service configuration.") from exc

@app.get("/api/workflows/templates")
def workflow_templates():
    return {"templates": list_templates()}

@app.post("/api/workflows/validate")
def workflow_validate(request: WorkflowValidationRequest):
    return validate_workflow(request.workflow.model_dump())

@app.post("/api/workflows/draft")
def workflow_draft(request: WorkflowDraftRequest):
    return draft_workflow(request.prompt, request.template)

@app.post("/api/decision-twin/simulate")
def decision_twin_simulate(request: SimulationRequest):
    return simulate(request.model_dump())


@app.get("/{full_path:path}", include_in_schema=False)
def serve_frontend(full_path: str):
    """Serve the built React/Vite SPA from the same App Service as FastAPI.

    API routes above take precedence. Unknown frontend routes fall back to index.html
    to support client-side routing; missing asset files return 404.
    """
    from pathlib import Path

    static_root = Path(STATIC_DIR).resolve()
    requested = (static_root / full_path).resolve()
    if requested != static_root and static_root not in requested.parents:
        raise HTTPException(status_code=403, detail="Forbidden")

    if requested.is_file():
        return FileResponse(requested)

    # If frontend assets haven't been built/copied yet, keep API endpoints usable.
    index_file = static_root / "index.html"
    if not index_file.is_file():
        raise HTTPException(404, detail="Frontend build not found. Build frontend and copy dist/ to backend/static/.")

    # Paths that look like missing assets should not return index.html.
    if Path(full_path).suffix:
        raise HTTPException(404, detail="Asset not found")
    return FileResponse(index_file)

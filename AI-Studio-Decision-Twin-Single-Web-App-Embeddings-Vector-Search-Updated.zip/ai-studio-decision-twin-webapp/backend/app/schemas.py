"""Request/response schemas. Pydantic checks the shape and basic types of API data."""
from typing import Any
from pydantic import BaseModel, Field

class WorkflowNode(BaseModel):
    id: str = Field(min_length=1, max_length=120)
    type: str = Field(min_length=1, max_length=60)
    label: str = Field(min_length=1, max_length=200)
    description: str = ""
    config: dict[str, Any] = Field(default_factory=dict)

class WorkflowEdge(BaseModel):
    id: str = Field(min_length=1, max_length=120)
    source: str = Field(min_length=1, max_length=120)
    target: str = Field(min_length=1, max_length=120)

class WorkflowDefinition(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str = ""
    nodes: list[WorkflowNode] = Field(default_factory=list)
    edges: list[WorkflowEdge] = Field(default_factory=list)

class WorkflowValidationRequest(BaseModel):
    workflow: WorkflowDefinition

class WorkflowDraftRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    template: str = "risk"

class SimulationRequest(BaseModel):
    baseline_exposure: float = Field(ge=0)
    cost_increase_pct: float = Field(ge=0, le=1000)
    exposure_pct: float = Field(ge=0, le=100)
    mitigation_effectiveness_pct: float = Field(ge=0, le=100)
    scenarios: list[str] = Field(default_factory=list)

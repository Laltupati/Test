"""Transparent, deterministic illustrative scenario calculations."""
from typing import Any

def simulate(payload: dict[str, Any]) -> dict[str, Any]:
    baseline = float(payload["baseline_exposure"])
    cost_increase = float(payload["cost_increase_pct"]) / 100.0
    exposure = float(payload["exposure_pct"]) / 100.0
    mitigation = float(payload["mitigation_effectiveness_pct"]) / 100.0
    gross = baseline * exposure * (1.0 + cost_increase)
    residual = gross * (1.0 - mitigation)
    avoided = gross - residual
    return {
        "assumptions": {"baseline_exposure": baseline, "cost_increase_pct": payload["cost_increase_pct"],
                        "exposure_pct": payload["exposure_pct"], "mitigation_effectiveness_pct": payload["mitigation_effectiveness_pct"],
                        "scenarios": payload.get("scenarios", [])},
        "results": {"gross_impact": round(gross, 2), "residual_impact": round(residual, 2), "illustrative_avoided_impact": round(avoided, 2)},
        "limitations": ["Illustrative sensitivity calculation only; not a forecast, financial advice, or causal estimate.",
                        "Results depend entirely on user-supplied assumptions and are not calibrated against real business data."],
    }

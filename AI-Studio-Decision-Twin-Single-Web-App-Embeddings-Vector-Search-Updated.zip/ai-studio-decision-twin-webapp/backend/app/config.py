"""Small configuration module for the AI Studio demo."""
import os

def cors_origins() -> list[str]:
    """Read comma-separated browser origins from CORS_ORIGINS."""
    raw = os.getenv("CORS_ORIGINS", "http://localhost:5173")
    return [item.strip() for item in raw.split(",") if item.strip()]

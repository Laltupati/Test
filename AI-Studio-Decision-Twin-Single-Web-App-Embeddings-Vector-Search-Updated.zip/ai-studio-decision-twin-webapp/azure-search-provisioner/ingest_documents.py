"""Generate embeddings for prepared text documents and upload chunks to Azure AI Search.

Input JSON may be a list of objects or JSON Lines. Each record needs `content`;
`title`, `source`, and `id` are optional. This utility does not extract PDF/DOCX/PPTX.
"""
import argparse
import json
import os
import sys
import uuid
from pathlib import Path

from dotenv import load_dotenv
from openai import AzureOpenAI
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient

load_dotenv()


def chunks(text: str, size: int, overlap: int):
    text = " ".join(text.split())
    if not text:
        return
    start = 0
    while start < len(text):
        end = min(len(text), start + size)
        yield text[start:end]
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)


def load_records(path: Path):
    raw = path.read_text(encoding="utf-8")
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            parsed = [parsed]
        if not isinstance(parsed, list):
            raise ValueError("JSON input must be an object or a list of objects.")
        return parsed
    except json.JSONDecodeError:
        records = []
        for line_number, line in enumerate(raw.splitlines(), start=1):
            if line.strip():
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSON on line {line_number}.") from exc
        return records


def main() -> int:
    parser = argparse.ArgumentParser(description="Embed text records and upload them to Azure AI Search.")
    parser.add_argument("input_file", help="JSON or JSONL file containing document records")
    parser.add_argument("--chunk-size", type=int, default=3000, help="Characters per chunk (default: 3000)")
    parser.add_argument("--overlap", type=int, default=300, help="Character overlap between chunks (default: 300)")
    args = parser.parse_args()

    if args.chunk_size < 100 or args.overlap < 0 or args.overlap >= args.chunk_size:
        print("Use --chunk-size >= 100 and 0 <= --overlap < --chunk-size.", file=sys.stderr)
        return 2

    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
    embedding_deployment = (
        os.getenv("AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "")
    ).strip()
    dimensions = int(os.getenv("AZURE_OPENAI_EMBEDDINGS_DIMENSIONS", "1536"))

    search_endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "").strip()
    search_index = os.getenv("AZURE_SEARCH_INDEX", "").strip()
    search_key = (os.getenv("AZURE_SEARCH_ADMIN_KEY") or os.getenv("AZURE_SEARCH_API_KEY", "")).strip()

    if not all([endpoint, api_key, embedding_deployment, search_endpoint, search_index, search_key]):
        print(
            "Missing configuration. Set AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, "
            "AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT, AZURE_SEARCH_ENDPOINT, AZURE_SEARCH_INDEX, "
            "and AZURE_SEARCH_ADMIN_KEY (or AZURE_SEARCH_API_KEY).",
            file=sys.stderr,
        )
        return 2

    input_path = Path(args.input_file)
    if not input_path.is_file():
        print(f"Input file not found: {input_path}", file=sys.stderr)
        return 2

    title_field = os.getenv("AZURE_SEARCH_TITLE_FIELD", "title")
    content_field = os.getenv("AZURE_SEARCH_CONTENT_FIELD", "content")
    source_field = os.getenv("AZURE_SEARCH_SOURCE_FIELD", "source")
    vector_field = os.getenv("AZURE_SEARCH_VECTOR_FIELD", "contentVector")

    try:
        records = load_records(input_path)
        if not records:
            print("No records found in input file.", file=sys.stderr)
            return 2

        aoai = AzureOpenAI(azure_endpoint=endpoint, api_key=api_key, api_version=api_version)
        search = SearchClient(
            endpoint=search_endpoint,
            index_name=search_index,
            credential=AzureKeyCredential(search_key),
        )

        documents = []
        for record_number, record in enumerate(records, start=1):
            if not isinstance(record, dict):
                print(f"Skipping record {record_number}: expected a JSON object.")
                continue
            content = str(record.get("content", "")).strip()
            if not content:
                print(f"Skipping record {record_number}: missing content.")
                continue
            title = str(record.get("title") or f"Document {record_number}")
            source = str(record.get("source") or record.get("filename") or title)
            base_id = str(record.get("id") or uuid.uuid5(uuid.NAMESPACE_URL, f"{source}:{title}"))
            for chunk_number, chunk_text in enumerate(chunks(content, args.chunk_size, args.overlap), start=1):
                embedding_response = aoai.embeddings.create(
                    model=embedding_deployment,
                    input=chunk_text,
                )
                vector = embedding_response.data[0].embedding
                if len(vector) != dimensions:
                    raise ValueError(
                        f"Embedding model returned {len(vector)} dimensions, but configured dimensions are "
                        f"{dimensions}. Align AZURE_OPENAI_EMBEDDINGS_DIMENSIONS and the index schema."
                    )
                documents.append({
                    "id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"{base_id}:chunk:{chunk_number}")),
                    title_field: title,
                    content_field: chunk_text,
                    source_field: source,
                    vector_field: vector,
                })

        if not documents:
            print("No valid text chunks to upload.", file=sys.stderr)
            return 2

        batch_size = 100
        uploaded = 0
        for offset in range(0, len(documents), batch_size):
            results = search.upload_documents(documents=documents[offset:offset + batch_size])
            failed = [r for r in results if not r.succeeded]
            if failed:
                errors = "; ".join(f"{r.key}: {r.error_message}" for r in failed[:5])
                raise RuntimeError(f"{len(failed)} document chunk(s) failed to upload: {errors}")
            uploaded += len(results)

        print(f"Uploaded {uploaded} embedded chunk(s) to index '{search_index}'.")
        print("If these documents already existed under different IDs, remove/reconcile duplicates as needed.")
        return 0
    except Exception as exc:
        print(f"Ingestion failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

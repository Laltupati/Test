"""Standalone Azure AI Search index provisioner, including vector-search schema."""
import os
import sys

from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import ResourceNotFoundError, AzureError
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
)

load_dotenv()


def required_fields():
    title = os.getenv("AZURE_SEARCH_TITLE_FIELD", "title").strip() or "title"
    content = os.getenv("AZURE_SEARCH_CONTENT_FIELD", "content").strip() or "content"
    source = os.getenv("AZURE_SEARCH_SOURCE_FIELD", "source").strip() or "source"
    vector_field = os.getenv("AZURE_SEARCH_VECTOR_FIELD", "contentVector").strip() or "contentVector"
    dimensions = int(os.getenv("AZURE_OPENAI_EMBEDDINGS_DIMENSIONS", "1536"))

    candidates = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True, filterable=True),
        SearchableField(name=title, type=SearchFieldDataType.String, searchable=True),
        SearchableField(name=content, type=SearchFieldDataType.String, searchable=True),
        SimpleField(name=source, type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="metadata_storage_name", type=SearchFieldDataType.String, filterable=True),
        SearchField(
            name=vector_field,
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=dimensions,
            vector_search_profile_name="content-vector-profile",
        ),
    ]
    result, seen = [], set()
    for field in candidates:
        if field.name not in seen:
            result.append(field)
            seen.add(field.name)
    return result


def ensure_vector_search(index):
    """Ensure the index has the HNSW algorithm and profile required by the vector field."""
    if index.vector_search is None:
        index.vector_search = VectorSearch(
            algorithms=[HnswAlgorithmConfiguration(name="content-hnsw")],
            profiles=[VectorSearchProfile(
                name="content-vector-profile",
                algorithm_configuration_name="content-hnsw",
            )],
        )
        return

    algorithms = list(index.vector_search.algorithms or [])
    profiles = list(index.vector_search.profiles or [])
    if not any(item.name == "content-hnsw" for item in algorithms):
        algorithms.append(HnswAlgorithmConfiguration(name="content-hnsw"))
    if not any(item.name == "content-vector-profile" for item in profiles):
        profiles.append(VectorSearchProfile(
            name="content-vector-profile",
            algorithm_configuration_name="content-hnsw",
        ))
    index.vector_search.algorithms = algorithms
    index.vector_search.profiles = profiles


def main() -> int:
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "").strip()
    index_name = os.getenv("AZURE_SEARCH_INDEX", "").strip()
    admin_key = os.getenv("AZURE_SEARCH_ADMIN_KEY", "").strip()
    if not endpoint or not index_name or not admin_key:
        print(
            "Set AZURE_SEARCH_ENDPOINT, AZURE_SEARCH_INDEX, and AZURE_SEARCH_ADMIN_KEY.",
            file=sys.stderr,
        )
        return 2

    try:
        client = SearchIndexClient(endpoint=endpoint, credential=AzureKeyCredential(admin_key))
        wanted = required_fields()
        try:
            current = client.get_index(index_name)
        except ResourceNotFoundError:
            created = client.create_index(SearchIndex(
                name=index_name,
                fields=wanted,
                vector_search=VectorSearch(
                    algorithms=[HnswAlgorithmConfiguration(name="content-hnsw")],
                    profiles=[VectorSearchProfile(
                        name="content-vector-profile",
                        algorithm_configuration_name="content-hnsw",
                    )],
                ),
            ))
            print(
                f"Created index '{created.name}'. Fields: "
                + ", ".join(field.name for field in created.fields)
            )
            print("Vector field and vector-search profile are configured.")
            return 0

        existing_names = {field.name for field in current.fields}
        missing = [field for field in wanted if field.name not in existing_names]
        ensure_vector_search(current)
        if not missing and current.vector_search is None:
            print(f"Index '{index_name}' already has all required fields.")
            return 0

        if missing:
            current.fields = list(current.fields) + missing
        updated = client.create_or_update_index(current)
        print(f"Updated index '{updated.name}'.")
        if missing:
            print("Added fields: " + ", ".join(field.name for field in missing))
        else:
            print("Added/verified vector-search configuration.")
        print("IMPORTANT: Existing documents are not automatically embedded. Re-ingest or update documents to populate the vector field.")
        return 0
    except (ValueError, AzureError) as exc:
        print(f"Azure AI Search provisioning failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

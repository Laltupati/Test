# Azure AI Search Provisioner and Document Ingestion

This folder contains two standalone scripts. Run them separately from the web app.

## 1. Configure

Copy `.env.example` to `.env` and set:
- `AZURE_SEARCH_ENDPOINT`
- `AZURE_SEARCH_INDEX`
- `AZURE_SEARCH_ADMIN_KEY` (index schema management; keep secret)
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` (the exact deployed embedding deployment name)
- `AZURE_OPENAI_EMBEDDINGS_DIMENSIONS=1536` for the default `text-embedding-3-small` configuration
- Optional field names; defaults are `title`, `content`, `source`, and `contentVector`.

If GPT and embeddings deployments are in the same Azure OpenAI resource, the same endpoint and API key can be reused. Otherwise, separate embedding endpoint/key settings must be added to the ingestion/backend code.

## 2. Install dependencies

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -r requirements.txt
```

## 3. Create or update the index schema

```bash
python provision_index.py
```

The script creates the index and basic fields if absent, and configures the `contentVector` vector field and HNSW profile. It does not delete fields or documents. If an existing index has incompatible field definitions, review the Azure error and create a new index rather than forcing a destructive schema change.

## 4. Prepare document text

Create a JSON file such as `documents.json`:

```json
[
  {
    "id": "policy-001",
    "title": "Example Policy",
    "source": "policies/example-policy.txt",
    "content": "Paste the extracted text of the document here."
  }
]
```

`content` must already be extracted text. This utility does not parse PDF, DOCX, PPTX, or Blob Storage files.

## 5. Generate embeddings and upload chunks

```bash
python ingest_documents.py documents.json
```

The script chunks the supplied text, creates embeddings using the configured Azure OpenAI deployment, and uploads each chunk and vector into Azure AI Search. It uses deterministic chunk IDs so rerunning the same source can replace the same chunks.

## 6. Backend configuration

In the App Service environment variables, set:
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_DEPLOYMENT` (GPT chat deployment)
- `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` (embedding deployment)
- `AZURE_OPENAI_EMBEDDINGS_DIMENSIONS=1536`
- `AZURE_SEARCH_ENDPOINT`
- `AZURE_SEARCH_INDEX`
- `AZURE_SEARCH_API_KEY` (query key or admin key)
- `AZURE_SEARCH_TITLE_FIELD=title`
- `AZURE_SEARCH_CONTENT_FIELD=content`
- `AZURE_SEARCH_SOURCE_FIELD=source`
- `AZURE_SEARCH_VECTOR_FIELD=contentVector`

The backend's document query path performs hybrid keyword + vector search and then passes retrieved excerpts to the GPT chat deployment.

**Important:** If you already have documents in an index created before the vector field existed, the schema update does not backfill vectors. Re-ingest documents or use a controlled migration to populate `contentVector` before expecting vector retrieval to return results.

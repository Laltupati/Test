# Testing Guide

## Before testing
Use synthetic data only. Run the backend and frontend locally using the README. Keep the API terminal open so you can see request errors.

## Manual test checklist

| Test | Action | Expected result |
|---|---|---|
| Frontend startup | Open the Vite URL | AI Studio screen loads |
| API health | Open `http://localhost:8000/api/health` | JSON contains `status: ok` |
| API docs | Open `http://localhost:8000/docs` | Interactive FastAPI docs appear |
| Draft workflow | Enter a prompt and click Generate draft | A predefined workflow appears; UI must not imply an LLM was called |
| Validate workflow | Click Validate workflow | Validity, node count and connection count appear |
| Broken edge | In a local test, submit an edge with an unknown source or target | Validation returns an error |
| Missing approval | Submit a valid workflow without an approval node | Validation warns about human approval |
| Simulation | Use the default inputs and run simulation | Gross impact $460,000; residual $230,000; illustrative avoided impact $230,000 |
| Input validation | Submit percentages outside allowed ranges directly to API | FastAPI returns HTTP 422 validation error |
| Export | Click Export/save workflow | JSON file downloads and can be parsed |
| Backend offline | Stop backend and refresh/use UI | UI shows offline/fallback behavior rather than claiming the backend succeeded |
| CORS | Use an unapproved browser origin | Browser should block reading the API response; remember CORS is not authentication |

## Suggested automated tests

### Unit tests
- `validate_workflow`: empty graph, duplicate IDs, missing start, missing output, broken edges, missing approval warning.
- `simulate`: zero exposure, zero mitigation, 100% mitigation, and known example values.
- `draft_workflow`: known template and unknown template fallback.

### API tests
- Health endpoint returns 200.
- Valid workflow payload returns `valid: true`.
- Invalid types/ranges return 422.
- Simulation response contains assumptions, results and limitations.

### Frontend tests
- Navigation changes active screen.
- Add-node action creates a visible node.
- API success and failure states are understandable.
- Keyboard navigation and contrast meet accessibility requirements.

## Release gate
Do not call this production-ready until authentication, authorization, automated tests, security scans, monitoring, privacy review and rollback procedures are in place.

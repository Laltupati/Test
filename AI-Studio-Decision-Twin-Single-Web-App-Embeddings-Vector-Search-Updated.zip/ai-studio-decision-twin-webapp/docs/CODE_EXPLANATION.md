# Code Explanation (Beginner-Friendly)

## Project layout

```text
ai-studio-decision-twin-webapp/
├── frontend/
│   ├── src/App.tsx       # Main screen, UI state, API calls and formulas shown in the UI
│   ├── src/main.tsx      # React entry point; mounts the App component
│   ├── src/styles.css    # Visual layout and colors
│   ├── index.html        # Browser page shell
│   ├── vite.config.ts    # Frontend development/build configuration
│   ├── package.json      # Node dependencies and scripts
│   └── server.js         # Serves the compiled frontend on App Service
├── backend/
│   ├── app/main.py       # FastAPI application and HTTP endpoints
│   ├── app/schemas.py    # Request validation models
│   ├── app/config.py     # Reads environment-based configuration
│   ├── app/workflow_service.py # Draft templates and workflow checks
│   ├── app/simulation.py # Scenario calculation
│   └── requirements.txt  # Python packages
├── docs/                 # Design, learning, deployment and testing documents
└── azure-pipelines-*.yml # Example Azure DevOps deployment pipelines
```

## Frontend files

### `frontend/src/main.tsx`
This is the entry point for React. It finds the root HTML element and renders the `App` component inside it. Most application behavior is in `App.tsx`.

### `frontend/src/App.tsx`
This file creates the four main areas: Workflow Studio, Decision Twin, Execution Runs and Governance.

Key concepts used:
- `useState`: stores values that change while a user interacts with the page, such as the selected tab, slider values and nodes.
- `useNodesState` / `useEdgesState`: React Flow helpers for managing diagram nodes and connections.
- `onConnect`: adds a connection when the user draws an edge between nodes.
- `fetch(...)`: sends HTTP requests from the browser to the backend.
- `workflowPayload`: converts the visual nodes and edges into the JSON structure expected by the API.
- `validateWorkflow()`: calls the backend validation endpoint. If the API is unavailable, the screen falls back to a small local check.
- `createDraft()`: asks the backend for a predefined template and maps the returned nodes/edges into React Flow elements. It does not invoke an LLM.
- `runSimulation()`: calls the simulation endpoint and displays results; if the backend is offline, it calculates the same simple formula locally.
- `saveDraft()`: downloads the current workflow as a JSON file. This is a local download, not a save to a database.

### `frontend/src/styles.css`
Controls the visual design, including layout, colors, cards, side navigation, buttons, and responsive behavior. Styling does not implement business logic.

### `frontend/server.js`
Serves the production-built static files from `frontend/dist`. It returns `index.html` for frontend routes so a browser refresh on a single-page-app route can still load the app. It is not the Python API server.

### `frontend/package.json`
Defines commands:
- `npm run dev`: local Vite development server.
- `npm run build`: TypeScript checks and creates the production bundle in `dist/`.
- `npm start`: starts `server.js` for Azure App Service.

## Backend files

### `backend/app/main.py`
Creates the FastAPI application, enables CORS for configured frontend origins and defines endpoints. Each endpoint accepts a request model, calls a service function and returns a Python dictionary that FastAPI serializes as JSON.

### `backend/app/schemas.py`
Defines the shape and limits of incoming data. For example, percentages are bounded and strings have maximum lengths. This helps reject malformed requests before service code runs. Schema validation is not the same as authorization or business approval.

### `backend/app/config.py`
Reads `CORS_ORIGINS` from an environment variable. CORS controls which browser origins can read API responses; it is **not authentication** and does not protect the API from direct non-browser requests.

### `backend/app/workflow_service.py`
Contains the approved demo templates (`risk`, `documents`, `decision`, `itops`) and structural validation rules. The draft function returns a stored template; the user's prompt is retained as the workflow description. No AI model is called. Validation checks unique IDs, a single start node, an output node and valid edge references. It warns if no human-approval node exists.

### `backend/app/simulation.py`
Uses arithmetic to calculate gross, residual and illustrative avoided impact. It does not call AI, query a database or read business data. The response includes assumptions and limitations so users can interpret the numbers carefully.

### `backend/requirements.txt`
Lists Python libraries installed for the backend: FastAPI for HTTP APIs, Uvicorn/Gunicorn for serving the app, and Pydantic for request validation.

## API request lifecycle example: Validate workflow

1. The user clicks **Validate workflow**.
2. `App.tsx` serializes the workflow into JSON and sends `POST /api/workflows/validate`.
3. FastAPI parses the request using `WorkflowValidationRequest` and `WorkflowDefinition` schemas.
4. `validate_workflow()` checks structure and connections.
5. FastAPI returns fields such as `valid`, `errors`, `warnings`, `node_count`, and `edge_count`.
6. The frontend turns that response into a short message.

## API request lifecycle example: Scenario simulation

1. The user changes scenario sliders and clicks **Run simulation**.
2. The frontend sends the four numeric inputs to `POST /api/decision-twin/simulate`.
3. Pydantic checks the allowed ranges.
4. `simulate()` converts percentages into fractions and applies the formulas.
5. The backend returns assumptions, results and limitations.
6. The frontend renders the result.

## How to safely add a real LLM later

1. Select an approved model service and identity method with your cloud/security team.
2. Call the model only from the backend, never directly from browser code with a secret key.
3. Ask the model to return a constrained workflow schema, not executable code.
4. Validate the proposed nodes against an allow-list and reject unknown node types.
5. Require human approval before consequential external actions.
6. Log the user, model/deployment version, input references, tool calls, approvals and result metadata while avoiding unnecessary sensitive content.
7. Add evaluation tests, prompt-injection tests, rate limits, cost controls and monitoring.

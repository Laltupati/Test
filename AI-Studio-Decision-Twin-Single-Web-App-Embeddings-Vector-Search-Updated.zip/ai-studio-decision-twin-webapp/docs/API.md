# API Reference

Base URL: `http://localhost:8000`

## `GET /api/health`
Returns demo API health.

## `GET /api/workflows/templates`
Returns available starter workflow templates.

## `POST /api/workflows/validate`
Request:
```json
{
  "workflow": {
    "name": "Supplier risk",
    "description": "Assess supplier risk",
    "nodes": [
      {"id":"start","type":"start","label":"Start","description":"","config":{}},
      {"id":"output","type":"output","label":"Output","description":"","config":{}}
    ],
    "edges": [{"id":"e1","source":"start","target":"output"}]
  }
}
```

## `POST /api/workflows/draft`
Request:
```json
{"prompt":"Assess supplier risk using approved data and create a report","template":"risk"}
```
Templates: `risk`, `documents`, `decision`, `itops`. This is template-based demo drafting, not an LLM generation call.

## `POST /api/decision-twin/simulate`
Request:
```json
{
  "baseline_exposure": 2000000,
  "cost_increase_pct": 15,
  "exposure_pct": 20,
  "mitigation_effectiveness_pct": 50,
  "scenarios": ["Before mitigation", "After mitigation"]
}
```
Response includes assumptions, results and limitations. Values are illustrative.

## Additional integration endpoints

- `GET /api/integrations/status` — returns boolean configuration status and deployment/index names only; never returns credentials.
- `POST /api/query` — request body `{ "mode": "workflow|documents|scenario|security", "query": "..." }`. Requires Azure OpenAI configuration. The `documents` mode also requires Azure AI Search and a populated index. Response contains answer, deployment name, optional source references, token usage, and a verification disclaimer.

# Azure App Service Deployment Checklist (No Docker)

## Before deployment
- [ ] Confirm the approved Azure subscription, region, naming convention and environment.
- [ ] Create a Linux Node.js App Service for the frontend and a Linux Python App Service for the backend.
- [ ] Use HTTPS-only and an approved App Service Plan.
- [ ] Create/confirm the Azure DevOps service connection and least-privilege deployment rights.
- [ ] Confirm the exact frontend and backend App Service names.

## Backend
- [ ] Deploy the contents of `backend/` with `app/` and `requirements.txt` at the package root.
- [ ] Set Python runtime to 3.12 (or the runtime approved and tested by your environment).
- [ ] Startup command: `gunicorn --bind=0.0.0.0:8000 --workers=2 --timeout=600 --worker-class=uvicorn.workers.UvicornWorker app.main:app`.
- [ ] Set `SCM_DO_BUILD_DURING_DEPLOYMENT=true` where required by the selected App Service build configuration.
- [ ] Set `APP_ENV=development` for the demo.
- [ ] Set `CORS_ORIGINS` to the exact frontend HTTPS origin.
- [ ] Verify `/api/health` and `/docs`.

## Frontend
- [ ] Build with `VITE_API_BASE_URL=https://<backend-app>.azurewebsites.net`.
- [ ] Run `npm install` and `npm run build`.
- [ ] Deploy `dist/`, `server.js`, and `package.json` at the package root.
- [ ] Set Node.js runtime to a supported LTS version approved by your Azure configuration.
- [ ] Set startup command to `npm start`.
- [ ] Verify the frontend loads and browser network requests reach the backend.

## After deployment
- [ ] Test workflow draft, validation, simulation and JSON export.
- [ ] Check App Service deployment logs and Log stream.
- [ ] Confirm CORS uses the correct exact origin and does not use `*` for a credentialed production setup.
- [ ] Confirm no secrets are in source code, frontend bundles, pipeline logs or browser storage.
- [ ] Do not expose the POC to sensitive data or real business decisions until identity, authorization and audit controls are implemented.

## Important note about pipelines
The YAML files are starter examples. Verify the task inputs, artifact paths, service connection name, App Service runtime and package structure against the Azure DevOps task version and your tenant configuration before running them.

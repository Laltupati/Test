# Requirements and Implementation Roadmap

## Functional requirements

| ID | Requirement | Current implementation |
|---|---|---|
| FR-01 | View and edit a visual workflow | Implemented in browser UI |
| FR-02 | Add workflow components | Implemented in UI |
| FR-03 | Connect components | Implemented in React Flow |
| FR-04 | Generate a starter workflow | Predefined templates only |
| FR-05 | Validate basic workflow structure | Backend API implemented |
| FR-06 | Export workflow JSON | Local browser download |
| FR-07 | Compare scenario assumptions | Illustrative arithmetic model |
| FR-08 | View governance gaps | Informational prototype cards |
| FR-09 | Persist run history | Not implemented |
| FR-10 | Execute AI workflows | Not implemented |

## Non-functional requirements for a production successor
- Identity: enterprise sign-in and server-side authorization.
- Security: secret management, least privilege, dependency scanning, secure headers, rate limiting and abuse controls.
- Privacy: data classification, retention, redaction and approved data-source policies.
- Reliability: health checks, timeouts, retry policy, graceful failure and operational alerting.
- Observability: request correlation IDs, latency/error metrics, model token/cost metrics and traces.
- Quality: unit, API, UI, security and AI evaluation tests.
- Governance: versioned workflows, approval gates, audit history and change management.
- Accessibility: keyboard operation, contrast and screen-reader testing.

## Suggested roadmap

### Phase 0 — Understand and run the POC
- Run frontend and backend locally.
- Learn the four screens and API calls.
- Test workflow validation and scenario assumptions.
- Keep all data synthetic.

### Phase 1 — Harden the web application
- Add Entra ID authentication and role-based authorization.
- Add server-side authorization to every API route.
- Add input limits, rate limits, security headers and request logging.
- Configure App Service health checks and Application Insights.
- Add automated tests and security scans to Azure DevOps.

### Phase 2 — Add a real model in a controlled way
- Choose an approved Azure AI model deployment.
- Use managed identity if supported by the chosen service.
- Implement server-side model calls and schema-constrained output.
- Add model evaluation and prompt-injection tests.
- Record model/deployment version, latency, token usage and errors.

### Phase 3 — Add grounded knowledge retrieval
- Define approved sources and data owners.
- Ingest, chunk and index documents using an approved search service.
- Enforce source permissions during retrieval.
- Show citations and source dates.
- Test retrieval quality and resistance to malicious document instructions.

### Phase 4 — Add safe workflow execution and audit
- Implement a controlled execution engine for allow-listed node types.
- Add a durable run store and trace view.
- Add approval checkpoints for consequential operations.
- Add idempotency, timeouts, cancellation, retry policy and cost limits.
- Review operational readiness and disaster recovery.

### Phase 5 — Calibrate Decision Twin for a real use case
- Agree on the decision and outcome metrics with business owners.
- Establish data quality, lineage and baseline periods.
- Validate assumptions against historical data.
- Back-test and document uncertainty and limitations.
- Obtain domain-owner approval before using outputs operationally.

## Definition of done for production
Production readiness requires security and privacy approval, tested identity and authorization, monitored APIs, validated model/data behavior, durable audit records, operational ownership, rollback strategy, cost controls and documented support procedures. A successful demo is not sufficient evidence of production readiness.

# Azure App Service deployment (no Docker)

This is the single-web-app variant. The pipeline builds the React frontend, copies the build output into `backend/static/`, and deploys the combined app to one Linux Python Azure App Service.

## 1. Create one Web App

- Frontend: Linux App Service, Node.js 20 LTS (or another currently supported Node LTS).
- Backend: Linux App Service, Python 3.12.
- Use HTTPS-only. For a client demo, use separate app names such as `ai-studio-frontend-dev` and `ai-studio-api-dev`.
- Configure both apps for the same approved region and appropriate App Service Plan.

## 2. Deploy the combined app

Use `azure-pipelines-single-app.yml`. It builds the frontend, copies `frontend/dist/` to `backend/static/`, packages the backend and static assets together, then deploys to one Web App.

Startup command:

```bash
gunicorn --bind=0.0.0.0:8000 --workers=2 --timeout=600 --worker-class=uvicorn.workers.UvicornWorker app.main:app
```

Configure `SCM_DO_BUILD_DURING_DEPLOYMENT=true` if required by your deployment approach. Set all Azure OpenAI and Azure AI Search settings in App Service Environment variables. The frontend calls relative `/api/...` paths, so a separate backend URL and CORS origin are not needed for the same-origin deployment.

## 3. Validate

- Open `/api/health` and `/docs`.
- Open `/api/integrations/status` and verify chat, embedding, and search configuration.
- Provision the search index using the separate `azure-search-provisioner/provision_index.py` script.
- Ingest extracted document text with `azure-search-provisioner/ingest_documents.py`.
- Test Ask documents only after the index has documents with populated vector values.

## 4. Azure DevOps pipelines

Two sample pipelines are included at the repository root:
- `azure-pipelines-backend.yml`
- `azure-pipelines-frontend.yml`

Create/use an Azure Resource Manager service connection and define these pipeline variables:

Backend pipeline:
- `AZURE_SERVICE_CONNECTION`: exact service connection name
- `BACKEND_APP_NAME`: backend Web App name

Frontend pipeline:
- `AZURE_SERVICE_CONNECTION`: exact service connection name
- `FRONTEND_APP_NAME`: frontend Web App name
- `BACKEND_BASE_URL`: full HTTPS backend base URL

Review the service connection, app names, task runtime settings and deployment permissions before running. The sample YAML is a template; it does not create Azure resources or service connections.

## 5. Verify

1. Open `https://<backend-app>.azurewebsites.net/api/health` and expect `status: ok`.
2. Open `https://<frontend-app>.azurewebsites.net`.
3. In browser developer tools, verify calls to the backend succeed.
4. Check backend CORS configuration exactly matches the frontend origin.
5. Review App Service Log stream and deployment logs if startup fails.

## 6. Security and limitations

This starter POC does not yet implement Entra ID authentication, tenant authorization, persistent audit logs, a live LLM, or real enterprise data connectors. Do not expose it to sensitive data or treat it as production-ready until these controls are implemented and tested. Keep secrets out of frontend settings and source code. Prefer managed identity for Azure services and Key Vault for any required secrets.


## Option: deploy frontend and backend to one Web App

Use `azure-pipelines-single-app.yml`. It builds the Vite frontend, copies `frontend/dist` into `backend/static`, and deploys the packaged FastAPI application. Create one Linux Web App using the **Python 3.12** runtime. Startup command:

```bash
gunicorn --bind=0.0.0.0:8000 --workers=2 --timeout=600 --worker-class=uvicorn.workers.UvicornWorker app.main:app
```

The frontend calls the API using relative `/api/...` URLs. Set Azure OpenAI and Azure AI Search configuration in the Web App's Environment variables. Do not deploy `.env` files. The separate `azure-search-provisioner/` script should be run independently before or during a controlled provisioning pipeline stage.

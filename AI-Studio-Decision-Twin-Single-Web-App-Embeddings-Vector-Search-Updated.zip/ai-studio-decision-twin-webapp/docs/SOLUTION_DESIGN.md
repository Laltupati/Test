# Solution Design Document

## Document purpose
Describe the current standalone AI Studio + Decision Twin proof of concept and the target direction for a controlled, low-code AI workflow platform.

## Problem statement
Business teams need a visual way to express AI-assisted workflows, understand what each step does, compare options and keep human review and governance visible. The POC demonstrates the interface and selected non-AI mechanics before enterprise services are integrated.

## Goals
- Provide a visual workflow canvas.
- Demonstrate template-based workflow drafting.
- Validate basic workflow structure.
- Demonstrate transparent scenario sensitivity calculations.
- Make governance gaps visible.
- Support code-based deployment to Azure App Service without Docker.

## Non-goals of the current POC
- Production AI execution or autonomous agents.
- Live Azure OpenAI or other model calls.
- Real document ingestion, RAG, or enterprise search.
- Entra ID sign-in, tenant authorization or row-level access control.
- Durable database storage, audit trail or run history.
- Forecasting or decision recommendations based on validated business data.

## Logical architecture

```mermaid
flowchart LR
  U[User's browser] --> FE[React + TypeScript frontend]
  FE -->|HTTPS JSON API| API[FastAPI backend]
  API --> SCH[Pydantic request schemas]
  API --> WF[Workflow template and validation service]
  API --> SIM[Deterministic scenario calculation]
  FE -->|Export JSON locally| FILE[User's device]
  API -. future .-> ID[Entra ID / identity]
  API -. future .-> LLM[Approved model endpoint]
  API -. future .-> RAG[Azure AI Search / document sources]
  API -. future .-> OBS[Application Insights / tracing]
  API -. future .-> DB[Run history / audit store]
```

The dashed items are future design options, not connected components in this codebase.

## Deployment architecture

```mermaid
flowchart TB
  Browser[User browser]
  subgraph Azure
    FE[Linux App Service - Node.js frontend]
    BE[Linux App Service - Python FastAPI backend]
    MON[App Service logs / future Application Insights]
  end
  Browser -->|HTTPS| FE
  FE -->|HTTPS API calls; exact CORS origin| BE
  FE -. logs .-> MON
  BE -. logs .-> MON
```

Deploy frontend and backend as separate App Services. This separates browser content hosting from server-side API behavior and allows each to be configured and released independently.

## Main user flows
1. **Design:** edit workflow nodes and edges on the canvas.
2. **Draft:** choose a predefined template; returned nodes and edges replace the canvas.
3. **Validate:** send workflow JSON to the API and show structural errors/warnings.
4. **Simulate:** send assumptions to the backend and display computed values.
5. **Export:** download the workflow JSON locally.
6. **Governance review:** review intended controls and identify integrations still required.

## Data contracts
Workflow definitions contain a name, description, node list and edge list. Nodes have an ID, type, label, description and configuration object. Edges identify source and target node IDs. Simulation requests contain baseline exposure and percentage assumptions. See `API.md` for endpoint contracts.

## Security principles
- Do not place secrets in frontend code or browser environment variables.
- Use HTTPS-only endpoints.
- Configure CORS to the exact frontend origin, but do not treat CORS as access control.
- Before real users/data, implement Entra ID authentication and server-side authorization.
- Use managed identity for Azure services where supported; use Key Vault for secrets that must exist.
- Restrict data connectors and tools to an allow-list.
- Require approval before external writes or consequential actions.
- Record auditable metadata, and protect logs from sensitive-data leakage.

## Risks and mitigations
| Risk | Current status | Recommended mitigation |
|---|---|---|
| Users mistake demo for real AI | Possible | Label prototype limitations in UI and documentation |
| Unauthorized API access | Authentication absent | Add Entra ID and server-side authorization before exposure |
| Invalid workflow configuration | Basic validation only | Validate node types, cycles, required fields and execution policy |
| Misleading scenario output | Formula is illustrative | Display assumptions and limitations; calibrate only with approved data |
| Prompt injection in future RAG | Not yet connected | Treat retrieved content as untrusted; isolate instructions from data |
| Missing audit history | No persistence | Add durable run/audit store with retention policy |
| Cost or runaway model calls | No model calls today | Add quotas, rate limits, budgets and model telemetry before integration |

## Acceptance criteria for this POC
- Frontend loads on App Service.
- Backend health endpoint responds successfully.
- Browser can call the backend with the configured CORS origin.
- Draft, validate and simulate endpoints return expected JSON.
- Workflow export produces valid JSON.
- Documentation clearly distinguishes implemented features from future integrations.

# Architecture — Standalone AI Studio + Decision Twin

## Goal
A separate application for designing low-code AI workflows and testing decision scenarios. It is not embedded into the existing GENAIPlayG application.

## Components
1. React + TypeScript UI
2. React Flow workflow canvas
3. FastAPI service
4. Workflow schema validation and template service
5. Deterministic scenario calculation service
6. Future integrations: model endpoint, Azure AI Search, Entra ID, Key Vault, Application Insights / OpenTelemetry.

## Key boundary
The LLM must not generate and execute arbitrary Python, JavaScript, SQL, or shell commands. It may propose a workflow configuration from an allow-listed node registry. The backend validates the configuration before any execution.

## Current demo limitations
- Workflow draft uses predefined templates rather than an LLM.
- Workflow validation checks structure but does not execute workflows.
- Decision Twin uses a simple illustrative formula, not a calibrated forecast.
- Execution Runs view is a placeholder; run persistence is not implemented.
- Authentication, tenant isolation, durable audit logging and real model/data connectors are not implemented.

# Demo runbook

## Scenario
A business team wants to assess supplier disruption risk, compare mitigation assumptions and prepare a reviewable decision dossier.

## Flow
1. Open Workflow Studio and explain the canvas and node library.
2. Connect or reposition nodes to show that the workflow is configurable.
3. Export the workflow JSON to demonstrate portable configuration.
4. Click Validate workflow. Explain that structural validation is implemented; production publishing gates remain to be added.
5. Open Decision Twin. Change baseline exposure, cost increase, exposure and mitigation effectiveness.
6. Run simulation and explain the formula and limitations.
7. Open Governance and explain the required controls before connecting client systems.

## Do not claim
- The default demo is not using a live LLM.
- The sample data and financial formula are not real client data or forecasts.
- No external action is executed.
- Authentication and production-grade audit persistence are not yet implemented.

# Beginner's Guide: AI Studio + Decision Twin

## 1. What is this application?

AI Studio is a small web application that demonstrates how a user could visually assemble an AI-assisted business process. Decision Twin is a companion screen where a user changes assumptions and compares possible outcomes.

Think of it as a **prototype workbench**, not a finished AI platform. The current version lets you edit a workflow diagram, ask the backend to check the diagram, export workflow JSON, and calculate an illustrative scenario. It does **not** call a real AI model, search corporate documents, or execute the diagram.

## 2. Important AI concepts in plain English

- **AI model / LLM:** software trained to interpret and generate language. This prototype does not call one yet.
- **Prompt:** instructions or a question written in everyday language.
- **Workflow:** a sequence of steps connected together, like a flowchart.
- **Agent:** an AI component that may reason over information and use approved tools. The agent node here is a visual placeholder.
- **RAG (Retrieval-Augmented Generation):** find relevant documents first, then give selected passages to an AI model so its answer can be grounded in evidence. The retrieval node here is only a placeholder.
- **API:** a defined way for one application to ask another application to do something.
- **Backend:** server-side code. It receives requests, validates data and performs calculations.
- **Frontend:** the browser-facing interface the user clicks and sees.
- **Decision Twin / what-if analysis:** compare scenarios by changing assumptions. A useful model must make assumptions and limitations visible.
- **Governance:** controls such as identity, permissions, approvals, logging, testing and cost monitoring.
- **Human-in-the-loop:** a person reviews a result or approves an action before it proceeds.

## 3. How a user action travels through the app

1. You change something on the React screen.
2. The frontend sends JSON to the FastAPI backend (for actions that use the API).
3. FastAPI checks request types using Pydantic schemas.
4. A service function validates the workflow or performs a deterministic calculation.
5. The backend returns a JSON response.
6. The frontend displays the result.

The browser should never contain server secrets. In a future live AI version, model credentials belong on the server or should be replaced by managed identity where supported.

## 4. Current features and what they really do

| Feature | Current behavior | Not implemented yet |
|---|---|---|
| Workflow canvas | Add nodes and connect them visually | Workflow execution engine |
| Generate draft | Selects a predefined template based on the requested template type | No LLM interprets the prompt |
| Validate workflow | Checks basic structure and node connections | Does not prove the business logic is correct |
| Decision Twin | Calculates impact using the visible formula | No predictive model or real business data |
| Execution Runs | Explains that run history is not persisted | Database, traces and run history |
| Governance | Shows intended guardrails and missing controls | Entra ID, role enforcement, durable audit logging |
| Knowledge retrieval / RAG | Visual node only | Azure AI Search, document ingestion, permissions and citations |

## 5. The Decision Twin formula

The screen uses four inputs:
- Baseline exposure: a hypothetical monetary baseline.
- Cost increase (%): an assumed percentage increase.
- Business impact exposure (%): the share of baseline affected.
- Mitigation effectiveness (%): the assumed percentage of modeled impact reduced.

Formula:

`gross impact = baseline × exposure fraction × (1 + cost increase fraction)`

`residual impact = gross impact × (1 − mitigation fraction)`

`illustrative avoided impact = gross impact − residual impact`

Example: baseline $2,000,000, cost increase 15%, exposure 20%, mitigation 50%.

- Gross impact = $2,000,000 × 0.20 × 1.15 = $460,000.
- Residual impact = $460,000 × (1 − 0.50) = $230,000.
- Illustrative avoided impact = $230,000.

These figures are only as good as the assumptions. They are not a forecast, causal estimate or financial recommendation.

## 6. Safe learning path

1. Open Workflow Studio and identify the start, retrieval, agent, simulation, approval and output nodes.
2. Add a node and connect it to another node.
3. Run workflow validation. Deliberately create a broken connection only in a local development copy to see validation feedback.
4. Open Decision Twin and change one slider at a time. Notice which outputs change.
5. Export the workflow JSON and inspect the nodes and edges.
6. Review `CODE_EXPLANATION.md` and `API.md` to connect the interface to the backend.
7. Before any real data or model is connected, complete the security and testing requirements.

## 7. Do not use this POC for

- Real financial, legal, medical, hiring or safety decisions.
- Sensitive or confidential corporate data.
- Autonomous changes to cloud resources or business systems.
- Production use without authentication, authorization, audit, monitoring, privacy review and security testing.

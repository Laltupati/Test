# AI and Software Glossary

| Term | Plain-English explanation | In this POC |
|---|---|---|
| API | A contract that lets software systems exchange requests and responses | Frontend calls FastAPI endpoints |
| Agent | An AI-driven component that can reason and potentially use approved tools | Visual placeholder only |
| Azure App Service | Managed Azure hosting for web applications | Intended hosting for frontend and backend |
| Backend | Server-side application logic | Python / FastAPI |
| CORS | Browser rule controlling which website origins can read an API response | Configured from `CORS_ORIGINS`; not a security boundary by itself |
| Decision Twin | A model of a decision or system used to compare scenarios | Simple sensitivity calculator only |
| Edge | A connection between workflow nodes | Stored as source and target IDs |
| Frontend | The interface rendered in a browser | React + TypeScript |
| LLM | Large language model used to process/generate language | Not connected yet |
| Human-in-the-loop | Human reviews or approves before a consequential step | Approval node is represented visually |
| JSON | A text format for structured data | API payloads and workflow export |
| Node | One step in a workflow | Start, retrieval, agent, simulation, approval, output |
| Pydantic | Python library that validates data against declared schemas | Checks API request shapes and ranges |
| Prompt | Natural-language instruction to an AI system | Used as the workflow description in this demo |
| RAG | Retrieve relevant source content and provide it to a model to ground its response | Retrieval node is not connected yet |
| Schema | Definition of allowed fields and data types | API request models in `schemas.py` |
| Sensitivity analysis | Explore how outputs change when assumptions change | Decision Twin slider calculations |
| Telemetry | Operational signals such as latency, errors and token usage | Future requirement; not persisted today |
| Workflow | Connected sequence of steps that describes a process | Visual graph and JSON definition |

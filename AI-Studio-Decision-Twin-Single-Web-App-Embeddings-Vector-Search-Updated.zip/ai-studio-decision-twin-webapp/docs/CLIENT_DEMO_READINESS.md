# Client demo readiness checklist

## Before the demo
- [ ] Use a dedicated development/demo Azure resource group and approved subscriptions.
- [ ] Obtain approval to use the selected Azure OpenAI model and the intended data classification.
- [ ] Configure the model deployment endpoint, key, and deployment name on the backend only.
- [ ] If demonstrating RAG, create an Azure AI Search index from approved synthetic or public demo documents and map the title/content/source fields.
- [ ] Confirm `/api/health` and `/api/integrations/status` return expected status.
- [ ] Run one workflow query, one document question, one security prompt, and the Decision Twin calculation.
- [ ] Verify document source names shown by the app are real retrieved sources, not invented citations.
- [ ] Prepare a no-network fallback: explain that query features need service configuration if credentials or network are unavailable.
- [ ] Use synthetic/public information only until identity, authorization, and data protection controls are approved.

## Live demo sequence (5–7 minutes)
1. Explain that AI Studio is a low-code orchestration concept and Decision Twin uses explicit assumptions.
2. In Query Studio, generate a workflow suggestion and review the approval checkpoint.
3. In Ask documents, ask a question whose answer is clearly present in one indexed demo document; verify the source reference.
4. In Assess security, request a preliminary checklist and explain that this is not a live security scan.
5. In Decision Twin, change one assumption and show the transparent calculation changing.
6. In Workflow Studio, validate and export the workflow JSON.
7. Close by identifying the production hardening items below.

## Must be completed before a production or confidential client pilot
- Microsoft Entra ID sign-in and server-side authorization on all protected API routes.
- Managed identity and least-privilege RBAC for Azure OpenAI/Search where supported; move secrets to Key Vault if keys remain necessary.
- Search security trimming / tenant filters so users can retrieve only documents they are entitled to see.
- Prompt-injection and data-exfiltration testing; safe output handling and content filters.
- Human approval enforcement on the backend for any consequential action.
- Persistent audit trail, run history, monitoring, rate limits, token/cost limits, retention policy, and incident response.
- Dependency/secret scanning and security review of the complete deployment.

This starter is suitable for a controlled technical demo after integration configuration, not a claim of production readiness.

# Azure AI integrations: chat, embeddings, and Azure AI Search

## What is connected
- Azure OpenAI chat deployment (for example, GPT-5.4 mini) generates responses.
- Azure OpenAI embedding deployment (for example, `text-embedding-3-small`) converts document chunks and questions into vectors.
- Azure AI Search performs keyword + vector hybrid retrieval for Ask documents.
- Decision Twin calculations remain deterministic Python code.

## 1. Configure Azure OpenAI deployments
Deploy the chat model and embedding model in Azure AI Foundry / Azure OpenAI. Copy each exact deployment name. If both deployments belong to the same Azure OpenAI resource, reuse its endpoint and API key.

Set:
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_DEPLOYMENT` — chat deployment, such as the deployment name for GPT-5.4 mini
- `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` — exact embedding deployment name
- `AZURE_OPENAI_EMBEDDINGS_DIMENSIONS=1536` — default for `text-embedding-3-small`
- `AZURE_OPENAI_API_VERSION` — API version supported by your resource

The embedding deployment name is separate from the chat deployment name. If the models are in different Azure OpenAI resources, the current implementation needs separate endpoint/key settings before use.

## 2. Configure Azure AI Search
Set:
- `AZURE_SEARCH_ENDPOINT`
- `AZURE_SEARCH_INDEX`
- `AZURE_SEARCH_API_KEY` — query key or admin key for runtime search
- `AZURE_SEARCH_ADMIN_KEY` — admin key for the separate provisioning script and index status
- `AZURE_SEARCH_TITLE_FIELD=title`
- `AZURE_SEARCH_CONTENT_FIELD=content`
- `AZURE_SEARCH_SOURCE_FIELD=source`
- `AZURE_SEARCH_VECTOR_FIELD=contentVector`
- `AZURE_SEARCH_TOP_K=5`

The index needs a vector field whose dimensions match the embedding output and a vector-search profile. Do not use a query-only key to create/update index schemas.

## 3. Provision the index (run separately)
From `azure-search-provisioner/`:

```bash
python -m pip install -r requirements.txt
python provision_index.py
```

This creates the index and standard fields when missing, and adds the vector field and HNSW profile. It does not automatically backfill vectors for existing documents.

## 4. Ingest document text
Prepare a JSON or JSONL file with records containing `content` and optional `id`, `title`, and `source`. For example:

```json
[
  {
    "id": "policy-001",
    "title": "Example Policy",
    "source": "example-policy.txt",
    "content": "Extracted document text goes here."
  }
]
```

Run:

```bash
python ingest_documents.py documents.json
```

The ingestion script chunks prepared text, calls the embedding deployment, and uploads text chunks plus vectors to Azure AI Search. It does not extract text from PDF/DOCX/PPTX or directly ingest from Blob Storage; those steps must be implemented or performed before passing the JSON input.

## 5. Runtime behavior
For `Ask documents`, the backend embeds the user's question, performs hybrid keyword + vector search against `contentVector`, and sends retrieved excerpts to the chat deployment. Other Query Studio modes use the chat deployment without document retrieval.

If you already had an index before the vector field was added, run the provisioner and then re-ingest/re-embed existing documents. Adding a field alone does not populate vectors. Avoid changing the embedding model or dimensions without planning a re-embedding migration.

## Security
- Store secrets in App Service environment variables or Key Vault; never in frontend `VITE_*` variables or source control.
- The standalone provisioner requires index-management privileges. The runtime app should ideally use a query key or a least-privilege identity.
- Validate document permissions and add authentication/authorization before exposing the demo to real or sensitive content.

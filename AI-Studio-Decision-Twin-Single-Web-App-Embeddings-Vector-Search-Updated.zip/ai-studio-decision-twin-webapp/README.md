# GENAIPlayG AI Studio + Decision Twin — Standalone Web App

A **separate application codebase** intended for Azure App Service deployment **without Docker**.

## Components
- `frontend/`: React + TypeScript + Vite workflow studio and Decision Twin UI; built by the pipeline and served from the same FastAPI app.
- `backend/`: FastAPI APIs, GPT chat integration, embedding generation for questions, and Azure AI Search hybrid retrieval.
- `docs/`: architecture, API, security, demo runbook, and Azure App Service deployment guide.
- `azure-pipelines-frontend.yml`: sample Azure DevOps frontend build/deployment pipeline.
- `azure-pipelines-backend.yml`: sample Azure DevOps backend deployment pipeline.

## Local run without Docker

Backend:
```bash
cd backend
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Frontend in a second terminal:
```bash
cd frontend
npm install
# macOS/Linux
VITE_API_BASE_URL=http://localhost:8000 npm run dev
# Windows PowerShell
$env:VITE_API_BASE_URL = 'http://localhost:8000'
npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:8000
- API docs: http://localhost:8000/docs

## Deploy to Azure
Follow [`docs/AZURE_APP_SERVICE_DEPLOYMENT.md`](docs/AZURE_APP_SERVICE_DEPLOYMENT.md). Create two Linux App Services: Node.js for the frontend and Python 3.12 for the backend. Set frontend startup to `npm start`; backend startup to the documented Gunicorn/Uvicorn command. Use the included Azure DevOps pipeline YAML as a template.

## Environment configuration
Copy `backend/.env.example` to `backend/.env` for local development if needed. The default demo does not require cloud credentials. Never commit `.env` or hard-code keys/endpoints.

## POC limitations
- Draft generation uses predefined templates, not a live LLM call.
- Workflow validation checks structure but does not execute the workflow.
- Decision Twin calculations are illustrative, deterministic sensitivity calculations—not a forecast or causal estimate.
- Document text must be extracted before using `azure-search-provisioner/ingest_documents.py`; direct Blob Storage/PDF/DOCX ingestion is not included. Add authentication, authorization, and production-grade audit controls before production use.


## UI update: Query Studio and clickable controls

The latest UI update adds a Query Studio page with four selectable query types:
- Build a workflow
- Ask documents
- Compare scenarios
- Assess security

The query page provides an illustrative preview only. It does not call a live LLM or retrieve documents.

Previously decorative controls have been wired:
- Workspace selector opens a menu and changes the displayed demo workspace.
- Help icon opens a help dialog.
- Workflow settings icon opens a settings/validation information dialog.

To run locally:
1. Start the FastAPI backend from `backend` using the steps in `docs/AZURE_APP_SERVICE_DEPLOYMENT.md` or `README.md`.
2. In a second terminal, run `cd frontend`, `npm install`, then `npm run dev`.
3. Open the local URL printed by Vite, normally `http://localhost:5173`.

After extracting this updated package, run `npm install` in `frontend` before `npm run build` or `npm run dev`.


## Optional live Azure AI integration
See [`docs/AZURE_AI_INTEGRATIONS.md`](docs/AZURE_AI_INTEGRATIONS.md). Copy `backend/.env.example` to `backend/.env`, configure Azure OpenAI and (for document questions) Azure AI Search, install the updated requirements, and restart the backend. Secrets belong only in backend configuration, never in the React frontend.


### Automatic Azure AI Search index setup

The backend supports idempotent index provisioning. Configure `AZURE_SEARCH_ENDPOINT`, `AZURE_SEARCH_INDEX`, and the backend-only `AZURE_SEARCH_ADMIN_KEY`, then set `Run `azure-search-provisioner/provision_index.py` separately to create/update the index.`. On startup it creates the index if absent and adds missing fields (`id`, `title`, `content`, `source`, `metadata_storage_name`) without deleting existing fields/documents. See `docs/AZURE_AI_INTEGRATIONS.md` for details. This creates the schema only; a separate ingestion/indexer is required to load documents.


## Single Azure App Service deployment

This project can run the React/Vite frontend and FastAPI backend in one Linux App Service. The single-app pipeline is `azure-pipelines-single-app.yml`. It builds `frontend/`, copies the generated `dist/` files into `backend/static/`, then deploys the backend package. FastAPI serves both `/api/*` endpoints and the frontend on the same origin, so the frontend uses relative API paths.

Select **Publish: Code**, **Operating System: Linux**, **Runtime: Python 3.12** for the single App Service. Configure Azure OpenAI and Azure AI Search settings as App Service environment variables. Keep the standalone `azure-search-provisioner/` folder separate; run it as a one-off provisioning task, not as part of application startup.

Pipeline variables required: `APP_SERVICE_NAME` and `AZURE_SERVICE_CONNECTION`. Ensure the selected App Service plan has enough memory/CPU for both API requests and static serving. The frontend and backend now share the same origin; CORS is not needed for same-origin browser calls, though existing CORS middleware remains configurable.

// Minimal production static server for Azure App Service (Node.js), no Docker required.
// Serves Vite's built assets from ./dist and supports client-side SPA routing.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, 'dist');
const port = Number(process.env.PORT || 8080);
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf'
};
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname);
  let target = path.resolve(root, `.${pathname}`);
  if (!target.startsWith(root + path.sep) && target !== root) {
    res.writeHead(403); return res.end('Forbidden');
  }
  if (pathname === '/') target = path.join(root, 'index.html');
  fs.stat(target, (err, stat) => {
    if (!err && stat.isFile()) return send(target, res);
    // Vite assets that are missing should return 404, not index.html.
    if (path.extname(pathname)) { res.writeHead(404); return res.end('Not found'); }
    send(path.join(root, 'index.html'), res);
  });
});
function send(file, res) {
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(500); return res.end('Unable to read application asset'); }
    res.writeHead(200, { 'Content-Type': types[path.extname(file).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  });
}
server.listen(port, '0.0.0.0', () => console.log(`AI Studio frontend listening on ${port}`));

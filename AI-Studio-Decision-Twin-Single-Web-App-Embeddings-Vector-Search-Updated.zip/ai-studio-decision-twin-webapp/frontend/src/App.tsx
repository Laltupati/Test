import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  ReactFlow, Background, Controls, MiniMap, addEdge, useEdgesState, useNodesState,
  type Connection, type Node, type Edge, MarkerType
} from '@xyflow/react'
import {
  Activity, Bot, Boxes, CheckCircle2, ChevronDown, CircleHelp, Clock3, FileSearch,
  GitBranch, LayoutDashboard, Plus, Play, Save, ShieldCheck, SlidersHorizontal,
  Sparkles, Workflow, Zap, ArrowRight, AlertTriangle, Gauge, Database, Settings2
} from 'lucide-react'

const API = import.meta.env.VITE_API_BASE_URL ?? ''

const initialNodes: Node[] = [
  { id: 'start', type: 'input', position: { x: 40, y: 180 }, data: { label: 'Business question', subtitle: 'Define objective' }, style: { background: '#14243c', color: '#edf4ff', border: '1px solid #31527a', borderRadius: 12, width: 175, padding: 14 } },
  { id: 'knowledge', position: { x: 280, y: 90 }, data: { label: 'Retrieve evidence', subtitle: 'Hybrid RAG' }, style: { background: '#102e3b', color: '#e6fbff', border: '1px solid #28788a', borderRadius: 12, width: 175, padding: 14 } },
  { id: 'agent', position: { x: 520, y: 180 }, data: { label: 'Risk analyst', subtitle: 'Agent reasoning' }, style: { background: '#252044', color: '#f3efff', border: '1px solid #6954a7', borderRadius: 12, width: 175, padding: 14 } },
  { id: 'simulation', position: { x: 760, y: 90 }, data: { label: 'Scenario simulation', subtitle: 'Validated calculations' }, style: { background: '#3a2b17', color: '#fff5e5', border: '1px solid #99713d', borderRadius: 12, width: 190, padding: 14 } },
  { id: 'approval', position: { x: 760, y: 300 }, data: { label: 'Human approval', subtitle: 'Required checkpoint' }, style: { background: '#18342b', color: '#eafff3', border: '1px solid #41866a', borderRadius: 12, width: 175, padding: 14 } },
  { id: 'output', type: 'output', position: { x: 1030, y: 180 }, data: { label: 'Decision dossier', subtitle: 'Evidence + options' }, style: { background: '#14243c', color: '#edf4ff', border: '1px solid #31527a', borderRadius: 12, width: 175, padding: 14 } },
]
const initialEdges: Edge[] = [
  { id: 'e1', source: 'start', target: 'knowledge', animated: true, markerEnd: { type: MarkerType.ArrowClosed } },
  { id: 'e2', source: 'knowledge', target: 'agent', animated: true, markerEnd: { type: MarkerType.ArrowClosed } },
  { id: 'e3', source: 'agent', target: 'simulation', animated: true, markerEnd: { type: MarkerType.ArrowClosed } },
  { id: 'e4', source: 'simulation', target: 'approval', animated: true, markerEnd: { type: MarkerType.ArrowClosed } },
  { id: 'e5', source: 'approval', target: 'output', animated: true, markerEnd: { type: MarkerType.ArrowClosed } },
]
const nodeStyle: Record<string, React.CSSProperties> = {
  knowledge: { background: '#102e3b', color: '#e6fbff', border: '1px solid #28788a', borderRadius: 12, width: 175, padding: 14 },
  agent: { background: '#252044', color: '#f3efff', border: '1px solid #6954a7', borderRadius: 12, width: 175, padding: 14 },
  simulation: { background: '#3a2b17', color: '#fff5e5', border: '1px solid #99713d', borderRadius: 12, width: 190, padding: 14 },
  approval: { background: '#18342b', color: '#eafff3', border: '1px solid #41866a', borderRadius: 12, width: 175, padding: 14 },
  output: { background: '#14243c', color: '#edf4ff', border: '1px solid #31527a', borderRadius: 12, width: 175, padding: 14 },
}
type Tab = 'query' | 'studio' | 'decision' | 'runs' | 'governance'

function App() {
  const [tab, setTab] = useState<Tab>('studio')
  const [workspaceOpen, setWorkspaceOpen] = useState(false)
  const [workspaceName, setWorkspaceName] = useState('KPMG Demo Workspace')
  const [overlay, setOverlay] = useState<'help'|'settings'|null>(null)
  const [queryMode, setQueryMode] = useState<'workflow'|'documents'|'scenario'|'security'>('workflow')
  const [queryText, setQueryText] = useState('Create a vendor risk assessment workflow. Review vendor documents, identify security and compliance risks, require human approval for high-risk vendors, and generate a final report.')
  const [queryPreview, setQueryPreview] = useState(false)
  const [queryRunning, setQueryRunning] = useState(false)
  const [queryResult, setQueryResult] = useState<any>(null)
  const [queryError, setQueryError] = useState('')
  const [integrationStatus, setIntegrationStatus] = useState<any>(null)
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const [toast, setToast] = useState('')
  const [prompt, setPrompt] = useState('Assess supplier disruption risk, compare mitigation options, and prepare an approval-ready decision dossier.')
  const [costIncrease, setCostIncrease] = useState(15)
  const [exposure, setExposure] = useState(20)
  const [mitigation, setMitigation] = useState(50)
  const [baseline, setBaseline] = useState(2000000)
  const [simulation, setSimulation] = useState<any>(null)
  const [runState, setRunState] = useState<'idle'|'running'|'complete'>('idle')
  const [selectedNode, setSelectedNode] = useState<string>('agent')
  const [apiStatus, setApiStatus] = useState('Checking API')

  const onConnect = useCallback((connection: Connection) => setEdges((eds) => addEdge({ ...connection, animated: true, markerEnd: { type: MarkerType.ArrowClosed } }, eds)), [setEdges])
  const addNode = (kind: string) => {
    const id = `${kind}-${Date.now().toString().slice(-5)}`
    const labels: Record<string, [string,string]> = {
      knowledge: ['Knowledge retrieval','Search approved sources'],
      agent: ['AI agent','Reason over evidence'],
      simulation: ['Scenario simulation','Run validated calculations'],
      approval: ['Human approval','Review before action'],
      output: ['Output','Produce a structured result'],
    }
    const [label, subtitle] = labels[kind] || ['Workflow node','Configure node']
    const node: Node = { id, position: { x: 220 + Math.random()*300, y: 100 + Math.random()*260 }, data: { label, subtitle }, style: nodeStyle[kind] || nodeStyle.agent }
    setNodes((nds) => [...nds, node])
    setSelectedNode(id)
    setToast(`${label} added to canvas`)
  }
  const onNodeClick = (_: unknown, node: Node) => setSelectedNode(node.id)
  const selected = nodes.find(n => n.id === selectedNode)
  const gross = baseline * (exposure/100) * (1 + costIncrease/100)
  const residual = gross * (1 - mitigation/100)
  const money = (n: number) => n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
  const workflowPayload = useMemo(() => ({
    name: 'Supplier Risk Decision Workflow',
    description: prompt,
    nodes: nodes.map(n => ({ id: n.id, type: (['input'].includes(n.type || '') ? 'start' : (['knowledge','agent','simulation','approval','output'].find(k => n.id.startsWith(k)) || (n.id==='start'?'start':'agent'))), label: String(n.data.label), description: String(n.data.subtitle || ''), config: {} })),
    edges: edges.map(e => ({ id: e.id, source: e.source, target: e.target }))
  }), [nodes, edges, prompt])

  async function checkApi() {
    try {
      const r = await fetch(`${API}/api/health`)
      if (!r.ok) throw new Error('API unavailable')
      setApiStatus('API connected')
    } catch { setApiStatus('Demo mode · API offline') }
  }
  useEffect(() => { void checkApi(); void checkIntegrations() }, [])
  async function checkIntegrations() {
    try { const r = await fetch(`${API}/api/integrations/status`); if (!r.ok) throw new Error('status unavailable'); setIntegrationStatus(await r.json()) } catch { setIntegrationStatus(null) }
  }
  async function executeQuery() {
    setQueryRunning(true); setQueryError(''); setQueryResult(null); setQueryPreview(true)
    try {
      const r = await fetch(`${API}/api/query`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({mode:queryMode, query:queryText}) })
      const data = await r.json()
      if (!r.ok) throw new Error(data.detail || 'Query failed. Check the backend configuration.')
      setQueryResult(data); setToast(data.live_model ? 'Live model response received' : 'Demo response received')
    } catch (e) { setQueryError(e instanceof Error ? e.message : 'Unable to run query. Is the backend running?') }
    finally { setQueryRunning(false) }
  }
  async function validateWorkflow() {
    try {
      const r = await fetch(`${API}/api/workflows/validate`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({workflow: workflowPayload}) })
      if (!r.ok) throw new Error('validation API unavailable')
      const result = await r.json()
      setToast(result.valid ? `Workflow validated · ${result.node_count} nodes / ${result.edge_count} connections${result.warnings?.length ? ` · ${result.warnings.length} warning(s)` : ''}` : `Validation failed: ${result.errors.join(' ')}`)
    } catch {
      const ids = new Set(nodes.map(n => n.id))
      const broken = edges.some(e => !ids.has(e.source) || !ids.has(e.target))
      setToast(broken ? 'Validation failed: one or more connections reference missing nodes.' : 'Local structural check passed. Start the API for server-side validation.')
    }
  }
  async function runSimulation() {
    setRunState('running')
    try {
      const r = await fetch(`${API}/api/decision-twin/simulate`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({baseline_exposure: baseline, cost_increase_pct: costIncrease, exposure_pct: exposure, mitigation_effectiveness_pct: mitigation, scenarios: ['Before mitigation','After assumed mitigation']}) })
      if (r.ok) setSimulation(await r.json())
      else throw new Error('API error')
    } catch {
      setSimulation({results:{gross_impact:gross,residual_impact:residual,illustrative_avoided_impact:gross-residual},limitations:['Local illustrative formula only; not a forecast or causal estimate.']})
    }
    setRunState('complete')
    setToast('Scenario simulation complete · illustrative inputs only')
  }
  function saveDraft() {
    const blob = new Blob([JSON.stringify({name:'Supplier Risk Decision Workflow',description:prompt,nodes,edges}, null, 2)], {type:'application/json'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'decision-twin-workflow.json'; a.click(); URL.revokeObjectURL(url)
    setToast('Workflow JSON exported')
  }
  async function createDraft() {
    try {
      const r = await fetch(`${API}/api/workflows/draft`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,template:tab==='decision'?'decision':'risk'})})
      if (!r.ok) throw new Error('draft endpoint unavailable')
      const data = await r.json()
      const newNodes: Node[] = data.nodes.map((n: any, i: number) => ({
        id:n.id, type:n.type==='start'?'input':n.type==='output'?'output':'default',
        position:{x:40+(i%3)*260,y:70+Math.floor(i/3)*170},
        data:{label:n.label,subtitle:n.description},
        style:nodeStyle[n.type] || (n.type==='start'?nodeStyle.output:nodeStyle.agent)
      }))
      const newEdges: Edge[] = data.edges.map((e:any) => ({...e,animated:true,markerEnd:{type:MarkerType.ArrowClosed}}))
      setNodes(newNodes); setEdges(newEdges); setToast('Draft workflow generated from a predefined demo template')
    } catch { setToast('Start the backend API to generate a template draft.') }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Boxes size={20}/></div><div><b>AI Studio</b><small>DECISION TWIN</small></div></div>
      <div className="workspace-wrap">
        <button className="workspace workspace-trigger" aria-expanded={workspaceOpen} onClick={() => setWorkspaceOpen(v=>!v)}>
          <div className="avatar">KT</div><div><b>{workspaceName}</b><small>Development environment</small></div><ChevronDown size={15}/>
        </button>
        {workspaceOpen && <div className="workspace-menu" role="menu">
          {['KPMG Demo Workspace','Personal Sandbox','Client Demo Workspace'].map(name=><button key={name} role="menuitem" className={workspaceName===name?'selected':''} onClick={()=>{setWorkspaceName(name);setWorkspaceOpen(false);setToast(`${name} selected · demo workspace only`)}}>{name}<small>{name==='KPMG Demo Workspace'?'Development environment':'Sample workspace'}</small></button>)}
        </div>}
      </div>
      <div className="nav-label">WORKSPACE</div>
      <button className={`nav-item ${tab==='query'?'active':''}`} onClick={()=>setTab('query')}><Sparkles size={17}/> Query Studio <span className="nav-pill">NEW</span></button>
      <button className={`nav-item ${tab==='studio'?'active':''}`} onClick={()=>setTab('studio')}><Workflow size={17}/> Workflow Studio <span className="nav-pill">NEW</span></button>
      <button className={`nav-item ${tab==='decision'?'active':''}`} onClick={()=>setTab('decision')}><GitBranch size={17}/> Decision Twin</button>
      <button className={`nav-item ${tab==='runs'?'active':''}`} onClick={()=>setTab('runs')}><Activity size={17}/> Execution Runs</button>
      <button className={`nav-item ${tab==='governance'?'active':''}`} onClick={()=>setTab('governance')}><ShieldCheck size={17}/> Governance</button>
      <div className="sidebar-bottom"><div className="status-line"><span className="status-dot"/> Demo environment</div><small>Standalone POC · v0.1.0</small><small>{apiStatus}</small></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="crumb">Workspace <span>/</span> <b>{tab==='query'?'Query Studio':tab==='studio'?'Workflow Studio':tab==='decision'?'Decision Twin':tab==='runs'?'Execution Runs':'Governance'}</b></div><div className="top-actions"><span className="env-tag"><span className="status-dot"/> DEV</span><button className="icon-btn" title="Help" aria-label="Help" onClick={()=>setOverlay("help")}><CircleHelp size={18}/></button><div className="avatar">KT</div></div></header>
      {tab==='query' && <section className="page">
        <div className="page-head"><div><div className="eyebrow"><Sparkles size={14}/> NATURAL LANGUAGE INTERFACE</div><h1>Query Studio</h1><p>Describe what you want to achieve and preview the intended workflow or analysis.</p></div><span className="tag"><span className="status-dot"/> {integrationStatus?.azure_openai_configured ? 'LLM configured' : 'LLM not configured'}</span></div>
        <div className="query-layout">
          <section className="panel query-panel">
            <div className="panel-head"><div><b>Choose a task</b><small>Select what you want the application to help with</small></div></div>
            <div className="query-options">
              {([{id:'workflow',title:'Build a workflow',desc:'Design a sequence of steps',icon:<Workflow/>},{id:'documents',title:'Ask documents',desc:'Question answering with RAG',icon:<FileSearch/>},{id:'scenario',title:'Compare scenarios',desc:'Explore what-if outcomes',icon:<GitBranch/>},{id:'security',title:'Assess security',desc:'Review risks and controls',icon:<ShieldCheck/>}] as const).map(item=><button key={item.id} className={`query-option ${queryMode===item.id?'selected':''}`} onClick={()=>{setQueryMode(item.id);setQueryPreview(false);setQueryText(({workflow:'Create a vendor risk assessment workflow. Review vendor documents, identify security and compliance risks, require human approval for high-risk vendors, and generate a final report.',documents:'Based on the approved security policies, identify mandatory controls before deploying a GenAI application to production. Include document references and missing controls.',scenario:'Compare the current scenario with a 15% operating cost increase. Assume 20% business impact exposure and 50% mitigation effectiveness. Show the calculations and residual impact.',security:'Assess an Azure-hosted GenAI application for authentication, secrets management, network access, logging, and API authorization. Classify risks and recommend remediation.'})[item.id])}}>{item.icon}<span><b>{item.title}</b><small>{item.desc}</small></span><span className="radio-dot">{queryMode===item.id?'✓':''}</span></button>)}
            </div>
            <div className="query-editor"><label htmlFor="query-text">Your query</label><textarea id="query-text" rows={6} value={queryText} onChange={e=>{setQueryText(e.target.value);setQueryPreview(false)}} placeholder="Describe your objective, context, constraints, and expected output."/><small>Tip: be specific about the outcome you expect.</small><button className="btn primary" disabled={!queryText.trim() || queryRunning} onClick={()=>void executeQuery()}><Play size={15}/>{queryRunning?'Running query…':'Run query'}</button><button className="btn secondary" onClick={()=>{setOverlay('settings')}}><Settings2 size={15}/> Integration setup</button></div>
          </section>
          <section className="panel query-result"><div className="panel-head"><div><b>Query response</b><small>{integrationStatus?.azure_openai_configured ? 'Azure OpenAI configured · backend execution' : 'Configure Azure OpenAI in backend environment variables'}</small></div></div>
            {!queryPreview ? <div className="query-empty"><Sparkles size={28}/><b>Your response will appear here</b><p>Choose a task, edit the query, then select Run query.</p><p>LLM configured: {integrationStatus?.azure_openai_configured ? 'Yes' : 'No'} · Search configured: {integrationStatus?.azure_search_configured ? 'Yes' : 'No'}</p></div> : <div className="query-preview">
              {queryRunning && <div className="preview-status"><Activity size={17}/> Sending query to backend…</div>}
              {queryError && <div className="preview-note"><AlertTriangle size={15}/><span><b>Query could not run.</b><br/>{queryError}<br/><br/>Check backend logs and the environment variables. For “Ask documents”, both Azure OpenAI and Azure AI Search must be configured.</span></div>}
              {queryResult && <><div className="preview-status"><CheckCircle2 size={17}/> {queryResult.live_model ? `Live model response · ${queryResult.model_deployment}` : 'Demo response'}</div><h3>Response</h3><div className="ai-answer">{queryResult.answer}</div>{queryResult.sources?.length>0 && <><h3>Retrieved sources</h3>{queryResult.sources.map((source:any,i:number)=><div className="preview-step" key={`${source.source}-${i}`}><span>{i+1}</span><div><b>{source.title}</b><small>{source.source}</small></div></div>)}</>}{queryResult.usage && <p className="usage-note">Tokens: {queryResult.usage.total_tokens ?? 'n/a'} total (prompt {queryResult.usage.prompt_tokens ?? 'n/a'}, completion {queryResult.usage.completion_tokens ?? 'n/a'})</p>}<div className="preview-note"><AlertTriangle size={15}/>{queryResult.disclaimer}</div></>}
              {!queryResult && !queryError && !queryRunning && <><div className="preview-status"><CheckCircle2 size={17}/> Query prepared</div><p>Click Run query to submit this request to the backend.</p></>}
              <button className="btn secondary" onClick={()=>{void GenCopy(queryText);setToast('Query copied to clipboard if browser permissions allow')}}>Copy query</button>
            </div>}
          </section>
        </div>
      </section>}
      {tab==='studio' && <section className="page">
        <div className="page-head"><div><div className="eyebrow"><Sparkles size={14}/> LOW-CODE AI ORCHESTRATION</div><h1>Workflow Studio</h1><p>Design, validate and govern AI workflows visually — without starting from code.</p></div><div className="head-actions"><button className="btn secondary" onClick={saveDraft}><Save size={16}/> Export JSON</button><button className="btn primary" onClick={validateWorkflow}><CheckCircle2 size={16}/> Validate workflow</button></div></div>
        <div className="metrics"><Metric icon={<Workflow/>} label="Workflow nodes" value={String(nodes.length).padStart(2,'0')} detail="Current canvas"/><Metric icon={<GitBranch/>} label="Connections" value={String(edges.length).padStart(2,'0')} detail="Directed edges"/><Metric icon={<ShieldCheck/>} label="Approval gates" value={String(nodes.filter(n=>n.id.startsWith('approval')).length + nodes.filter(n=>n.id==='approval').length)} detail="Human review checkpoints"/><Metric icon={<Gauge/>} label="Runtime" value="Demo" detail="No live model connected"/></div>
        <div className="studio-grid">
          <section className="panel canvas-panel">
            <div className="panel-head"><div><b>Workflow canvas</b><small>Connect nodes by dragging from one handle to another</small></div><div className="panel-tools"><span className="tag"><span className="status-dot"/> Draft</span><button className="icon-btn" title="Workflow settings" aria-label="Workflow settings" onClick={()=>setOverlay("settings")}><Settings2 size={17}/></button></div></div>
            <div className="canvas"><ReactFlow nodes={nodes} edges={edges} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect} onNodeClick={onNodeClick} fitView minZoom={0.25} maxZoom={1.5} attributionPosition="bottom-left"><Background color="#23324a" gap={20}/><Controls/><MiniMap nodeColor={(n)=>n.id.includes('approval')?'#41866a':n.id.includes('simulation')?'#99713d':n.id.includes('knowledge')?'#28788a':'#6954a7'} maskColor="rgba(5,10,20,.65)"/></ReactFlow></div>
            <div className="canvas-footer"><span><span className="legend-dot blue"/> Start / Output</span><span><span className="legend-dot teal"/> Knowledge</span><span><span className="legend-dot purple"/> Agent</span><span><span className="legend-dot amber"/> Simulation</span><span><span className="legend-dot green"/> Approval</span></div>
          </section>
          <aside className="right-column">
            <section className="panel"><div className="panel-head"><div><b><Plus size={15}/> Node library</b><small>Add a component to the workflow</small></div></div><div className="node-library">
              <NodeButton icon={<Database/>} title="Knowledge retrieval" desc="RAG, search, citations" onClick={()=>addNode('knowledge')}/>
              <NodeButton icon={<Bot/>} title="AI agent" desc="Reasoning and tool use" onClick={()=>addNode('agent')}/>
              <NodeButton icon={<SlidersHorizontal/>} title="Scenario simulation" desc="Deterministic calculations" onClick={()=>addNode('simulation')}/>
              <NodeButton icon={<ShieldCheck/>} title="Human approval" desc="Controlled decision gate" onClick={()=>addNode('approval')}/>
              <NodeButton icon={<FileSearch/>} title="Output" desc="Structured report or result" onClick={()=>addNode('output')}/>
            </div></section>
            <section className="panel"><div className="panel-head"><div><b>Node properties</b><small>Selected component</small></div></div><div className="properties">
              <label>Node ID</label><div className="property-value mono">{selected?.id || 'Select a node'}</div>
              <label>Component name</label><div className="property-value">{String(selected?.data.label || '—')}</div>
              <label>Purpose</label><div className="property-value muted">{String(selected?.data.subtitle || 'Select a node on the canvas to inspect it.')}</div>
              <div className="info-callout"><ShieldCheck size={15}/><span>External actions should require an explicit approval node and server-side authorization.</span></div>
            </div></section>
          </aside>
        </div>
        <section className="panel prompt-panel"><div className="prompt-icon"><Sparkles/></div><div className="prompt-content"><b>Prompt-to-Workflow</b><p>Describe the business process and generate a starting workflow from an approved template.</p><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={2}/></div><button className="btn primary" onClick={createDraft}><Zap size={16}/> Generate draft</button></section>
      </section>}
      {tab==='decision' && <section className="page">
        <div className="page-head"><div><div className="eyebrow"><GitBranch size={14}/> WHAT-IF ANALYSIS</div><h1>Decision Twin</h1><p>Compare scenarios using transparent assumptions and deterministic calculations.</p></div><button className="btn primary" onClick={runSimulation} disabled={runState==='running'}><Play size={16}/>{runState==='running'?'Running…':'Run simulation'}</button></div>
        <div className="metrics"><Metric icon={<SlidersHorizontal/>} label="Scenario variables" value="04" detail="Editable assumptions"/><Metric icon={<Activity/>} label="Simulation engine" value="Deterministic" detail="Transparent formula"/><Metric icon={<ShieldCheck/>} label="Approval required" value="Yes" detail="Before consequential action"/><Metric icon={<Clock3/>} label="Last run" value={runState==='complete'?'Just now':'Not run'} detail="Local demo"/></div>
        <div className="decision-grid"><section className="panel"><div className="panel-head"><div><b>Scenario assumptions</b><small>Change inputs to compare possible impacts</small></div><span className="tag">Synthetic data</span></div><div className="sliders">
          <Range label="Baseline exposure" value={baseline} min={100000} max={10000000} step={100000} display={money(baseline)} onChange={setBaseline}/>
          <Range label="Operating cost increase" value={costIncrease} min={0} max={40} step={5} display={`${costIncrease}%`} onChange={setCostIncrease}/>
          <Range label="Business impact exposure" value={exposure} min={5} max={50} step={5} display={`${exposure}%`} onChange={setExposure}/>
          <Range label="Assumed mitigation effectiveness" value={mitigation} min={0} max={80} step={10} display={`${mitigation}%`} onChange={setMitigation}/>
        </div><div className="formula"><b>Calculation model</b><code>Gross impact = baseline × exposure × (1 + cost increase)</code><code>Residual impact = gross impact × (1 − mitigation)</code><small>Illustrative sensitivity model only — not a forecast or causal estimate.</small></div></section>
        <section className="panel"><div className="panel-head"><div><b>Scenario comparison</b><small>Calculated from current assumptions</small></div><span className="tag"><span className="status-dot"/> Live inputs</span></div><div className="results"><div className="result-card"><span>Impact before mitigation</span><strong>{money(gross)}</strong><div className="bar"><i style={{width:'100%'}}/></div><small>100% of modeled impact</small></div><div className="result-card"><span>Residual impact</span><strong>{money(residual)}</strong><div className="bar residual"><i style={{width:`${100-mitigation}%`}}/></div><small>{100-mitigation}% of modeled impact remains</small></div><div className="result-card positive"><span>Illustrative avoided impact</span><strong>{money(gross-residual)}</strong><small>Based entirely on assumed mitigation effectiveness</small></div></div>{simulation && <div className="simulation-output"><b><CheckCircle2 size={16}/> Last simulation result</b><p>Gross: {money(simulation.results.gross_impact)} · Residual: {money(simulation.results.residual_impact)} · Avoided: {money(simulation.results.illustrative_avoided_impact)}</p><small>{simulation.limitations?.[0]}</small></div>}</section></div>
      </section>}
      {tab==='runs' && <section className="page"><div className="page-head"><div><div className="eyebrow"><Activity size={14}/> OBSERVABILITY</div><h1>Execution Runs</h1><p>Inspect workflow execution status, duration, evaluation and trace events.</p></div></div><div className="panel empty-state"><div className="empty-icon"><Activity size={28}/></div><h2>No persisted runs yet</h2><p>The standalone POC currently provides local simulation and workflow validation. Add a durable run store and tracing integration before using this view for operational monitoring.</p><button className="btn secondary" onClick={()=>setTab('studio')}>Return to Workflow Studio <ArrowRight size={15}/></button></div></section>}
      {tab==='governance' && <section className="page"><div className="page-head"><div><div className="eyebrow"><ShieldCheck size={14}/> TRUST AND CONTROL</div><h1>Governance</h1><p>Prototype guardrails for publishing workflows responsibly.</p></div></div><div className="governance-grid"><GovernanceCard icon={<ShieldCheck/>} title="Human approval" status="Required for consequential actions" body="Place an approval node before external writes, financial actions, or operational remediation."/><GovernanceCard icon={<CheckCircle2/>} title="Workflow validation" status="Available" body="Validate unique node IDs, required start node, edge references, and approval checkpoints."/><GovernanceCard icon={<AlertTriangle/>} title="Identity and access" status="Integration required" body="Entra ID sign-in and server-side role enforcement must be implemented before production use."/><GovernanceCard icon={<Activity/>} title="Audit and tracing" status="Integration required" body="Persist who ran a workflow, input references, tool calls, approvals, results, and model versions."/><GovernanceCard icon={<Gauge/>} title="Cost and quality" status="Integration required" body="Capture model token usage, latency, evaluation scores, and estimated cost per completed task."/><GovernanceCard icon={<Database/>} title="Data access" status="Demo data only" body="Connect only approved data sources and enforce permissions at retrieval and tool-execution layers." /></div></section>}
      {overlay && <div className="modal-backdrop" onClick={()=>setOverlay(null)}><section className="modal panel" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={e=>e.stopPropagation()}><div className="panel-head"><div><b id="modal-title">{overlay==='help'?'AI Studio help':'Workflow settings'}</b><small>{overlay==='help'?'Quick guide to the prototype':'Demo configuration options'}</small></div><button className="icon-btn" onClick={()=>setOverlay(null)} aria-label="Close dialog">×</button></div>{overlay==='help'?<div className="modal-body"><p><b>Workflow Studio</b> lets you add, connect, inspect, validate and export workflow nodes.</p><p><b>Decision Twin</b> runs transparent calculations from the sliders; results are illustrative.</p><p><b>Query Studio</b> submits a query to the backend. Azure OpenAI handles generation; Azure AI Search is used for Ask documents when configured.</p><p><b>Security note:</b> this is a client-demo starter, not production-secured. Add Entra ID, role authorization, audit storage, and governance before exposing it to clients or confidential data.</p></div>:<div className="modal-body"><h3>Integration status</h3><p>Azure OpenAI: <b>{integrationStatus?.azure_openai_configured ? 'Configured' : 'Not configured'}</b></p><p>Azure AI Search: <b>{integrationStatus?.azure_search_configured ? 'Configured' : 'Not configured'}</b></p><label>Where to configure</label><p>Local: set variables in <code>backend/.env</code> and load them before starting FastAPI. Never commit this file.</p><p>Azure: App Service → backend web app → Environment variables. Save and restart the app after changing settings.</p><label>Azure OpenAI variables</label><pre>AZURE_OPENAI_ENDPOINT{`\n`}AZURE_OPENAI_API_KEY{`\n`}AZURE_OPENAI_DEPLOYMENT{`\n`}AZURE_OPENAI_API_VERSION</pre><label>Azure AI Search variables</label><pre>AZURE_SEARCH_ENDPOINT{`\n`}AZURE_SEARCH_API_KEY{`\n`}AZURE_SEARCH_INDEX{`\n`}AZURE_SEARCH_TITLE_FIELD{`\n`}AZURE_SEARCH_CONTENT_FIELD{`\n`}AZURE_SEARCH_SOURCE_FIELD</pre><p>Check <code>/api/integrations/status</code> to confirm configuration. It returns no secrets.</p></div>}<div className="modal-actions"><button className="btn primary" onClick={()=>setOverlay(null)}>Close</button></div></section></div>}
      {toast && <div className="toast" role="status"><CheckCircle2 size={16}/>{toast}<button onClick={()=>setToast('')}>×</button></div>}
    </main>
  </div>
}
async function GenCopy(value: string) { try { await navigator.clipboard.writeText(value) } catch { /* clipboard may be blocked in non-secure contexts */ } }
function Metric({icon,label,value,detail}:{icon:React.ReactNode,label:string,value:string,detail:string}) { return <div className="metric"><div className="metric-top"><span className="metric-icon">{icon}</span><span className="metric-detail">{detail}</span></div><strong>{value}</strong><small>{label}</small></div> }
function NodeButton({icon,title,desc,onClick}:{icon:React.ReactNode,title:string,desc:string,onClick:()=>void}) { return <button className="node-button" onClick={onClick}><span className="node-icon">{icon}</span><span><b>{title}</b><small>{desc}</small></span><Plus size={15}/></button> }
function Range({label,value,min,max,step,display,onChange}:{label:string,value:number,min:number,max:number,step:number,display:string,onChange:(v:number)=>void}) { return <div className="range"><div><label>{label}</label><b>{display}</b></div><input type="range" min={min} max={max} step={step} value={value} onChange={e=>onChange(Number(e.target.value))}/><div className="range-limits"><span>{min.toLocaleString('en-US')}</span><span>{max.toLocaleString('en-US')}</span></div></div> }
function GovernanceCard({icon,title,status,body}:{icon:React.ReactNode,title:string,status:string,body:string}) { return <div className="panel governance-card"><div className="gov-head"><span className="metric-icon">{icon}</span><span className="tag">{status}</span></div><h3>{title}</h3><p>{body}</p></div> }
export default App

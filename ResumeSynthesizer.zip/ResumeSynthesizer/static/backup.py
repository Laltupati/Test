import os
import re
import requests
import json
from flask import Flask, render_template, request, jsonify, send_file, session
from flask_session import Session
from PyPDF2 import PdfReader
import docx
from collections import Counter
from docx import Document
from docx.shared import Inches  
from flask.helpers import send_from_directory
from flask import send_file

app = Flask(__name__)
app.secret_key = "super_secret_key"
app.config["UPLOAD_FOLDER"] = "uploaded_files"
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = "session_data"


Session(app)

ALLOWED_EXTENSIONS = {"pdf", "docx"}
QUALITIES = ['communication', 'programming', 'leadership', 'teamwork', 'analytical', 'creative']

def allowed_file(filename):
    return (
        "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def extract_resume_skill_scores(resume_lines):
    total_skill_score = 0
    for line in resume_lines:
        match = re.match(r"\s*\|\s*[^|]+\s*\|\s*\d+\s*\|\s*(\d+)\s*\|", line)
        if match:
            skill_score = int(match.group(1))
            total_skill_score += skill_score
    return total_skill_score


def read_document_content(file_path):
    if file_path.endswith(".pdf"):
        text = ""
        with open(file_path, "rb") as f:
            pdf_reader = PdfReader(f)

            for page in pdf_reader.pages:
                text += page.extract_text()

        return text
    elif file_path.endswith(".docx"):
        text = ""
        document = docx.Document(file_path)
        for paragraph in document.paragraphs:
            text += paragraph.text + "\n"
        return text


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    resume_files = request.files.getlist("resumes")
    jd_file = request.files["jd"]
    save_path = app.config["UPLOAD_FOLDER"]

    if not os.path.exists(save_path):
        os.makedirs(save_path)

    jd_filepath = os.path.join(save_path, jd_file.filename)
    jd_file.save(jd_filepath)

    uploaded_resumes = []
    for file in resume_files:
        if file and allowed_file(file.filename):
            filename = file.filename
            file_path = os.path.join(save_path, filename)
            file.save(file_path)
            uploaded_resumes.append({"name": filename, "path": file_path})

    # Store uploaded resumes and JD in session
    session["resumes"] = uploaded_resumes
    session["jd"] = jd_filepath
    return jsonify({"resumes": uploaded_resumes, "jd": jd_filepath})


@app.route("/api/send_prompt", methods=["POST"])
def send_prompt():
    prompt = request.form.get("prompt")
    conversation_history = request.form.get("conversation_history")
    
    api_url = "https://oai-kgsgpt-testapp.openai.azure.com/openai/deployments/gpt-35-turbo-16k/chat/completions?api-version=2023-03-15-preview"
    api_key = "d4595b37d235460395fa78721602c87b"

    headers = {"api-key": api_key}

    query_data = {
        "messages": [
                {"role": "system", "content": f"{conversation_history}\n{prompt}"}
            ],
            "temperature": 0.3,
            "top_p": 1,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 4000,
            "stop": None,
        }
    
    response = requests.post(api_url, headers=headers, json=query_data, verify=False)
    response_data = response.json()
    generated_text = response_data["choices"][0]["message"]["content"].strip()
    print(generated_text)

    return jsonify({"response": generated_text})

def send_gpt3_request(prompt):
    api_url = "https://oai-kgsgpt-testapp.openai.azure.com/openai/deployments/gpt-35-turbo-16k/chat/completions?api-version=2023-03-15-preview"
    api_key = "d4595b37d235460395fa78721602c87b"

    headers = {"api-key": api_key}

    query_data = {
        "messages": [
                {"role": "system", "content": prompt}
            ],
            "temperature": 0.3,
            "top_p": 1,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 4000,
            "stop": None,
        }
    
    try:
        response = requests.post(api_url, headers=headers, json=query_data)
        response_data = response.json()
        if "choices" not in response_data:
            print("Error response from the GPT-3 API:", response_data)
            return {"choices": [{"text": ""}]}
        return response_data
    
    except Exception as e:
        print(f"Error while sending request to GPT-3 API: {e}")
        return {"choices": [{"text": ""}]}

def extract_skills_score(generated_text):
    match = re.match(
        r"\s*Total Skillset Score:\s*(\d+)",
        generated_text,
    )
    if match:
        return int(match.group(1))
    return 0


@app.route("/api/display_skills_ranking_table", methods=["POST"])
def display_skills_ranking_table():
    resumes = session.get("resumes")
    jd = session.get("jd")
    jd_file_name = os.path.basename(jd)
    resume_file_names = [os.path.basename(resume["path"]) for resume in resumes]

    prompt = f"Please provide the total skillset scores summarizing the compatibility of each of these resumes with the job requirements for {jd_file_name}. The resumes are: {', '.join(resume_file_names)}. Provide the scores in the following format: \"Resume: {{resume_file_name}} - Total Skillset Score: {{score}}\"."

    conversation_history_with_prompt = f"\n{prompt}"

    response_data = send_gpt3_request(conversation_history_with_prompt)
    generated_text = response_data["choices"][0]["message"]["content"].strip()

    lines = generated_text.split("\n")

    data = [(m.group(1), int(m.group(2))) for line in lines if (m := re.match(r"\s*Resume:\s*(.+)\s*-\s*Total Skillset Score:\s*(\d+)", line)) is not None]
    html_table = convert_to_html_table(data)
    session["skill_ranking_table"] = html_table  # Add this line to save the HTML table in the session
    return jsonify({"table": html_table})

# @app.route("/api/send_prompt_pros_cons", methods=["POST"])
# def send_prompt_pros_cons():
#     resumes = session.get("resumes")

#     # Dummy data for demonstration purposes
#     # Replace this with the actual logic for generating pros and cons based on uploaded resumes
#     pros_cons = generate_pros_cons_based_on_resumes([read_document_content(r["path"]) for r in resumes])

#     data = "\n".join(
#         [
#             f"Candidate {i + 1}: {resume['name']} - Pros: {pro_con[0]}; Cons: {pro_con[1]}"
#             for i, (resume, pro_con) in enumerate(zip(resumes, pros_cons))
#         ]
#     )

#     return jsonify({"pros_cons": data})

# # Dummy pros and cons generator function
# # Replace this function with the actual logic for generating pros and cons based on resumes
# def generate_pros_cons_based_on_resumes(resumes):
#     return [
#         (
#             "Strong experience in required technologies, excellent communication skills",
#             "Limited industry experience, unfamiliar with certain tools",
#         ),
#         (
#             "In-depth knowledge of industry, worked with leading clients",
#             "Lacks experience in specific technologies, less hands-on experience",
#         ),
#         (
#             "Solid programming skills, good understanding of tools",
#             "Limited client interaction, needs improvement in communication",
#         ),
#     ]

# def extract_skills(text):
#     words = text.lower().split()
#     skills = [word for word in words if word.strip(".,") in QUALITIES] # Please add more skills or process custom field
#     return Counter(skills)

# @app.route("/api/display_pros_cons_table", methods=["POST"])
# def display_pros_cons_table_api():
#     resumes = session.get("resumes")
#     jd = session.get("jd")
#     return display_pros_cons_table(resumes, jd)

# def display_pros_cons_table(resumes, jd):
#     jd_text = read_document_content(jd)
#     jd_counter = extract_skills(jd_text)

#     data = []

#     for r in resumes:
#         resume_text = read_document_content(r["path"])
#         resume_counter = extract_skills(resume_text)

#         pros = [f"{key}:{resume_counter[key]}" for key in resume_counter if key in jd_counter]
#         cons = [f"{key}:{jd_counter[key]}" for key in jd_counter if key not in resume_counter]

#         data.append((os.path.basename(r["path"]), ", ".join(pros), ", ".join(cons)))

#     html_table = convert_pros_cons_to_html_table(data)
#     return jsonify({"table": html_table})

@app.route("/api/display_pros_cons_table", methods=["POST"])
def display_pros_cons_table():
    resumes = session.get("resumes")
    jd = session.get("jd")

    results = []
    for index, resume in enumerate(resumes, start=1):
        resume_file_name = os.path.basename(resume["path"])
        prompt = f"Display the pros and cons of candidate {index}: {resume_file_name}. Use the format: \"Pros: {{pros}}; Cons: {{cons}}\"."

        conversation_history_with_prompt = f"{read_document_content(resume['path'])}\n{read_document_content(jd)}\n{prompt}"
        
        response_data = send_gpt3_request(conversation_history_with_prompt)
        generated_text = response_data["choices"][0]["message"]["content"].strip()

        formatted_text = f"Candidate {index}: {resume_file_name} - {generated_text}\n"
        results.append(formatted_text)

    # Format the pros and cons text and store it in the session
    formatted_text_list = []
    for result in results:
        formatted_text = result.replace("Pros:", "<br>Pros:").replace("Cons:", "<br>Cons:")
        formatted_text += "<hr>"
        formatted_text_list.append(formatted_text)

    session["pros_cons_html"] = "".join(formatted_text_list)
    return jsonify({"results": results})


def extract_pros_and_cons(generated_text):
    match = re.match(r"\s*Pros:\s*(.+)\s*;\s*Cons:\s*(.+)", generated_text)
    if match:
        return match.groups()
    return "", ""

# def convert_pros_cons_to_html_table(data):
#     html_table = '<table border="1" cellpadding="5" cellspacing="0">'
#     html_table += "<tr><th colspan='3'>Pros and Cons Table</th></tr>"
#     html_table += "<tr><th>Resume</th><th>Pros</th><th>Cons</th></tr>"

#     for row in data:
#         html_table += f"<tr><td>{row[0]}</td><td>{row[1]}</td><td>{row[2]}</td></tr>"

#     html_table += "</table>"
#     return html_table

# @app.route("/api/send_custom_prompt", methods=["POST"])
# def send_custom_prompt():
#     prompt = request.form.get("prompt")
#     conversation_history = ""

#     prompt_with_instruction = (
#         prompt
#         + "\n"
#         + "Stay in character and don't provide generic responses. Provide quantification whenever possible."
#     )

#     response_data = send_gpt3_request(prompt_with_instruction)
#     generated_text = response_data["choices"][0]["message"]["content"].strip()
#     return jsonify({"response": generated_text})

@app.route("/api/send_custom_prompt", methods=["POST"])
def send_custom_prompt():
    prompt = request.form.get("prompt")
    resumes_text = "\n".join([read_document_content(resume["path"]) for resume in session.get("resumes")])
    conversation_history = request.form.get("conversation_history", "")
    skill_ranking_table_html = session.get("skill_ranking_table", "")
    pros_cons_html = session.get("pros_cons_html", "")

    prompt_with_content = (f"{resumes_text}\n"
                           f"{read_document_content(session['jd'])}\n"
                           f"{skill_ranking_table_html}\n"
                           f"{pros_cons_html}\n"
                           f"{conversation_history}\n"
                           f"{prompt}\n"
                           "Stay in character and don't provide generic responses. Provide quantification whenever possible.")
    
    response_data = send_gpt3_request(prompt_with_content)
    generated_text = response_data["choices"][0]["message"]["content"].strip()
    return jsonify({"response": generated_text})

def convert_to_html_table(data):
    html_table = '<table border="1" cellpadding="5" cellspacing="0">'
    html_table += "<tr><th colspan='2'>Skills Ranking Table</th></tr>"
    html_table += "<tr><th>Resume</th><th>Skills Score</th></tr>"

    for row in data:
        html_table += f"<tr><td>{row[0]}</td><td>{row[1]}</td></tr>"

    html_table += "</table>"

    explanation = (
        "<p>The skill scores are calculated based on an AI-powered analysis of the content "
        "of the uploaded resumes and the job description. GPT-3.5 Turbo, a powerful natural "
        "language processing model, is used to estimate each candidate's compatibility "
        "with the job requirements by factoring in various skills and qualifications "
        "mentioned in their resumes. Please note that these scores are meant to "
        "provide an initial assessment and should not replace human judgment in the "
        "final decision-making process.</p>"
    )

    html_table += explanation
    return html_table

@app.route("/api/export_output_in_ms_word", methods=["POST"])
def export_output_in_ms_word():
    content = request.form.get("content")
    document = Document()
    p = document.add_paragraph(content)

    # Save the document
    output_file = "output.docx"
    document.save(output_file)

    # Send the file to the user
    return send_file(output_file, as_attachment=True, download_name=output_file)


# Run the application
if __name__ == "__main__":
    app.run(debug=True)
$(document).ready(function() {
    $("#upload-form").submit(function(event) {
        event.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: "/upload",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data) {
                var fileListHtml = "Job Description: " + data.jd + "<br>Resumes:" + data.resumes.map(function(resume) {
                    return "<br>" + resume.path;
                }).join("");
                $("#results").html(fileListHtml);
            },
            error: function() {
                $("#results").html("Error Occurred.");
            }
        });
    });

    $("#display-skills-ranking-table").click(function() {
        $.ajax({
            url: "/api/display_skills_ranking_table",
            type: "POST",
            success: function(data) {
                $("#results").html(data.table);
            },
            error: function() {
                $("#results").html("Error Occurred.");
            }
        });
    });
    

    $("#display-pros-cons-table").click(function () {
        $.ajax({
          url: "/api/display_pros_cons_table",
          type: "POST",
          success: function (data) {
            let content = "";
            data.results.forEach((result) => {
              content += result.replace("Pros:", "<br>Pros:").replace("Cons:", "<br>Cons:");
              content += "<hr>";
            });
            $("#results").html(content);
          },
          error: function () {
            $("#results").html("Error occurred.");
          },
        });
    });     

    $("#send-prompt").click(function () {
        const prompt = $("#prompt-input").val().trim();
        if (!prompt) {
          alert("Please enter a prompt before sending.");
          return;
        }
      
        $.ajax({
          url: "/api/send_custom_prompt",
          type: "POST",
          data: { prompt: prompt, conversation_history: "" },
          success: function (data) {
            const generated_text = data.response;
            // Display the GPT-3 response
            $("#results").html(`<p>${generated_text}</p>`);
            $("#prompt-input").val(""); // Clear the text input
          },
          error: function () {
            alert("An error occurred.");
          },
        });
    });     

    $("#export-output-in-ms-word").click(function () {
      const content = $("#results").text();
      $.ajax({
          url: "/api/export_output_in_ms_word",
          type: "POST",
          data: { content: content },
          xhrFields: {
              responseType: "blob",
          },
          success: function (blob) {
              var link = document.createElement("a");
              var url = URL.createObjectURL(blob);
              link.href = url;
              link.download = "output.docx";
              document.body.appendChild(link);
              link.click();
              setTimeout(function () {
                  document.body.removeChild(link);
                  URL.revokeObjectURL(url);
              }, 100);
  
              // Display message to the user
              alert("The content has been downloaded as a Word document. Please check your downloads folder.");
          },
          error: function () {
              alert("An error occurred.");
          },
      });
    });

    function clearResults() {
      $("#results").html("");
    }  
});
  
  


@description('Globally unique App Service name. Lowercase letters, numbers, and hyphens only.')
param appName string
param location string = resourceGroup().location
@description('DEV, TEST or PROD')
param environmentName string = 'DEV'

var planName = '${appName}-plan'
var tags = {
  managedBy: 'AdminDeploymentTab'
  environment: environmentName
  deploymentPurpose: 'UploadedApplication'
}

resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  kind: 'linux'
  sku: {
    name: environmentName == 'PROD' ? 'P1v3' : 'B1'
    tier: environmentName == 'PROD' ? 'PremiumV3' : 'Basic'
    capacity: 1
  }
  properties: {
    reserved: true
    perSiteScaling: false
    maximumElasticWorkerCount: 1
  }
  tags: tags
}

resource web 'Microsoft.Web/sites@2023-12-01' = {
  name: appName
  location: location
  kind: 'app,linux'
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'NODE|22-lts'
      alwaysOn: environmentName == 'PROD'
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      http20Enabled: true
    }
  }
  tags: tags
}
resource webSettings 'Microsoft.Web/sites/config@2023-12-01' = {
  parent: web
  name: 'appsettings'
  properties: {
    WEBSITE_RUN_FROM_PACKAGE: '1'
    NODE_ENV: 'production'
  }
}
output webAppName string = web.name
output webAppUrl string = 'https://${web.properties.defaultHostName}'
output resourceGroupName string = resourceGroup().name

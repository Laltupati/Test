import React, { useCallback, useEffect, useMemo, useState } from 'react';

const FLOW = [
  { key: 'source', title: 'Source validation', detail: 'ZIP package and file intake checks' },
  { key: 'scan', title: 'Security scan', detail: 'Secrets, SAST, dependencies, IaC and container checks' },
  { key: 'gate', title: 'Security gate', detail: 'Remediation, or eligible waiver with audit trail' },
  { key: 'infra', title: 'Infrastructure plan / provisioning', detail: 'Bicep template validation and scoped Azure resource deployment' },
  { key: 'build', title: 'Build & deploy', detail: 'Build, package, provisioned App Service release' },
  { key: 'smoke', title: 'Smoke test', detail: 'Post-deployment HTTP verification and result' },
];
const ACTIVE_STAGE = { scanning: 'scan', 'security-gate': 'gate', build: 'build', provisioning: 'infra', deploying: 'build', 'smoke-test': 'smoke' };
const STATUS_LABELS = {
  'not-started': 'Not started', running: 'In progress', 'waiting-decision': 'Security decision required',
  'configuration-required': 'Configuration required', 'trigger-failed': 'Pipeline trigger failed',
  'remediation-required': 'Fix findings & re-upload', completed: 'Completed', failed: 'Failed', canceled: 'Canceled',
};
function formatSize(bytes) { if (!Number.isFinite(bytes)) return '—'; if (bytes < 1024) return `${bytes} B`; if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`; return `${(bytes / (1024 * 1024)).toFixed(1)} MB`; }
function countFindings(counts = {}) { return Object.values(counts).reduce((n, v) => n + Number(v || 0), 0); }

export default function Deployment({ adminFetch }) {
  const [readiness, setReadiness] = useState(null); const [history, setHistory] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null); const [environment, setEnvironment] = useState('DEV');
  const [dragging, setDragging] = useState(false); const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState(''); const [error, setError] = useState('');
  const [waiverReasons, setWaiverReasons] = useState({}); const [decisionBusy, setDecisionBusy] = useState('');

  const refresh = useCallback(async () => {
    try {
      const [readyRes, historyRes] = await Promise.all([adminFetch('/api/admin/deployment/readiness'), adminFetch('/api/admin/deployment/uploads')]);
      if (readyRes.ok) setReadiness(await readyRes.json());
      if (historyRes.ok) setHistory(await historyRes.json());
    } catch (err) { setError(err?.message || 'Unable to load deployment configuration.'); }
  }, [adminFetch]);
  useEffect(() => { refresh(); const id = setInterval(refresh, 20000); return () => clearInterval(id); }, [refresh]);

  const maxBytes = readiness?.maxUploadBytes || 25 * 1024 * 1024;
  const chooseFile = (file) => { setMessage(''); setError(''); if (!file) return; if (!file.name.toLowerCase().endsWith('.zip')) return setError('Please upload a ZIP package.'); if (file.size > maxBytes) return setError(`File exceeds the ${formatSize(maxBytes)} upload limit.`); setSelectedFile(file); };
  const upload = async () => {
    if (!selectedFile || uploading) return;
    setUploading(true); setMessage(''); setError('');
    try {
      const response = await adminFetch('/api/admin/deployment/upload', { method: 'POST', headers: { 'Content-Type': 'application/zip', 'X-Upload-Filename': selectedFile.name, 'X-Target-Environment': environment }, body: selectedFile });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Upload failed (${response.status}).`);
      setMessage(data.message || `${data.filename || selectedFile.name} accepted.`); setSelectedFile(null); await refresh();
    } catch (err) { setError(err?.message || 'Upload failed.'); await refresh(); }
    finally { setUploading(false); }
  };
  const submitDecision = async (upload, decision) => {
    const reason = waiverReasons[upload.uploadId] || '';
    if (decision === 'continue' && reason.trim().length < 10) { setError('For a waiver, enter a reason with at least 10 characters.'); return; }
    setDecisionBusy(upload.uploadId); setError('');
    try {
      const response = await adminFetch(`/api/admin/deployment/decision/${upload.uploadId}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ decision, reason }) });
      const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || 'Unable to submit decision.');
      setMessage(decision === 'continue' ? 'Waiver decision recorded. Pipeline will continue.' : 'Remediation selected. Fix findings and upload a new source revision.'); await refresh();
    } catch (e) { setError(e.message || 'Decision submission failed.'); }
    finally { setDecisionBusy(''); }
  };

  const stats = useMemo(() => ({ uploads: history.length, active: history.filter(x => ['running', 'waiting-decision'].includes(x.pipelineStatus)).length, complete: history.filter(x => x.pipelineStatus === 'completed').length }), [history]);
  const stageState = (item, index, record) => {
    const current = ACTIVE_STAGE[record.pipelineStage];
    if (index === 0) return 'done';
    if (item.key === 'scan') return record.scanSummary ? 'done' : current === 'scan' ? 'active' : record.pipelineStatus === 'running' ? 'active' : 'pending';
    if (item.key === 'gate') return record.securityDecision === 'continue' ? 'done' : record.pipelineStatus === 'waiting-decision' ? 'active' : record.pipelineStatus === 'remediation-required' || (record.scanSummary?.counts?.CRITICAL > 0) ? 'blocked' : current === 'gate' ? 'active' : 'pending';
    if (item.key === 'infra') return record.deploymentResult?.resourceGroup ? 'done' : current === 'infra' ? 'active' : record.pipelineStatus === 'failed' ? 'blocked' : 'pending';
    if (item.key === 'build') return record.deploymentResult?.appName ? 'done' : current === 'build' ? 'active' : 'pending';
    if (item.key === 'smoke') return record.deploymentResult?.status === 'succeeded' ? 'done' : record.deploymentResult?.status === 'failed' ? 'blocked' : current === 'smoke' ? 'active' : 'pending';
    return 'pending';
  };

  return <div className="ad-deployment-page">
    <div className="ad-page-header"><div><h1 className="ad-page-title">Deployment</h1><p className="ad-page-subtitle">Upload source to trigger security validation, Azure infrastructure provisioning and application deployment.</p></div><button type="button" className="ad-deployment-refresh" onClick={refresh} disabled={uploading}>↻ Refresh</button></div>
    <div className="ad-deployment-banner"><div className="ad-deployment-banner-icon">⇪</div><div><strong>Infra Deployment + DevSecOps Pipeline</strong><p>Upload code once. The configured Azure DevOps pipeline validates, scans, provisions infrastructure, builds, deploys and verifies the application. Security findings can pause the pipeline for your decision.</p></div></div>
    <div className="ad-deployment-stat-grid"><div className="ad-deployment-stat"><span>Source uploads</span><strong>{stats.uploads}</strong><small>Recent packages</small></div><div className="ad-deployment-stat"><span>Azure DevOps</span><strong className={readiness?.pipelineConfigured ? 'configured' : 'not-configured'}>{readiness?.pipelineConfigured ? 'Connected' : 'Not configured'}</strong><small>Pipeline trigger readiness</small></div><div className="ad-deployment-stat"><span>Active runs</span><strong>{stats.active}</strong><small>Running or awaiting a security decision</small></div></div>
    <div className="ad-deployment-main-grid">
      <section className="ad-deployment-card"><div className="ad-deployment-card-header"><div><h2>Upload Application Source</h2><p>Upload a ZIP package to start automated intake.</p></div><span className="ad-deployment-badge">INTAKE</span></div>
        <div className={`ad-deployment-dropzone${dragging ? ' dragging' : ''}${selectedFile ? ' has-file' : ''}`} onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); chooseFile(e.dataTransfer.files?.[0]); }}><div className="ad-deployment-upload-icon">↑</div><strong>Drag and drop your application ZIP here</strong><span>or choose a file from your computer</span><label className="ad-deployment-browse">Browse files<input type="file" accept=".zip,application/zip" onChange={e => chooseFile(e.target.files?.[0])}/></label><small>ZIP only · Maximum {formatSize(maxBytes)}</small></div>
        {selectedFile && <div className="ad-deployment-file-chip"><span>▣</span><div><b>{selectedFile.name}</b><small>{formatSize(selectedFile.size)}</small></div><button type="button" aria-label="Remove file" onClick={() => setSelectedFile(null)}>×</button></div>}
        <div className="ad-deployment-options"><label htmlFor="deployment-env">Target environment</label><select id="deployment-env" value={environment} onChange={e => setEnvironment(e.target.value)}><option value="DEV">Development</option><option value="TEST">Test</option><option value="PROD">Production</option></select><p>Pipeline uses environment-specific resource naming. Production deployments should be restricted by Azure DevOps approval policy.</p></div>
        <button type="button" className="ad-deployment-upload-button" disabled={!selectedFile || uploading} onClick={upload}>{uploading ? 'Uploading & triggering pipeline…' : 'Upload & Start Deployment'}</button>{message && <div className="ad-deployment-feedback success" role="status">✓ {message}</div>}{error && <div className="ad-deployment-feedback error" role="alert">! {error}</div>}
      </section>
      <section className="ad-deployment-card"><div className="ad-deployment-card-header"><div><h2>Automated Workflow</h2><p>Live stages for the selected deployment run</p></div></div>{history[0] ? <div className="ad-deployment-workflow">{FLOW.map((stage, i) => { const state = stageState(stage, i, history[0]); return <div className={`ad-deployment-stage ad-deployment-stage-${state}`} key={stage.key}><div className="ad-deployment-stage-number">{state === 'done' ? '✓' : String(i + 1).padStart(2, '0')}</div><div><strong>{stage.title}</strong><span>{stage.detail}</span></div><span className="ad-deployment-stage-state">{state === 'done' ? 'Complete' : state === 'active' ? 'In progress' : state === 'blocked' ? 'Blocked' : 'Pending'}</span></div>})}</div> : <div className="ad-deployment-empty">Upload a ZIP to start the workflow.</div>}</section>
    </div>
    <section className="ad-deployment-card ad-deployment-history-card"><div className="ad-deployment-card-header"><div><h2>Recent Uploads</h2><p>Deployment runs, scan findings and decisions</p></div></div>{history.length === 0 ? <div className="ad-deployment-empty">No source packages uploaded yet.</div> : <div className="ad-deployment-history-list">{history.map(item => <div className="ad-deployment-history-row ad-deployment-history-row-expanded" key={item.uploadId}><div className="ad-deployment-history-icon">ZIP</div><div className="ad-deployment-history-details"><strong>{item.filename}</strong><span>{new Date(item.createdAt).toLocaleString()} · {formatSize(item.sizeBytes)}</span><small>Environment: {item.targetEnvironment || 'DEV'} · Status: {STATUS_LABELS[item.pipelineStatus] || item.pipelineStatus}</small>{item.pipelineStage && <small>Current stage: {item.pipelineStage} — {item.pipelineMessage}</small>}{item.pipelineRunUrl && <a href={item.pipelineRunUrl} target="_blank" rel="noreferrer">Open Azure DevOps run ↗</a>}{item.deploymentResult?.appUrl && <a href={item.deploymentResult.appUrl} target="_blank" rel="noreferrer">Open deployed app ↗</a>}{item.securityDecisionAt && <small>Security decision: {item.securityDecision} by {item.securityDecisionBy || 'Admin'} · {new Date(item.securityDecisionAt).toLocaleString()} · {item.securityDecisionReason}</small>}{item.scanSummary && <div className="ad-deployment-findings"><strong>Security findings:</strong> {Object.entries(item.scanSummary.counts || {}).map(([sev, count]) => `${sev}: ${count}`).join(' · ')}<div className="ad-deployment-finding-list">{item.scanSummary.findings?.slice(0, 10).map((f, ix) => <div key={`${item.uploadId}-${ix}`}><b>{f.severity}</b> · {f.scanner} · {f.title}{f.file ? <small>{f.file}</small> : null}</div>)}</div></div>}{(item.pipelineStatus === 'waiting-decision' || item.pipelineStatus === 'remediation-required' || (item.scanSummary && ['failed', 'canceled'].includes(item.pipelineStatus))) && <div className="ad-deployment-decision"><label htmlFor={`waiver-${item.uploadId}`}>Waiver reason (required to continue; Critical findings are blocked)</label><textarea id={`waiver-${item.uploadId}`} rows={2} value={waiverReasons[item.uploadId] || ''} onChange={e => setWaiverReasons(prev => ({ ...prev, [item.uploadId]: e.target.value }))} placeholder="Explain why continuing with the findings is acceptable (10+ characters)."/><div className="ad-deployment-decision-actions"><button type="button" disabled={decisionBusy === item.uploadId} onClick={() => submitDecision(item, 'fix')}>Fix & re-upload</button><button type="button" className="continue" disabled={decisionBusy === item.uploadId || item.pipelineStatus !== 'waiting-decision' || Number(item.scanSummary?.counts?.CRITICAL || item.scanSummary?.counts?.critical || 0) > 0} onClick={() => submitDecision(item, 'continue')}>Continue with waiver</button></div></div>}</div><span className={`ad-deployment-status-pill ${item.pipelineStatus || 'pending'}`}>{STATUS_LABELS[item.pipelineStatus] || item.pipelineStatus || 'Pending'}</span></div>)}</div>}</section>
    <div className="ad-deployment-integration-note"><strong>Integration status:</strong> {readiness?.pipelineConfigured ? 'Azure DevOps API settings are present. The pipeline YAML, Azure service connection, variable configuration and target subscription permissions must also be configured in DevOps.' : 'Upload intake remains available, but automated pipeline triggering requires AZDO_ORG_URL, AZDO_PROJECT, AZDO_PIPELINE_ID, AZDO_PAT, DEPLOY_SOURCE_TOKEN_SECRET and DEPLOY_CALLBACK_BASE_URL.'} Initial pipeline profile supports Node.js App Service; unsupported project types fail validation rather than being falsely marked deployed.</div>
  </div>;
}

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { useCases, systemHealth, monitoringData, executionStats } = require('./data');
const adminHealth = require('./adminHealth');
const costMetrics = require('./costMetrics');
const azureLogs = require('./azureLogs');
const { requireEntraAuth, allowedEmailsCount } = require('./entraAuth');

const app = express();

// Admin Panel Deployment: secure intake + Azure DevOps pipeline handoff.
const DEPLOY_UPLOAD_LIMIT_BYTES = Math.max(1, Number(process.env.DEPLOY_UPLOAD_LIMIT_MB || 25)) * 1024 * 1024;
const DEPLOY_QUARANTINE_DIR = process.env.DEPLOY_QUARANTINE_DIR || path.join(os.tmpdir(), 'genai-admin-deployment-quarantine');
const DEPLOY_METADATA_PATH = path.join(DEPLOY_QUARANTINE_DIR, 'metadata.json');
const deploymentUploads = [];
fs.mkdirSync(DEPLOY_QUARANTINE_DIR, { recursive: true, mode: 0o700 });
const uploadExpiryMs = Math.max(1, Number(process.env.DEPLOY_UPLOAD_RETENTION_HOURS || 24)) * 60 * 60 * 1000;
function persistDeployments() { try { const temp = `${DEPLOY_METADATA_PATH}.tmp`; fs.writeFileSync(temp, JSON.stringify(deploymentUploads.map(({ filePath, ...m }) => m), null, 2), { mode: 0o600 }); fs.renameSync(temp, DEPLOY_METADATA_PATH); } catch (e) { console.error('[deployment] metadata save failed', e.message); } }
try { const records = JSON.parse(fs.readFileSync(DEPLOY_METADATA_PATH, 'utf8')); if (Array.isArray(records)) records.forEach(m => { const filePath = path.join(DEPLOY_QUARANTINE_DIR, `${m.uploadId}.zip`); if (fs.existsSync(filePath)) deploymentUploads.push({ ...m, filePath }); }); } catch { /* first run */ }
function findDeployment(id) { return deploymentUploads.find(x => x.uploadId === id); }
function makeDeployToken(id, exp) { const secret = process.env.DEPLOY_SOURCE_TOKEN_SECRET; if (!secret) throw new Error('DEPLOY_SOURCE_TOKEN_SECRET is missing'); return `${exp}.${crypto.createHmac('sha256', secret).update(`${id}.${exp}`).digest('hex')}`; }
function validDeployToken(id, token) { try { const [expText, sig] = String(token || '').split('.'); const exp = Number(expText); if (!process.env.DEPLOY_SOURCE_TOKEN_SECRET || !sig || exp < Date.now()) return false; const expected = crypto.createHmac('sha256', process.env.DEPLOY_SOURCE_TOKEN_SECRET).update(`${id}.${exp}`).digest('hex'); return crypto.timingSafeEqual(Buffer.from(sig, 'hex'), Buffer.from(expected, 'hex')); } catch { return false; } }
function deployTokenFromRequest(req) { const auth = String(req.get('authorization') || ''); return req.query.token || (auth.startsWith('Bearer ') ? auth.slice(7) : ''); }
function adoSettings() { return { org: String(process.env.AZDO_ORG_URL || '').replace(/\/$/, ''), project: process.env.AZDO_PROJECT || '', pipelineId: process.env.AZDO_PIPELINE_ID || '', pat: process.env.AZDO_PAT || '' }; }
function isHttpsEndpoint(value) { try { return new URL(String(value || '')).protocol === 'https:'; } catch { return false; } }
function adoReady() { const a = adoSettings(); return Boolean(isHttpsEndpoint(a.org) && a.project && a.pipelineId && a.pat && process.env.DEPLOY_SOURCE_TOKEN_SECRET && isHttpsEndpoint(process.env.DEPLOY_CALLBACK_BASE_URL)); }
async function triggerAdo(record) { const a = adoSettings(); const token = makeDeployToken(record.uploadId, Date.now() + 48 * 60 * 60 * 1000); const url = `${a.org}/${encodeURIComponent(a.project)}/_apis/pipelines/${encodeURIComponent(a.pipelineId)}/runs?api-version=7.1`; const response = await fetch(url, { method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`:${a.pat}`).toString('base64')}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ templateParameters: { uploadId: record.uploadId, filename: record.filename, targetEnvironment: record.targetEnvironment }, variables: { sourceDownloadToken: { value: token, isSecret: true } } }) }); const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(`ADO trigger failed HTTP ${response.status}: ${data.message || 'unknown error'}`); record.pipelineRunId = data.id; record.pipelineRunUrl = data._links?.web?.href || data.url || `${a.org}/${encodeURIComponent(a.project)}/_build/results?buildId=${data.id}`; record.pipelineStatus = 'running'; record.pipelineMessage = 'Pipeline triggered'; record.pipelineStartedAt = new Date().toISOString(); persistDeployments(); }
async function refreshAdoStatus(record) { const a = adoSettings(); if (!record.pipelineRunId || !a.org || !a.pat) return; const url = `${a.org}/${encodeURIComponent(a.project)}/_apis/pipelines/${encodeURIComponent(a.pipelineId)}/runs/${record.pipelineRunId}?api-version=7.1`; const r = await fetch(url, { headers: { Authorization: `Basic ${Buffer.from(`:${a.pat}`).toString('base64')}` } }); if (!r.ok) throw new Error(`ADO status HTTP ${r.status}`); const run = await r.json(); if (run.state === 'completed') { record.pipelineStatus = ({ succeeded: 'completed', failed: 'failed', canceled: 'canceled' })[run.result] || run.result || 'completed'; record.pipelineCompletedAt = new Date().toISOString(); } }
function cleanupDeployments() { const cutoff = Date.now() - uploadExpiryMs; for (let i = deploymentUploads.length - 1; i >= 0; i--) { const x = deploymentUploads[i]; if (Date.parse(x.createdAt) < cutoff && !['running', 'waiting-decision'].includes(x.pipelineStatus)) { try { fs.unlinkSync(x.filePath); } catch {} deploymentUploads.splice(i, 1); } } persistDeployments(); }
setInterval(cleanupDeployments, 30 * 60 * 1000).unref();
const port = process.env.PORT || 3000;
useCases.forEach(uc => { uc.launches = 0; });
app.use(cors()); app.use(express.json({ limit: '1mb' }));
app.get('/api/admin/deployment/readiness', requireEntraAuth, (req, res) => { res.set('Cache-Control', 'no-store'); const configured = adoReady() && Boolean(process.env.DEPLOY_CALLBACK_BASE_URL); res.json({ uploadEnabled: true, pipelineConfigured: configured, adoCredentialsPresent: Boolean(process.env.AZDO_ORG_URL && process.env.AZDO_PROJECT && process.env.AZDO_PIPELINE_ID && process.env.AZDO_PAT), pipelineIntegration: configured ? 'configured' : 'missing-configuration', sourceTransferConfigured: Boolean(process.env.DEPLOY_SOURCE_TOKEN_SECRET), scanners: { secretScan: configured, sast: configured, dependencyScan: configured, iacScan: configured }, maxUploadBytes: DEPLOY_UPLOAD_LIMIT_BYTES, note: configured ? 'Uploads trigger Azure DevOps. The selected pipeline must be configured with the deployment YAML and Azure service connection.' : 'Set Azure DevOps organization/project/pipeline/PAT, callback base URL and source token secret to enable pipeline handoff.' }); });
app.get('/api/admin/deployment/uploads', requireEntraAuth, async (req, res) => { cleanupDeployments(); for (const x of deploymentUploads.slice(0, 25)) { if (x.pipelineRunId && ['running', 'waiting-decision'].includes(x.pipelineStatus)) { try { await refreshAdoStatus(x); } catch (e) { x.pipelineMessage = e.message; } } } persistDeployments(); res.json(deploymentUploads.slice(0, 25).map(({ filePath, ...m }) => m)); });
app.get('/api/admin/deployment/source/:uploadId', (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !validDeployToken(x.uploadId, deployTokenFromRequest(req))) return res.status(403).send('Invalid or expired source token'); if (!fs.existsSync(x.filePath)) return res.status(404).send('Source ZIP not found'); res.set('Cache-Control', 'no-store'); res.type('application/zip').sendFile(x.filePath); });
app.post('/api/admin/deployment/scan-result/:uploadId', (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !validDeployToken(x.uploadId, deployTokenFromRequest(req))) return res.status(403).json({ error: 'Invalid/expired source token' }); const b = req.body || {}; x.scanSummary = { completedAt: new Date().toISOString(), findings: (Array.isArray(b.findings) ? b.findings : []).slice(0, 250), counts: b.counts || {}, scanners: b.scanners || {}, gate: b.gate || 'pending' }; const total = Object.values(x.scanSummary.counts || {}).reduce((sum, n) => sum + Number(n || 0), 0); if (total === 0) { x.securityDecision = 'continue'; x.securityDecisionReason = 'Automatically approved: no findings were reported.'; x.pipelineStatus = 'running'; x.pipelineMessage = 'Security scan passed; pipeline continuing automatically.'; } else { x.pipelineStatus = 'waiting-decision'; x.pipelineMessage = 'Scan completed; awaiting Admin Panel decision'; } persistDeployments(); res.json({ accepted: true, autoApproved: total === 0 }); });
app.get('/api/admin/deployment/decision/:uploadId', (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !validDeployToken(x.uploadId, deployTokenFromRequest(req))) return res.status(403).json({ error: 'Invalid/expired source token' }); res.json({ decision: x.securityDecision || 'pending', reason: x.securityDecisionReason || '', counts: x.scanSummary?.counts || {}, criticalCount: Number(x.scanSummary?.counts?.CRITICAL || x.scanSummary?.counts?.critical || 0), findings: x.scanSummary?.findings || [] }); });
app.post('/api/admin/deployment/decision/:uploadId', requireEntraAuth, (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !['waiting-decision', 'failed', 'remediation-required'].includes(x.pipelineStatus) || !x.scanSummary) return res.status(404).json({ error: 'Run is not awaiting a security decision or remediation' }); const decision = String(req.body?.decision || '').toLowerCase(), reason = String(req.body?.reason || '').trim().slice(0, 1000); if (!['fix', 'continue'].includes(decision)) return res.status(400).json({ error: 'Decision must be fix or continue' }); if (decision === 'continue' && x.pipelineStatus !== 'waiting-decision') return res.status(409).json({ error: 'This pipeline run is no longer waiting. Fix findings and re-upload to start a new run.' }); if (decision === 'continue' && reason.length < 10) return res.status(400).json({ error: 'Waiver reason must be at least 10 characters' }); const critical = Number(x.scanSummary?.counts?.CRITICAL || x.scanSummary?.counts?.critical || 0); if (decision === 'continue' && critical > 0) return res.status(403).json({ error: 'Critical findings are not bypassable' }); x.securityDecision = decision; x.securityDecisionReason = reason; x.securityDecisionAt = new Date().toISOString(); x.securityDecisionBy = req.adminUser?.email || 'unknown-admin'; x.pipelineStatus = decision === 'fix' ? 'remediation-required' : 'running'; x.pipelineMessage = decision === 'fix' ? 'Fix findings and upload a new revision' : 'Continuation approved; waiver recorded'; persistDeployments(); res.json({ accepted: true, pipelineStatus: x.pipelineStatus }); });
app.post('/api/admin/deployment/stage/:uploadId', (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !validDeployToken(x.uploadId, deployTokenFromRequest(req))) return res.status(403).json({ error: 'Invalid/expired source token' }); x.pipelineStage = String(req.body?.stage || '').slice(0, 80); x.pipelineMessage = String(req.body?.message || '').slice(0, 500); x.stageUpdatedAt = new Date().toISOString(); persistDeployments(); res.json({ accepted: true }); });
app.post('/api/admin/deployment/result/:uploadId', (req, res) => { const x = findDeployment(req.params.uploadId); if (!x || !validDeployToken(x.uploadId, deployTokenFromRequest(req))) return res.status(403).json({ error: 'Invalid/expired source token' }); const b = req.body || {}; x.deploymentResult = { completedAt: new Date().toISOString(), status: String(b.status || 'unknown'), appName: String(b.appName || '').slice(0, 100), appUrl: String(b.appUrl || '').slice(0, 300), resourceGroup: String(b.resourceGroup || '').slice(0, 100), message: String(b.message || '').slice(0, 500) }; x.pipelineMessage = x.deploymentResult.message; persistDeployments(); res.json({ accepted: true }); });
app.post('/api/admin/deployment/upload', requireEntraAuth, (req, res) => { const declared = Number(req.headers['content-length'] || 0); const filename = String(req.headers['x-upload-filename'] || 'application.zip').replace(/[\/\r\n\0]/g, '_').slice(0, 180); const targetEnvironment = String(req.headers['x-target-environment'] || 'DEV').toUpperCase(); if (!['DEV', 'TEST', 'PROD'].includes(targetEnvironment)) return res.status(400).json({ error: 'Invalid environment' }); if (!filename.toLowerCase().endsWith('.zip')) return res.status(400).json({ error: 'ZIP only' }); if (declared && declared > DEPLOY_UPLOAD_LIMIT_BYTES) return res.status(413).json({ error: 'Upload size limit exceeded' }); const uploadId = crypto.randomUUID(), filePath = path.join(DEPLOY_QUARANTINE_DIR, `${uploadId}.zip`), out = fs.createWriteStream(filePath, { flags: 'wx', mode: 0o600 }); let bytes = 0, header = Buffer.alloc(0), failed = false; const fail = (status, msg) => { if (failed) return; failed = true; out.destroy(); try { fs.unlinkSync(filePath); } catch {} if (!res.headersSent) res.status(status).json({ error: msg }); }; req.on('data', chunk => { if (failed) return; bytes += chunk.length; if (bytes > DEPLOY_UPLOAD_LIMIT_BYTES) return fail(413, 'Upload size limit exceeded'); if (header.length < 4) header = Buffer.concat([header, chunk.subarray(0, 4 - header.length)]); }); req.on('aborted', () => fail(400, 'Upload interrupted')); req.pipe(out); out.on('error', e => fail(500, `Storage error: ${e.message}`)); out.on('finish', async () => { if (failed) return; const zip = header.length >= 4 && header[0] === 0x50 && header[1] === 0x4b && [3, 5, 7].includes(header[2]) && [4, 6, 8].includes(header[3]); if (!zip || !bytes) return fail(400, 'Invalid ZIP file'); const record = { uploadId, filename, targetEnvironment, sizeBytes: bytes, createdAt: new Date().toISOString(), intakeStatus: 'quarantined', pipelineStatus: 'not-started', filePath, securityDecision: null }; deploymentUploads.unshift(record); persistDeployments(); if (!adoReady()) { record.pipelineStatus = 'configuration-required'; record.pipelineMessage = 'ADO settings missing; upload retained but no pipeline triggered'; persistDeployments(); return res.status(201).json({ uploadId, filename, targetEnvironment, sizeBytes: bytes, intakeStatus: record.intakeStatus, pipelineStatus: record.pipelineStatus, message: record.pipelineMessage }); } try { await triggerAdo(record); return res.status(201).json({ uploadId, filename, targetEnvironment, sizeBytes: bytes, intakeStatus: record.intakeStatus, pipelineStatus: record.pipelineStatus, pipelineRunId: record.pipelineRunId, pipelineRunUrl: record.pipelineRunUrl, message: 'Upload received and ADO pipeline triggered' }); } catch (e) { record.pipelineStatus = 'trigger-failed'; record.pipelineMessage = e.message; persistDeployments(); return res.status(502).json({ uploadId, filename, pipelineStatus: record.pipelineStatus, error: `Upload retained in quarantine; pipeline trigger failed: ${e.message}` }); } }); });

// Public, non-secret MSAL bootstrap configuration. The browser needs these
// identifiers before it can sign in. Keep secrets/credentials out of this route.
// Environment-specific values let one frontend artifact work in TEST and PROD.
app.get('/api/auth/config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    tenantId: process.env.ENTRA_TENANT_ID || '',
    clientId: process.env.ENTRA_SPA_CLIENT_ID || process.env.ENTRA_CLIENT_ID || process.env.VITE_ENTRA_CLIENT_ID || '',
    apiScope: process.env.ENTRA_API_SCOPE || process.env.VITE_ENTRA_API_SCOPE || '',
    redirectUri: process.env.ENTRA_REDIRECT_URI || process.env.VITE_ENTRA_REDIRECT_URI || '',
  });
});

app.get('/api/use-cases', (req, res) => {
  res.json(useCases);
});

app.post('/api/use-cases/:id/launch', (req, res) => {
  const id = req.params.id;
  const useCase = useCases.find(uc => uc.id === id);
  if (useCase) {
    useCase.launches = (useCase.launches || 0) + 1;
    res.json({ success: true, launches: useCase.launches });
  } else {
    res.status(404).json({ error: 'Use case not found' });
  }
});

app.get('/api/system-health', (req, res) => {
  res.json({
    overview: systemHealth,
    monitoring: monitoringData,
    executionStats: executionStats
  });
});

/* ── Admin tab: real status checks + auto-fix + owner notification ── */
/*    All routes below require a valid Entra ID sign-in (see entraAuth.js). */

// UC1: current status of every use case with a live launchUrl
app.get('/api/admin/health', requireEntraAuth, (req, res) => {
  const apps = adminHealth.getHealthSnapshot(useCases);
  const checkedApps = apps.filter(a => a.lastChecked);
  res.json({
    apps,
    summary: {
      total: apps.length,
      active: apps.filter(a => a.status === 'active').length,
      stopped: apps.filter(a => a.status === 'stopped').length,
      inactive: apps.filter(a => a.status === 'inactive').length,
      checking: apps.filter(a => a.status === 'checking').length,
      avgLatencyMs: checkedApps.length
        ? Math.round(checkedApps.reduce((sum, a) => sum + (a.latencyMs || 0), 0) / checkedApps.length)
        : null,
    },
  });
});

// UC1+2+3 for a single app: re-probe now, auto-fix via retry, notify owner if still down
app.post('/api/admin/health/:id/check', requireEntraAuth, async (req, res) => {
  const useCase = useCases.find(uc => uc.id === req.params.id);
  if (!useCase) return res.status(404).json({ error: 'Use case not found' });
  const record = await adminHealth.investigateApplication(useCase);
  res.json(record);
});

// UC1+2+3 across every app in the catalog
app.post('/api/admin/health/check-all', requireEntraAuth, async (req, res) => {
  const records = await adminHealth.runCheckAll(useCases);
  res.json({ apps: records });
});

// Live feed for the "Active Alerts" panel: detections, auto-fix attempts, resolutions, notifications
app.get('/api/admin/incidents', requireEntraAuth, (req, res) => {
  const limit = Number(req.query.limit) || 50;
  res.json(adminHealth.getIncidents(limit));
});

// Azure Monitor / Log Analytics: errors only, grouped per registered application.
app.get('/api/admin/logs/errors', requireEntraAuth, async (req, res) => {
  try {
    const minutes = Math.min(Math.max(Number(req.query.minutes) || 60, 1), 1440);
    const result = await azureLogs.getErrorsForApplications(useCases.filter(uc => uc.launchUrl), minutes, 50);
    res.json(result);
  } catch (err) {
    res.status(200).json({ configured: true, queryError: true, error: err.message, apps: {} });
  }
});

app.get('/api/admin/logs/errors/:id', requireEntraAuth, async (req, res) => {
  const useCase = useCases.find(uc => uc.id === req.params.id);
  if (!useCase) return res.status(404).json({ error: 'Use case not found' });
  try {
    const minutes = Math.min(Math.max(Number(req.query.minutes) || 60, 1), 31 * 24 * 60);
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
    const range = req.query.start && req.query.end ? { start: req.query.start, end: req.query.end } : null;
    const result = await azureLogs.getErrorsForUseCase(useCase, minutes, limit, range);
    // Operational severity is contextual. If the application currently has a
    // latched, unhealthy dependency that makes the workflow unusable, every
    // error row shown for that incident is escalated to Critical in the admin
    // evidence view. Preserve the raw row severity for diagnostics.
    const health = adminHealth.getHealthSnapshot([useCase])[0];
    // Preserve the live probe result in the detail view even when the target
    // application does not emit HTTP diagnostics (or ingestion is delayed).
    // This is explicitly labeled as monitor evidence, not an Azure log row.
    if (health && Number(health.statusCode) >= 500 && health.lastError) {
      result.errors = Array.isArray(result.errors) ? result.errors : [];
      const alreadyPresent = result.errors.some((row) => String(row.Message || '').includes(`HTTP ${health.statusCode}`));
      if (!alreadyPresent) result.errors.unshift({
        TimeGenerated: health.lastChecked || new Date().toISOString(),
        Source: 'Health Monitor',
        Level: 'Error',
        Severity: 'critical',
        Message: `Live health probe received HTTP ${health.statusCode}: ${health.lastError.errorMessage || 'Application returned a server error'}`,
        _ResourceId: azureLogs.resolveResourceId(useCase),
        ResourceName: useCase.title,
        IsSynthetic: true,
      });
    }
    const criticalDependency = ['degraded', 'inactive'].includes(health?.status) &&
      health?.dependencyHealth?.status === 'unhealthy';
    if (criticalDependency && Array.isArray(result.errors)) {
      result.errors = result.errors.map((row) => ({
        ...row,
        RawSeverity: row.RawSeverity || row.Severity || row.Level || null,
        Severity: 'critical',
        OperationalSeverityReason: `Application is unavailable because of an unresolved ${health.dependencyHealth?.failingDependency || 'dependency'} failure`,
      }));
      result.operationalSeverity = 'critical';
    }
    res.json(result);
  } catch (err) {
    res.status(200).json({ configured: true, queryError: true, error: err.message, errors: [] });
  }
});

// Non-sensitive config summary for the Security & Access / Configuration tabs —
// exposes counts only (never the actual allowlisted emails).
app.get('/api/admin/config', requireEntraAuth, (req, res) => {
  const webhookConfigured = !!(process.env.OWNER_NOTIFICATION_WEBHOOK_URL || process.env.AZURE_NOTIFICATION_WEBHOOK_URL);
  res.json({
    allowedEmailsCount,
    notifications: {
      provider: webhookConfigured ? 'Logic App webhook' : 'Not configured',
      webhookConfigured,
      cc: String(process.env.OWNER_NOTIFICATION_CC || 'laltupati@kpmg.com')
        .split(/[;,]/).map((email) => email.trim()).filter(Boolean),
      smtpRequired: false,
    },
  });
});

// Real Azure spend for "Usage & Cost" and the Overview's Cost & Consumption
// panel. Returns { configured: false } until AZURE_SUBSCRIPTION_ID is set —
// see README-AZURE-COST.md.
app.get('/api/admin/cost', requireEntraAuth, async (req, res) => {
  try {
    const startDate = req.query.start || req.query.startDate || undefined;
    const endDate = req.query.end || req.query.endDate || undefined;
    const force = String(req.query.force || '').toLowerCase() === '1' || String(req.query.force || '').toLowerCase() === 'true';
    res.json(await costMetrics.getCostIntelligence(useCases, { startDate, endDate, force }));
  } catch (err) {
    res.status(500).json({ configured: true, error: err.message });
  }
});

// Background sweep so status is fresh even before anyone opens the Admin tab
adminHealth.startMonitoring(useCases);

// Serve frontend in production (Azure)
const clientBuildPath = path.join(__dirname, '../client/dist');
app.use(express.static(clientBuildPath));

// Catch-all route to serve index.html for Single Page Application routing
app.use((req, res) => {
  res.sendFile(path.join(clientBuildPath, 'index.html'));
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});

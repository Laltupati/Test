# Admin Panel — Deployment tab: Azure DevOps and Azure setup

This is an **additive Admin Panel feature**. It does not change Health & Monitoring, Usage & Cost, Alerts & Incidents, Overview, or Configuration behavior.


## Implemented flow

1. Admin uploads a ZIP in **Admin Panel → Deployment**.
2. Backend validates the ZIP signature and stores it in a quarantine folder without extracting or executing it.
3. When Azure DevOps settings are present, backend starts the configured pipeline and supplies the upload ID plus an HMAC-signed source-download token as a secret pipeline variable.
4. Pipeline retrieves the ZIP from the authenticated-by-signature callback route and safely checks archive paths before extraction.
5. Pipeline runs Gitleaks (secrets), Trivy (dependency vulnerabilities, secrets, and recognized IaC misconfigurations), Semgrep (SAST), and Checkov (Bicep template checks). Reports are published as an Azure DevOps pipeline artifact and a limited summary is sent back to the Admin Panel.
6. Critical findings block continuation. When non-critical findings exist, the pipeline pauses for an Admin Panel decision: **Fix & re-upload** or **Continue with waiver**. Waiver requires a reason and the Admin API records the admin email, reason, and timestamp. Critical findings cannot be waived in this UI.
7. A clean scan is auto-approved and continues.
8. Pipeline runs a Bicep `what-if`, creates a new resource group and Linux App Service Plan/Web App, builds and packages the supported Node application, deploys the package, and performs an HTTP smoke check.
9. PROD upload runs require an Azure DevOps `ManualValidation` approval stage before provisioning.
10. Admin Panel polls Azure DevOps pipeline run state and displays scan findings, stage, pipeline link, and deployed URL when reported.

## Scope and limitations of this first implementation

- The first automated deployment profile is **Node.js 22 on Linux App Service**. Other stacks fail with an explicit unsupported-profile message rather than being falsely deployed.
- The Bicep template creates a new resource group, Linux App Service Plan, and App Service for each upload. DEV/TEST use Basic B1 by default; PROD uses Premium P1v3. Review and change these SKUs before enabling real deployment.
- Upload files and run metadata are stored in the App Service's local quarantine folder. This is not durable across some restarts, and is not safe for multi-instance scaling. For production/high availability, replace this with a private Blob Storage quarantine/artifact store and retention lifecycle policy (the current local implementation is a single-instance pilot). The security-decision wait stage currently polls using a hosted agent for up to 6 hours, which consumes pipeline agent time; a later iteration should split scan and deploy into separate pipelines or use a durable external gate.
- This package cannot verify the Azure DevOps PAT, pipeline permissions, Azure service connection, subscription role assignments, or live Azure resource deployment because no tenant credentials are included.
- Scanner report artifacts are available in the Azure DevOps run. This implementation sends only summarized finding details to the Admin Panel, not detected secret values.
- A pipeline that fails before its result callback will show the Azure DevOps failure and available partial scan data, if scan callback already completed.

## One-time server App Service settings

Set the following in **Azure Portal → Admin Panel App Service → Settings → Environment variables** (restart after changing settings). Never put PATs or signing secrets in source control.

| Setting | Required | Value |
|---|---|---|
| `AZDO_ORG_URL` | Yes | `https://dev.azure.com/<organization>` |
| `AZDO_PROJECT` | Yes | Exact Azure DevOps project name |
| `AZDO_PIPELINE_ID` | Yes | Numeric ID of the pipeline using `azure-pipelines-deployment.yml` |
| `AZDO_PAT` | Yes | Short-lived PAT with Build read/execute, scoped to this project where possible |
| `DEPLOY_SOURCE_TOKEN_SECRET` | Yes | Random 32-byte secret; generate with `openssl rand -hex 32` |
| `DEPLOY_CALLBACK_BASE_URL` | Yes | Public HTTPS Admin Panel base URL, no trailing slash |
| `DEPLOY_UPLOAD_LIMIT_MB` | Optional | Default 25 MB |
| `DEPLOY_UPLOAD_RETENTION_HOURS` | Optional | Default 24 hours |


## Azure DevOps repository setup

1. Ensure the repository used for the pipeline contains this code, `azure-pipelines-deployment.yml`, and `deployment/bicep/appservice.bicep`.
2. In Azure DevOps, create a pipeline pointing to `azure-pipelines-deployment.yml`. Set its pipeline ID in the server App Service setting `AZDO_PIPELINE_ID`.
3. Grant the PAT the minimum needed pipeline run/status permissions (Build read & execute). Prefer an organization-approved service identity/federation for REST triggering if your environment supports it; this code uses PAT for the REST trigger/status requests.
4. In the pipeline's variable configuration (or approved variable group), add:
   - `DEPLOY_CALLBACK_BASE_URL` = same public HTTPS Admin Panel URL
   - `AZURE_DEPLOY_SERVICE_CONNECTION` = name of an Azure Resource Manager service connection with approved permissions
   - `AZURE_DEPLOY_LOCATION` = e.g. `eastus` (optional; defaults to `eastus`)
   - `AZURE_DEPLOY_RESOURCE_GROUP_PREFIX` = `admin-deploy-rg` (optional default)
   - `AZURE_WEBAPP_NAME_PREFIX` = `admin-deploy` (optional default)
5. Authorize the Azure service connection for this pipeline only. Its permissions must allow resource group creation in the target subscription and resource deployment within that scope. A subscription-level role that permits resource-group creation is required by the current pipeline; use an organization-approved custom role/service identity and scope.
6. Review `deployment/bicep/appservice.bicep` and the SKU defaults. Apply budget/guardrails and verify Microsoft.Web resource provider registration in the target subscription.
7. Configure Azure DevOps Environment approvals for production as an additional control if desired. The YAML also has a PROD ManualValidation stage.
8. Save and run a pipeline validation in Azure DevOps before enabling upload-triggered deployments.


## Pipeline variable details

| Variable | Purpose |
|---|---|
| `sourceDownloadToken` | Injected at run time as a secret variable by the Admin API; never define a static value |
| `DEPLOY_CALLBACK_BASE_URL` | Used by the pipeline for signed source, scan-result, stage, decision and result callbacks |
| `AZURE_DEPLOY_SERVICE_CONNECTION` | Azure service connection name passed to Azure CLI and App Service deployment tasks |
| `AZURE_DEPLOY_LOCATION` | Azure region for new resource group/resources |
| `AZURE_DEPLOY_RESOURCE_GROUP_PREFIX` | Prefix for generated resource group names |
| `AZURE_WEBAPP_NAME_PREFIX` | Prefix for generated App Service names; globally unique names may still collide and cause deployment failure |


## Azure resources created per upload

- Resource group: `<RG_PREFIX>-<environment>-<sanitized-source-name>-<upload-id-prefix>`
- Linux App Service Plan: Basic B1 for DEV/TEST, Premium P1v3 for PROD
- Linux App Service: Node.js 22, HTTPS-only, FTPS disabled, minimum TLS 1.2, package run-from-package setting

The resource names are deterministic for the upload ID and unique per upload. The pipeline runs Bicep `what-if` and then applies the Bicep template. The what-if preview is currently in pipeline logs, not rendered as a dedicated preview card in the Admin Panel.


## Troubleshooting

- **Pipeline not configured in UI:** verify the six server settings above, save, restart the App Service, and refresh the Deployment tab.
- **Trigger failed:** check PAT expiry/scopes, organization URL, project name, pipeline ID, and whether the PAT user can run the selected pipeline.
- **Source download 403:** source token secret must match the backend signing secret, and the callback base URL must be reachable from the hosted agent.
- **Scan reports missing:** inspect Docker pulls/permissions and scanner logs. Missing reports intentionally fail the Scan stage.
- **Security decision timeout:** refresh the Admin Panel. Use Fix & re-upload or enter a waiver reason and continue if the finding policy allows it. Critical findings are blocked.
- **Azure provisioning fails:** check service connection authorization, subscription permissions, resource provider registration, quotas, location availability, App Service naming, and the Bicep what-if output.
- **Build/startup fails:** first profile expects a Node project with a start script or `server.js`, `app.js`, or `index.js` entry point. Review pipeline build logs.
- **Smoke test fails:** inspect App Service logs and environment variables. The deployment pipeline does not infer application-specific secrets or inject them automatically.

## Rollback / cleanup

This version creates new resources per upload; it does not delete failed or prior resource groups automatically. Review the run and resource tags (`managedBy=AdminDeploymentTab`, `sourceUploadId`) before cleanup. Automatic rollback is not implemented yet.

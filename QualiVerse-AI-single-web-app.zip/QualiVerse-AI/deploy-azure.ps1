[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ResourceGroupName,
    [Parameter(Mandatory=$true)][string]$WebAppName
)
$ErrorActionPreference = "Stop"

if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw "Azure CLI is required." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "Node.js/npm is required." }
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "Python is required." }

Push-Location frontend
try {
    npm ci
    $env:VITE_API_BASE_URL = "/api/v1"
    npm run build
} finally { Pop-Location }

python -m compileall -q backend/app
if (-not (Test-Path "frontend/dist/index.html")) { throw "Frontend build output is missing." }

Remove-Item -Recurse -Force backend/static -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force backend/static | Out-Null
Copy-Item -Recurse -Force frontend/dist/* backend/static/

Remove-Item -Force qualiverse-single-webapp.zip -ErrorAction SilentlyContinue
Push-Location backend
try {
    Compress-Archive -Path * -DestinationPath ../qualiverse-single-webapp.zip -Force
} finally { Pop-Location }

az webapp deploy --resource-group $ResourceGroupName --name $WebAppName `
    --src-path qualiverse-single-webapp.zip --type zip
az webapp restart --resource-group $ResourceGroupName --name $WebAppName
$hostName = az webapp show --resource-group $ResourceGroupName --name $WebAppName --query defaultHostName -o tsv
Write-Host "Application: https://$hostName"
Write-Host "Health:      https://$hostName/health"

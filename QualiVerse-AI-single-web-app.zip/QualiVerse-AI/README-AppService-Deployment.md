# QualiVerse AI — Azure single Web App deployment

## Architecture

QualiVerse AI is deployed as **one Azure Linux App Service Web App**:

- React + Vite frontend is built with Node.js 22.
- FastAPI backend runs on Python 3.11.
- The frontend build output is copied into `backend/static/`.
- FastAPI serves the React SPA and `/api/v1` endpoints from the same hostname.
- PostgreSQL Flexible Server remains a separate managed database resource.

There is no Azure Static Web App, second frontend Web App, frontend API URL, or browser CORS dependency in this deployment.

## Azure resources

| Resource | Purpose |
|---|---|
| Resource Group | Groups the application and database resources |
| Linux App Service Plan | Compute for the application |
| **One Linux Web App** | Serves React UI and FastAPI APIs |
| PostgreSQL Flexible Server + database | Persistent application data |
| Key Vault (recommended) | Stores database, JWT and OAuth secrets |
| Application Insights / Log Analytics (recommended) | Monitoring and diagnostics |

## Runtime and startup

Configure the Web App for Linux / Python 3.11.

Startup command:

```bash
gunicorn --bind 0.0.0.0:8000 --workers 2 --worker-class uvicorn.workers.UvicornWorker --timeout 120 app.main:app
```

App settings should include the existing database and authentication settings:

- `ENVIRONMENT`
- `DATABASE_URL`
- `USE_FIRESTORE=false`
- `JWT_SECRET` (unique secret; do not use the source-code fallback)
- `JWT_ALGORITHM=HS256`
- `JWT_ACCESS_TOKEN_EXPIRE_MINUTES=1440`
- `PORT=8000`
- `SCM_DO_BUILD_DURING_DEPLOYMENT=true`
- `ENABLE_ORYX_BUILD=true`

`CORS_ORIGINS` is not required for the React UI because browser requests use the same origin (`/api/v1`). If external browser clients need cross-origin access, configure only their exact trusted origins.

## Deploy using GitHub Actions

Configure these GitHub repository secrets:

- `AZURE_CREDENTIALS`
- `AZURE_RESOURCE_GROUP`
- `AZURE_WEBAPP_NAME`

The workflow `.github/workflows/deploy-azure.yml` performs these steps:

1. Installs frontend dependencies and builds React.
2. Validates backend Python source.
3. Copies `frontend/dist` into `backend/static`.
4. Packages the backend directory, with `app/`, `requirements.txt`, and `static/` at the ZIP root.
5. Deploys the combined ZIP to the one Web App.
6. Restarts the Web App and checks `/health`.

No `AZURE_STATIC_WEB_APPS_API_TOKEN` or `AZURE_BACKEND_API_URL` is needed.

## Deploy manually

```bash
./deploy-azure.sh <resource-group> <web-app-name>
```

Or run the equivalent commands:

```bash
cd frontend
npm ci
VITE_API_BASE_URL=/api/v1 npm run build
cd ..

rm -rf backend/static
mkdir -p backend/static
cp -a frontend/dist/. backend/static/

python3 -m compileall -q backend/app
cd backend
zip -qr ../qualiverse-single-webapp.zip . -x ".venv/*" "__pycache__/*" "*.pyc" ".env"
cd ..

az webapp deploy --resource-group <resource-group> --name <web-app-name> \
  --src-path qualiverse-single-webapp.zip --type zip
```

After deployment, verify:

- `https://<web-app-hostname>/` loads the React UI.
- `https://<web-app-hostname>/health` returns the API health response.
- `https://<web-app-hostname>/docs` loads FastAPI Swagger UI.
- Frontend API calls go to the same hostname under `/api/v1`.

## Important

This deployment package does not create, migrate, or delete your existing Azure resources. Review Terraform plan before applying infrastructure changes. If you previously used a separate Static Web App, it is no longer part of the application deployment; do not delete that Azure resource until you confirm it is unused.

The application still requires its existing PostgreSQL database and correctly configured secrets. This package does not rotate credentials or alter existing database records.

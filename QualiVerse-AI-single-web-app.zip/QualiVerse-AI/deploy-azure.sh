#!/bin/bash
# Build and deploy the complete QualiVerse AI application to one Azure Linux Web App.
set -euo pipefail

RESOURCE_GROUP="${1:-rg-qualiverse-dev}"
WEBAPP_NAME="${2:?Usage: ./deploy-azure.sh <resource-group> <web-app-name>}"

command -v az >/dev/null || { echo "Azure CLI is required."; exit 1; }
command -v npm >/dev/null || { echo "Node.js/npm is required."; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required."; exit 1; }

echo "Building frontend..."
(
  cd frontend
  npm ci
  VITE_API_BASE_URL=/api/v1 npm run build
)

echo "Validating backend..."
python3 -m compileall -q backend/app
test -f frontend/dist/index.html

echo "Packaging frontend and backend together..."
rm -rf backend/static
mkdir -p backend/static
cp -a frontend/dist/. backend/static/
(
  cd backend
  zip -qr ../qualiverse-single-webapp.zip . \
    -x ".venv/*" "__pycache__/*" "*.pyc" ".env"
)

echo "Deploying to the single Web App: ${WEBAPP_NAME}"
az webapp deploy \
  --resource-group "${RESOURCE_GROUP}" \
  --name "${WEBAPP_NAME}" \
  --src-path qualiverse-single-webapp.zip \
  --type zip

az webapp restart --resource-group "${RESOURCE_GROUP}" --name "${WEBAPP_NAME}"
APP_HOST=$(az webapp show --resource-group "${RESOURCE_GROUP}" --name "${WEBAPP_NAME}" --query defaultHostName -o tsv)
echo "Application: https://${APP_HOST}"
echo "Health:      https://${APP_HOST}/health"

# Single Web App deployment changes

- Frontend API client now defaults to relative `/api/v1`.
- Vite is configured with root-relative asset paths.
- GitHub Actions builds the React SPA and packages it into `backend/static`.
- GitHub Actions deploys one ZIP to one Azure Linux Web App and checks `/health`.
- Shell and PowerShell deployment scripts target one existing Web App.
- Azure Terraform no longer provisions an Azure Static Web App; the frontend URL output and deployment token output were removed.
- Root Dockerfile uses Node.js 22 for the frontend build and continues to serve the frontend from FastAPI in one container.
- PostgreSQL remains a separate managed database resource; “single Web App” means one application host, not one Azure resource overall.

Before deploying:
1. Set GitHub secrets `AZURE_CREDENTIALS`, `AZURE_RESOURCE_GROUP`, and `AZURE_WEBAPP_NAME`.
2. Confirm the Web App uses Linux Python 3.11 and the stated Gunicorn startup command.
3. Preserve existing `DATABASE_URL`, `JWT_SECRET`, and OAuth settings in App Service Configuration.
4. Review Terraform plan before applying; it will no longer manage a Static Web App resource.
5. Do not delete any old Static Web App until you verify no users or DNS routes still depend on it.

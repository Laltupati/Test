# Health Monitoring Targeted Fix

## Scope
This patch is based on the supplied latest Test-main package. It intentionally changes only `server/adminHealth.js` and leaves the Test UI, colours, labels, content, application catalog, deployment pipeline YAML, and Logic App owner-notification implementation untouched.

## Change
The health snapshot previously converted every `active` record with HTTP 403 into `inactive`, even when the probe had already positively identified an Azure App Service platform access-restriction response and reconciled Log Analytics evidence. This caused healthy applications whose App Service access restrictions block the monitoring worker to appear Unavailable on every dashboard refresh.

The snapshot now preserves `active` only for the two explicit platform-access-restriction sources already emitted by the existing reconciliation path:
- `azure_runtime_access_restricted`
- `azure_access_restriction_unverified`

Normal application-generated 401/403 responses and unclassified 403 responses continue to become Unavailable. Fresh actionable telemetry continues to take precedence, so confirmed application/dependency failures (including Advisor Intelligence / Neo4j) remain Unavailable.

The existing Resume Creator required-setting check and its backend App Service mapping are unchanged; it continues to classify a confirmed missing Azure OpenAI API-key setting as Unavailable.

## Validation
- `node --check` passed for every `server/*.js` file.
- Static assertions confirmed the existing Neo4j detection, required-setting validation, and owner-notification call paths remain present.
- Full frontend build was not run because npm dependencies were not available in the offline environment.
- No live Azure/Log Analytics/Logic App test was performed from this environment.
